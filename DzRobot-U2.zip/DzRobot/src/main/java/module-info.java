module pe.edu.upeu.dzrobot {
    requires javafx.controls;
    requires javafx.fxml;

    requires org.controlsfx.controls;
    requires static lombok;
    requires jakarta.validation;

    requires java.sql;
    requires java.naming;
    requires org.slf4j;
    requires com.zaxxer.hikari;
    requires org.jsoup;
    requires java.desktop;
    requires com.github.librepdf.openpdf;

    opens pe.edu.upeu.dzrobot to javafx.fxml;
    opens pe.edu.upeu.dzrobot.controller to javafx.fxml;
    opens pe.edu.upeu.dzrobot.model;
    exports pe.edu.upeu.dzrobot;
}
