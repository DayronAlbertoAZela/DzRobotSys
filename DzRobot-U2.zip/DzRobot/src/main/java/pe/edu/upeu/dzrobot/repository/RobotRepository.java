package pe.edu.upeu.dzrobot.repository;

import pe.edu.upeu.dzrobot.enums.EstadoRobot;
import pe.edu.upeu.dzrobot.enums.NivelEducativo;
import pe.edu.upeu.dzrobot.enums.TipoLocomocion;
import pe.edu.upeu.dzrobot.enums.TipoRobot;
import pe.edu.upeu.dzrobot.model.*;

import java.sql.Connection;
import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.Optional;

public class RobotRepository extends AbstractJpaRepository<Robot, Long> {
    private final ComponenteRepository componenteRepository;

    public RobotRepository(ComponenteRepository componenteRepository) {
        this.componenteRepository = componenteRepository;
    }

    private static final String SELECT_JOIN =
            "SELECT r.*, m.nombre AS mar_nombre, c.nombres AS cli_nombres, " +
                    "ri.capacidad_carga, ri.num_ejes, rm.locomocion, rm.autonomia, re.plataforma, re.nivel " +
                    "FROM producto r JOIN marca m ON r.id_marca = m.id_marca " +
                    "LEFT JOIN cliente c ON r.dniruc = c.dniruc " +
                    "LEFT JOIN robot_industrial ri ON r.id_producto = ri.id_producto " +
                    "LEFT JOIN robot_movil rm ON r.id_producto = rm.id_producto " +
                    "LEFT JOIN robot_educativo re ON r.id_producto = re.id_producto " +
                    "WHERE r.tipo IN ('INDUSTRIAL', 'MOVIL', 'EDUCATIVO') ";

    @Override
    protected String getTableName() {return "producto";}

    @Override
    protected String getPkColumn() {return "id_producto";}

    @Override
    public List<Robot> findAll() {
        return cargarComponentes(executeQuery(SELECT_JOIN + "ORDER BY r.codigo"));
    }

    @Override
    public Optional<Robot> findById(Long id) {
        return executeQueryOne(SELECT_JOIN + "AND r.id_producto = ?", id)
                .map(r -> cargarComponentes(List.of(r)).get(0));
    }

    private List<Robot> cargarComponentes(List<Robot> robots) {
        for (Robot r : robots) {
            r.setComponentes(componenteRepository.listarPorRobot(r.getIdRobot()));
        }
        return robots;
    }

    @Override
    protected Robot mapRow(ResultSet rs) throws SQLException {
        Robot.RobotBuilder<?, ?> b = switch (TipoRobot.valueOf(rs.getString("tipo"))) {
            case INDUSTRIAL -> RobotIndustrial.builder()
                    .capacidadCarga(rs.getDouble("capacidad_carga"))
                    .numEjes(rs.getInt("num_ejes"));
            case MOVIL -> RobotMovil.builder()
                    .locomocion(TipoLocomocion.valueOf(rs.getString("locomocion")))
                    .autonomia(rs.getDouble("autonomia"));
            case EDUCATIVO -> RobotEducativo.builder()
                    .plataforma(rs.getString("plataforma"))
                    .nivel(NivelEducativo.valueOf(rs.getString("nivel")));
        };
        Date ultMant = rs.getDate("fecha_ult_mant");
        String dniruc = rs.getString("dniruc");
        return b.idRobot(rs.getLong("id_producto"))
                .codigo(rs.getString("codigo"))
                .nombre(rs.getString("nombre"))
                .modelo(rs.getString("modelo"))
                .fechaAdq(rs.getDate("fecha_adq").toLocalDate())
                .fechaUltMant(ultMant == null ? null : ultMant.toLocalDate())
                .estado(EstadoRobot.valueOf(rs.getString("estado")))
                .pu(rs.getDouble("pu"))
                .utilidad(rs.getDouble("utilidad"))
                .idMarca(Marca.builder().idMarca(rs.getLong("id_marca")).nombre(rs.getString("mar_nombre")).build())
                .dniruc(dniruc == null ? null : Cliente.builder().dniruc(dniruc).nombres(rs.getString("cli_nombres")).build())
                .build();
    }

    @Override
    protected Robot insert(Connection conn, Robot e) throws SQLException {
        if (e.getFechaUltMant() == null) e.setFechaUltMant(e.getFechaAdq());
        long id = executeInsertGetKey(conn,
                "INSERT INTO producto(codigo,nombre,modelo,tipo,fecha_adq,fecha_ult_mant,estado,pu,utilidad,id_marca,dniruc,vida_util,stock) " +
                        "VALUES(?,?,?,?,?,?,?,?,?,?,?,0,?)",
                e.getCodigo(), e.getNombre(), e.getModelo(), e.getTipoRobot().name(),
                Date.valueOf(e.getFechaAdq()), Date.valueOf(e.getFechaUltMant()), e.getEstado().name(),
                e.getPu(), e.getUtilidad(), e.getIdMarca().getIdMarca(),
                e.getDniruc() == null ? null : e.getDniruc().getDniruc(), stock(e));
        e.setIdRobot(id);
        insertarSubclase(conn, e);
        return e;
    }

    @Override
    protected Robot updateRow(Connection conn, Robot e) throws SQLException {
        executeUpdate(conn,
                "UPDATE producto SET codigo=?,nombre=?,modelo=?,fecha_adq=?,fecha_ult_mant=?,estado=?,pu=?,utilidad=?,id_marca=?,dniruc=?,stock=? " +
                        "WHERE id_producto=?",
                e.getCodigo(), e.getNombre(), e.getModelo(), Date.valueOf(e.getFechaAdq()),
                Date.valueOf(e.getFechaUltMant() == null ? e.getFechaAdq() : e.getFechaUltMant()),
                e.getEstado().name(), e.getPu(), e.getUtilidad(), e.getIdMarca().getIdMarca(),
                e.getDniruc() == null ? null : e.getDniruc().getDniruc(), stock(e), e.getIdRobot());
        executeUpdate(conn, "DELETE FROM " + tablaSubclase(e) + " WHERE id_producto=?", e.getIdRobot());
        insertarSubclase(conn, e);
        return e;
    }

    @Override
    public void deleteById(Long id) {
        try (Connection conn = openConnection()) {
            conn.setAutoCommit(false);
            try {
                for (String t : List.of("robot_industrial", "robot_movil", "robot_educativo", "componente")) {
                    executeUpdate(conn, "DELETE FROM " + t + " WHERE id_producto=?", id);
                }
                executeUpdate(conn, "DELETE FROM producto WHERE id_producto=?", id);
                conn.commit();
            } catch (SQLException e) {
                conn.rollback();
                throw e;
            }
        } catch (SQLException e) {
            throw new RuntimeException("No se pudo eliminar (¿tiene ventas o mantenimientos?): " + e.getMessage(), e);
        }
    }

    private String tablaSubclase(Robot e) {
        return "robot_" + e.getTipoRobot().name().toLowerCase();
    }

    private void insertarSubclase(Connection conn, Robot e) throws SQLException {
        if (e instanceof RobotIndustrial ri) {
            executeUpdate(conn, "INSERT INTO robot_industrial(id_producto,capacidad_carga,num_ejes) VALUES(?,?,?)",
                    ri.getIdRobot(), ri.getCapacidadCarga(), ri.getNumEjes());
        } else if (e instanceof RobotMovil rm) {
            executeUpdate(conn, "INSERT INTO robot_movil(id_producto,locomocion,autonomia) VALUES(?,?,?)",
                    rm.getIdRobot(), rm.getLocomocion().name(), rm.getAutonomia());
        } else if (e instanceof RobotEducativo re) {
            executeUpdate(conn, "INSERT INTO robot_educativo(id_producto,plataforma,nivel) VALUES(?,?,?)",
                    re.getIdRobot(), re.getPlataforma(), re.getNivel().name());
        }
    }

    private double stock(Robot e) {
        return e.getEstado() == EstadoRobot.EN_STOCK ? 1 : 0;
    }
}
