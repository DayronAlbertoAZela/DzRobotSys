package pe.edu.upeu.dzrobot.repository;

import pe.edu.upeu.dzrobot.config.DatabaseConfig;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class ConsultaRepository {
    public List<Map<String, Object>> filas(String sql, Object... params) {
        try (Connection conn = DatabaseConfig.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            for (int i = 0; i < params.length; i++) {
                ps.setObject(i + 1, params[i]);
            }
            try (ResultSet rs = ps.executeQuery()) {
                ResultSetMetaData md = rs.getMetaData();
                List<Map<String, Object>> lista = new ArrayList<>();
                while (rs.next()) {
                    Map<String, Object> fila = new LinkedHashMap<>();
                    for (int c = 1; c <= md.getColumnCount(); c++) {
                        fila.put(md.getColumnLabel(c).toLowerCase(), rs.getObject(c));
                    }
                    lista.add(fila);
                }
                return lista;
            }
        } catch (SQLException e) {
            throw new RuntimeException("Error en consulta: " + e.getMessage(), e);
        }
    }

    public double numero(String sql, Object... params) {
        List<Map<String, Object>> r = filas(sql, params);
        if (r.isEmpty()) {
            return 0;
        }
        Object v = r.get(0).values().iterator().next();
        return v == null ? 0 : ((Number) v).doubleValue();
    }

    public int ejecutar(String sql, Object... params) {
        try (Connection conn = DatabaseConfig.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            for (int i = 0; i < params.length; i++) {
                ps.setObject(i + 1, params[i]);
            }
            return ps.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException("Error al guardar: " + e.getMessage(), e);
        }
    }
}
