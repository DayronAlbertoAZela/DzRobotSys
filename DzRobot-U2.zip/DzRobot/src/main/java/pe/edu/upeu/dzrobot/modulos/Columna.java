package pe.edu.upeu.dzrobot.modulos;

import java.util.function.Function;

public record Columna(String titulo, String clave, double ancho, Tipo tipo, Function<String, String> color) {
    public enum Tipo { TEXTO, MONEDA, NUMERO, PILDORA }

    public static Columna texto(String titulo, String clave, double ancho) {
        return new Columna(titulo, clave, ancho, Tipo.TEXTO, null);
    }

    public static Columna moneda(String titulo, String clave, double ancho) {
        return new Columna(titulo, clave, ancho, Tipo.MONEDA, null);
    }

    public static Columna numero(String titulo, String clave, double ancho) {
        return new Columna(titulo, clave, ancho, Tipo.NUMERO, null);
    }

    public static Columna pildora(String titulo, String clave, double ancho, Function<String, String> color) {
        return new Columna(titulo, clave, ancho, Tipo.PILDORA, color);
    }
}
