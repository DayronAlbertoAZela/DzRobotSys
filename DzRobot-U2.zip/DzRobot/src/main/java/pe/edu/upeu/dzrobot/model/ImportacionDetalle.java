package pe.edu.upeu.dzrobot.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ImportacionDetalle {
    private Long idImportacionDetalle;
    private double pu;
    private double cantidad;
    private Robot idRobot;
    private Repuesto idRepuesto;

    public double getSubtotal() {
        return pu * cantidad;
    }
}
