package pe.edu.upeu.dzrobot.controller;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.chart.BarChart;
import javafx.scene.chart.CategoryAxis;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.XYChart;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.layout.Priority;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.shape.Circle;
import javafx.stage.Stage;
import lombok.RequiredArgsConstructor;
import pe.edu.upeu.dzrobot.DzRobot;
import pe.edu.upeu.dzrobot.componentes.Iconos;
import pe.edu.upeu.dzrobot.componentes.Tema;
import pe.edu.upeu.dzrobot.config.AppContext;
import pe.edu.upeu.dzrobot.dto.MenuMenuItenTO;
import pe.edu.upeu.dzrobot.dto.SessionManager;
import pe.edu.upeu.dzrobot.model.Repuesto;
import pe.edu.upeu.dzrobot.model.Robot;
import pe.edu.upeu.dzrobot.modulos.Modulos;
import pe.edu.upeu.dzrobot.repository.ConsultaRepository;
import pe.edu.upeu.dzrobot.service.IMenuMenuItemDao;
import pe.edu.upeu.dzrobot.service.IRepuestoService;
import pe.edu.upeu.dzrobot.service.IRobotService;

import java.io.IOException;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.TextStyle;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.HashMap;

@RequiredArgsConstructor
public class MainGuiController {
    private static final Locale ES = Locale.forLanguageTag("es-PE");
    private static final DecimalFormat SOLES = new DecimalFormat("S/ #,##0", DecimalFormatSymbols.getInstance(Locale.US));

    private final IMenuMenuItemDao menuDao;
    private final IRobotService robotService;
    private final IRepuestoService repuestoService;
    private final ConsultaRepository consultas = new ConsultaRepository();

    @FXML
    MenuBar menuBar;
    @FXML
    TabPane tabPane;
    @FXML
    Label lblUsuario, lblVersion;

    private final Map<String, MenuMenuItenTO> accesosPorId = new HashMap<>();

    @FXML
    public void initialize() {
        SessionManager s = SessionManager.getInstance();
        lblUsuario.setText("Usuario: " + s.getUserName() + "   |   Perfil: " + s.getUserPerfil());
        lblVersion.setText(Tema.NOMBRE + " " + Tema.VERSION);
        construirMenu(menuDao.listaAccesos(s.getUserPerfil()));
        mostrarPrincipal();
    }

    private void construirMenu(List<MenuMenuItenTO> accesos) {
        accesosPorId.clear();
        Map<String, Menu> menus = new LinkedHashMap<>();
        Menu sistema = new Menu("Sistema");
        MenuItem inicio = new MenuItem("Inicio");
        inicio.setOnAction(e -> mostrarPrincipal());
        sistema.getItems().add(inicio);
        menus.put("Sistema", sistema);
        for (MenuMenuItenTO acceso : accesos) {
            accesosPorId.put(acceso.getIdNombreObj(), acceso);
            Menu menu = menus.computeIfAbsent(acceso.getMenunombre(), Menu::new);
            if ("C".equals(acceso.getTipoTab())) {
                menu.getItems().add(new SeparatorMenuItem());
            }
            MenuItem item = new MenuItem(acceso.getMenuitemnombre());
            item.setOnAction(e -> manejar(acceso));
            menu.getItems().add(item);
        }
        menuBar.getMenus().setAll(menus.values());
    }

    private void manejar(MenuMenuItenTO acceso) {
        if ("C".equals(acceso.getTipoTab())) {
            cerrarSesion();
        } else if (!acceso.getRutaFile().isEmpty()) {
            abrirTabPaneFXML(acceso.getRutaFile(), acceso.getNombreTab());
        } else {
            Node modulo = Modulos.crear(acceso.getIdNombreObj());
            abrirTab(acceso.getNombreTab(), modulo != null ? modulo
                    : new Label("Módulo \"" + acceso.getNombreTab() + "\" en construcción."));
        }
    }

    private void ir(String id) {
        MenuMenuItenTO acceso = accesosPorId.get(id);
        if (acceso != null) {
            manejar(acceso);
        }
    }

    private String motivo(Robot r) {
        return r.getProximoMantenimiento().isAfter(LocalDate.now())
                ? "tiene un componente desgastado"
                : "le tocaba el " + r.getProximoMantenimiento();
    }

    private void mostrarPrincipal() {
        ImageView marca = new ImageView(new Image(DzRobot.class.getResourceAsStream("/img/dzrobot-marca.png")));
        marca.setFitHeight(40);
        marca.setPreserveRatio(true);
        marca.setSmooth(true);
        Label saludo = new Label(saludo() + ", " + SessionManager.getInstance().getUserName());
        saludo.getStyleClass().add("dash-saludo");
        Label fecha = new Label(LocalDate.now().format(DateTimeFormatter.ofPattern("EEEE d 'de' MMMM 'de' yyyy", ES)));
        fecha.getStyleClass().add("dash-fecha");
        VBox textos = new VBox(2, saludo, fecha);
        textos.setAlignment(Pos.CENTER_RIGHT);
        Pane espacio = new Pane();
        HBox.setHgrow(espacio, Priority.ALWAYS);
        HBox cabecera = new HBox(12, marca, espacio, textos);
        cabecera.setAlignment(Pos.CENTER_LEFT);
        cabecera.getStyleClass().add("panel");

        VBox contenedor = new VBox(14, cabecera);
        contenedor.setPadding(new Insets(10));
        try {
            List<Robot> alertas = robotService.listarQueNecesitanMantenimiento();
            List<Repuesto> stockBajo = repuestoService.listarStockBajo();
            int mes = LocalDate.now().getMonthValue(), anio = LocalDate.now().getYear();

            HBox tarjetas = new HBox(12);
            tarjetas.getChildren().addAll(
                    tarjeta("kpi-verde", Iconos.ROBOT, "Robots en stock",
                            fmt(consultas.numero("SELECT COUNT(*) FROM producto WHERE tipo IN ('INDUSTRIAL', 'MOVIL', 'EDUCATIVO') AND estado = 'EN_STOCK'")), "listos para vender", "mirobot"),
                    tarjeta("kpi-gris", Iconos.CARRITO, "Robots vendidos",
                            fmt(consultas.numero("SELECT COUNT(*) FROM producto WHERE tipo IN ('INDUSTRIAL', 'MOVIL', 'EDUCATIVO') AND dniruc IS NOT NULL")), "en total", "mihventa"),
                    tarjeta("kpi-naranja", Iconos.LLAVE, "Mantenimiento", String.valueOf(alertas.size()),
                            "robots lo necesitan", "mimant"),
                    tarjeta("kpi-celeste", Iconos.DINERO, "Ventas del mes",
                            SOLES.format(consultas.numero("SELECT COALESCE(SUM(precio_total), 0) FROM venta "
                                    + "WHERE EXTRACT(MONTH FROM fecha_gener) = ? AND EXTRACT(YEAR FROM fecha_gener) = ?", mes, anio)),
                            LocalDate.now().getMonth().getDisplayName(TextStyle.FULL, ES), "mihventa"),
                    tarjeta("kpi-rojo", Iconos.ALERTA, "Stock bajo", String.valueOf(stockBajo.size()),
                            "repuestos con 5 o menos", "mirepuesto"));

            VBox panelGrafico = new VBox(6, subtitulo("Ventas e importaciones por mes (S/)"), grafico());
            panelGrafico.getStyleClass().add("panel");
            HBox.setHgrow(panelGrafico, Priority.ALWAYS);

            VBox lista = new VBox(6, subtitulo("Alertas de hoy"));
            alertas.forEach(r -> lista.getChildren().add(alerta(false, r.getCodigo() + " " + r.getNombre(), motivo(r))));
            stockBajo.forEach(r -> lista.getChildren().add(alerta(true, r.getNombre(),
                    "quedan " + r.getStock().intValue() + " unidades")));
            if (alertas.isEmpty() && stockBajo.isEmpty()) {
                lista.getChildren().add(new Label("Todo en orden, no hay alertas."));
            }
            lista.getStyleClass().add("panel");
            lista.setPrefWidth(420);
            lista.setMinWidth(360);

            HBox fila = new HBox(14, panelGrafico, lista);
            contenedor.getChildren().addAll(tarjetas, fila);
        } catch (RuntimeException ex) {
            contenedor.getChildren().add(new Label("No se pudieron cargar los datos: " + ex.getMessage()));
        }
        abrirTab("Inicio", contenedor);
    }

    private String saludo() {
        int h = java.time.LocalTime.now().getHour();
        return h < 12 ? "Buenos días" : h < 19 ? "Buenas tardes" : "Buenas noches";
    }

    private static String fmt(double n) {
        return String.valueOf((long) n);
    }

    private Label subtitulo(String texto) {
        Label l = new Label(texto);
        l.getStyleClass().add("dash-subtitulo");
        return l;
    }

    private Node tarjeta(String color, String icono, String titulo, String numero, String detalle, String moduloId) {
        StackPane burbuja = new StackPane(Iconos.crear(icono, 24));
        burbuja.getStyleClass().add("kpi-burbuja");
        Label lTitulo = new Label(titulo);
        lTitulo.getStyleClass().add("kpi-titulo");
        Label lNumero = new Label(numero);
        lNumero.getStyleClass().add("kpi-numero");
        Label lDetalle = new Label(detalle);
        lDetalle.getStyleClass().add("kpi-detalle");
        VBox textos = new VBox(0, lTitulo, lNumero, lDetalle);
        HBox card = new HBox(14, burbuja, textos);
        card.setAlignment(Pos.CENTER_LEFT);
        card.getStyleClass().addAll("panel", "kpi-card", color);
        card.setPrefWidth(240);
        card.setMaxWidth(Double.MAX_VALUE);
        HBox.setHgrow(card, Priority.ALWAYS);
        card.setOnMouseClicked(e -> ir(moduloId));
        return card;
    }

    private Node alerta(boolean stock, String titulo, String texto) {
        Circle punto = new Circle(5);
        punto.getStyleClass().add(stock ? "alerta-punto-rojo" : "alerta-punto");
        Label t = new Label(titulo);
        t.setStyle("-fx-font-weight: bold;");
        Label d = new Label(texto);
        d.getStyleClass().add("kpi-detalle");
        HBox fila = new HBox(10, punto, new VBox(1, t, d));
        fila.setAlignment(Pos.CENTER_LEFT);
        fila.getStyleClass().add("alerta-fila");
        return fila;
    }

    private Node grafico() {
        CategoryAxis x = new CategoryAxis();
        NumberAxis y = new NumberAxis();
        BarChart<String, Number> chart = new BarChart<>(x, y);
        chart.setAnimated(false);
        chart.setLegendVisible(true);
        chart.setBarGap(3);
        chart.setCategoryGap(18);
        chart.setPrefHeight(300);
        XYChart.Series<String, Number> ventas = new XYChart.Series<>();
        ventas.setName("Ventas");
        XYChart.Series<String, Number> importaciones = new XYChart.Series<>();
        importaciones.setName("Importaciones");
        LocalDate hoy = LocalDate.now().withDayOfMonth(1);
        for (int i = 5; i >= 0; i--) {
            LocalDate m = hoy.minusMonths(i);
            String etiqueta = m.getMonth().getDisplayName(TextStyle.SHORT, ES);
            ventas.getData().add(new XYChart.Data<>(etiqueta, consultas.numero(
                    "SELECT COALESCE(SUM(precio_total), 0) FROM venta WHERE EXTRACT(MONTH FROM fecha_gener) = ? "
                            + "AND EXTRACT(YEAR FROM fecha_gener) = ?", m.getMonthValue(), m.getYear())));
            importaciones.getData().add(new XYChart.Data<>(etiqueta, consultas.numero(
                    "SELECT COALESCE(SUM(precio_total), 0) FROM importacion WHERE EXTRACT(MONTH FROM fecha_imp) = ? "
                            + "AND EXTRACT(YEAR FROM fecha_imp) = ?", m.getMonthValue(), m.getYear())));
        }
        chart.getData().addAll(List.of(ventas, importaciones));
        return chart;
    }

    private void abrirTab(String titulo, Node contenido) {
        ScrollPane scrollPane = new ScrollPane(contenido);
        scrollPane.setFitToWidth(true);
        scrollPane.setFitToHeight(true);
        tabPane.getTabs().setAll(new Tab(titulo, scrollPane));
    }

    private void abrirTabPaneFXML(String fxmlPath, String titulo) {
        try {
            FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource(fxmlPath));
            fxmlLoader.setControllerFactory(AppContext.getInstance()::getBean);
            Parent root = fxmlLoader.load();
            abrirTab(titulo, root);
        } catch (IOException ex) {
            throw new RuntimeException(ex);
        }
    }

    private void cerrarSesion() {
        try {
            SessionManager.getInstance().setUserId(null);
            FXMLLoader fxmlLoader = new FXMLLoader(DzRobot.class.getResource("/view/login.fxml"));
            fxmlLoader.setControllerFactory(AppContext.getInstance()::getBean);
            Scene scene = new Scene(fxmlLoader.load());
            Tema.aplicar(scene);
            Stage stage = (Stage) tabPane.getScene().getWindow();
            stage.setTitle(Tema.NOMBRE + " - Login");
            stage.setScene(scene);
            stage.setResizable(false);
            stage.sizeToScene();
            stage.centerOnScreen();
        } catch (IOException ex) {
            throw new RuntimeException(ex);
        }
    }
}
