package pe.edu.upeu.dzrobot.modulos;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Control;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.layout.Priority;
import javafx.scene.layout.VBox;
import pe.edu.upeu.dzrobot.components.TableViewHelper;
import pe.edu.upeu.dzrobot.components.Toast;
import pe.edu.upeu.dzrobot.components.ToltipCustom;
import pe.edu.upeu.dzrobot.repository.ConsultaRepository;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class ModuloCrud {
    private final ConsultaRepository repo;
    private final String titulo;
    private final String singular;
    private final String tablaBd;
    private final String pk;
    private final List<Campo> campos;
    private final List<Columna> columnas;

    private final Map<Campo, Control> controles = new LinkedHashMap<>();
    private final ToltipCustom ttc = new ToltipCustom();
    private List<Map<String, Object>> filas = new ArrayList<>();
    private TableView<Map<String, Object>> tabla;
    private TextField filtro;
    private Object idEditando;

    public ModuloCrud(ConsultaRepository repo, String titulo, String singular, String tablaBd, String pk,
                      List<Campo> campos, List<Columna> columnas) {
        this.repo = repo;
        this.titulo = titulo;
        this.singular = singular;
        this.tablaBd = tablaBd;
        this.pk = pk;
        this.campos = campos;
        this.columnas = columnas;
    }

    public Node crear() {
        Label lblTitulo = new Label(titulo);
        lblTitulo.getStyleClass().add("titulo-modulo");
        filtro = new TextField();
        filtro.setPrefWidth(220);
        filtro.setPromptText("Buscar...");
        Pane espacio = new Pane();
        HBox.setHgrow(espacio, Priority.ALWAYS);
        HBox cabecera = new HBox(10, lblTitulo, espacio, new Label("Filtrar"), filtro);
        cabecera.setAlignment(Pos.CENTER_LEFT);
        cabecera.getStyleClass().add("panel");

        GridPane grid = new GridPane();
        grid.setHgap(6);
        grid.setVgap(5);
        grid.getColumnConstraints().addAll(new ColumnConstraints(110), new ColumnConstraints(230));
        int fila = 0;
        for (Campo c : campos) {
            if (c.seccion() != null) {
                Label s = new Label(c.seccion());
                s.getStyleClass().add("form-seccion");
                s.setMaxWidth(Double.MAX_VALUE);
                grid.add(s, 0, fila++, 2, 1);
            }
            Control control;
            if (c.opciones() != null) {
                ComboBox<String> cb = new ComboBox<>();
                cb.getItems().setAll(c.opciones());
                cb.setMaxWidth(Double.MAX_VALUE);
                control = cb;
            } else {
                control = new TextField();
            }
            controles.put(c, control);
            grid.add(new Label(c.etiqueta()), 0, fila);
            grid.add(control, 1, fila++);
        }
        Label lblForm = new Label("Registro de " + singular);
        lblForm.getStyleClass().add("form-titulo");
        Button guardar = new Button("Guardar");
        guardar.setMaxWidth(Double.MAX_VALUE);
        guardar.setOnAction(e -> guardar());
        Button cancelar = new Button("Cancelar");
        cancelar.setMaxWidth(Double.MAX_VALUE);
        cancelar.setOnAction(e -> limpiar());
        HBox.setHgrow(guardar, Priority.ALWAYS);
        HBox.setHgrow(cancelar, Priority.ALWAYS);
        VBox form = new VBox(10, lblForm, grid, new HBox(10, guardar, cancelar));
        form.getStyleClass().add("panel");
        form.setMinWidth(360);
        ScrollPane scrollForm = new ScrollPane(form);
        scrollForm.setFitToWidth(true);
        scrollForm.setFitToHeight(true);
        scrollForm.setMinWidth(390);
        scrollForm.getStyleClass().add("form-scroll");

        tabla = TablaMapa.crear(columnas);
        TableViewHelper.agregarAcciones(tabla, this::editar, this::eliminar);
        HBox.setHgrow(tabla, Priority.ALWAYS);

        HBox cuerpo = new HBox(10, scrollForm, tabla);
        VBox.setVgrow(cuerpo, Priority.ALWAYS);
        VBox raiz = new VBox(8, cabecera, cuerpo);
        raiz.setPadding(new Insets(5));
        filtro.textProperty().addListener((o, a, b) -> filtrar());
        listar();
        return raiz;
    }

    private void listar() {
        try {
            filas = repo.filas("SELECT * FROM " + tablaBd + " ORDER BY " + pk);
        } catch (RuntimeException e) {
            Toast.mostrar(tabla, e.getMessage(), Toast.Tipo.ERROR);
        }
        filtrar();
    }

    private void filtrar() {
        String f = filtro.getText() == null ? "" : filtro.getText().toLowerCase();
        tabla.getItems().setAll(filas.stream()
                .filter(m -> m.values().stream().anyMatch(v -> v != null && v.toString().toLowerCase().contains(f)))
                .toList());
    }

    private String valor(Control c) {
        if (c instanceof ComboBox<?> cb) {
            return cb.getValue() == null ? "" : cb.getValue().toString();
        }
        return ((TextField) c).getText().trim();
    }

    private void guardar() {
        controles.values().forEach(ttc::limpiarCampo);
        String primerError = null;
        List<Object> valores = new ArrayList<>();
        for (Map.Entry<Campo, Control> e : controles.entrySet()) {
            String v = valor(e.getValue());
            if (!v.matches(e.getKey().regex())) {
                ttc.marcarError(e.getValue(), e.getKey().error());
                if (primerError == null) {
                    primerError = e.getKey().error();
                }
            }
            valores.add(v);
        }
        if (primerError != null) {
            Toast.mostrar(tabla, primerError, Toast.Tipo.ERROR);
            return;
        }
        String cols = campos.stream().map(Campo::columna).collect(Collectors.joining(","));
        try {
            if (idEditando == null) {
                String marcas = campos.stream().map(c -> "?").collect(Collectors.joining(","));
                repo.ejecutar("INSERT INTO " + tablaBd + "(" + cols + ") VALUES(" + marcas + ")", valores.toArray());
                Toast.mostrar(tabla, singular.substring(0, 1).toUpperCase() + singular.substring(1) + " guardado correctamente", Toast.Tipo.OK);
            } else {
                String sets = campos.stream().map(c -> c.columna() + "=?").collect(Collectors.joining(","));
                valores.add(idEditando);
                repo.ejecutar("UPDATE " + tablaBd + " SET " + sets + " WHERE " + pk + "=?", valores.toArray());
                Toast.mostrar(tabla, singular.substring(0, 1).toUpperCase() + singular.substring(1) + " actualizado correctamente", Toast.Tipo.OK);
            }
            limpiar();
            listar();
        } catch (RuntimeException ex) {
            Toast.mostrar(tabla, ex.getMessage(), Toast.Tipo.ERROR);
        }
    }

    @SuppressWarnings("unchecked")
    private void editar(Map<String, Object> fila) {
        limpiar();
        idEditando = fila.get(pk);
        for (Map.Entry<Campo, Control> e : controles.entrySet()) {
            Object v = fila.get(e.getKey().columna());
            if (e.getValue() instanceof ComboBox<?> cb) {
                ((ComboBox<String>) cb).setValue(v == null ? null : v.toString());
            } else {
                ((TextField) e.getValue()).setText(v == null ? "" : v.toString());
            }
        }
        Toast.mostrar(tabla, "Editando " + fila.get(campos.get(1).columna()), Toast.Tipo.INFO);
    }

    private void eliminar(Map<String, Object> fila) {
        Alert a = new Alert(Alert.AlertType.CONFIRMATION, "¿Eliminar " + singular + " " + fila.get(campos.get(1).columna()) + "?",
                ButtonType.YES, ButtonType.NO);
        if (a.showAndWait().orElse(ButtonType.NO) != ButtonType.YES) {
            return;
        }
        try {
            repo.ejecutar("DELETE FROM " + tablaBd + " WHERE " + pk + "=?", fila.get(pk));
            Toast.mostrar(tabla, "Eliminado correctamente", Toast.Tipo.OK);
            listar();
        } catch (RuntimeException ex) {
            Toast.mostrar(tabla, "No se puede eliminar: tiene registros relacionados", Toast.Tipo.ERROR);
        }
    }

    private void limpiar() {
        idEditando = null;
        controles.values().forEach(c -> {
            ttc.limpiarCampo(c);
            if (c instanceof ComboBox<?> cb) {
                cb.getSelectionModel().clearSelection();
            } else {
                ((TextField) c).clear();
            }
        });
    }
}
