package pe.edu.upeu.dzrobot.model;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import pe.edu.upeu.dzrobot.enums.TipoProducto;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class VentCarrito {
    private Long idCarrito;
    @NotBlank(message = "Elija primero el cliente")
    private String dniruc;
    @NotNull(message = "Elija un producto")
    private TipoProducto tipoProducto;
    private Long idRobot;
    private Long idRepuesto;
    @NotBlank(message = "Elija un producto")
    private String nombreProducto;
    @NotNull(message = "La cantidad es obligatoria")
    @Positive(message = "La cantidad debe ser mayor a 0")
    private Double cantidad;
    @NotNull(message = "El precio es obligatorio")
    @Positive(message = "El precio debe ser mayor a 0")
    private Double punitario;
    private Double ptotal;
    private Integer estado;
    private Long idUsuario;

    public Long getIdProducto() {
        return tipoProducto == TipoProducto.ROBOT ? idRobot : idRepuesto;
    }
}
