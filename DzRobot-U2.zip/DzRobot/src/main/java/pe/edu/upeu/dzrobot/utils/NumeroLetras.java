package pe.edu.upeu.dzrobot.utils;

import java.math.BigDecimal;
import java.math.RoundingMode;

public final class NumeroLetras {
    private static final String[] UNIDADES = {"", "UNO", "DOS", "TRES", "CUATRO", "CINCO", "SEIS", "SIETE", "OCHO", "NUEVE",
            "DIEZ", "ONCE", "DOCE", "TRECE", "CATORCE", "QUINCE", "DIECISEIS", "DIECISIETE", "DIECIOCHO", "DIECINUEVE",
            "VEINTE", "VEINTIUNO", "VEINTIDOS", "VEINTITRES", "VEINTICUATRO", "VEINTICINCO", "VEINTISEIS", "VEINTISIETE",
            "VEINTIOCHO", "VEINTINUEVE"};
    private static final String[] DECENAS = {"", "", "", "TREINTA", "CUARENTA", "CINCUENTA", "SESENTA", "SETENTA", "OCHENTA", "NOVENTA"};
    private static final String[] CENTENAS = {"", "CIENTO", "DOSCIENTOS", "TRESCIENTOS", "CUATROCIENTOS", "QUINIENTOS",
            "SEISCIENTOS", "SETECIENTOS", "OCHOCIENTOS", "NOVECIENTOS"};

    private NumeroLetras() {
    }

    public static String soles(BigDecimal monto) {
        BigDecimal m = monto.setScale(2, RoundingMode.HALF_UP);
        long entero = m.longValue();
        int centimos = m.subtract(BigDecimal.valueOf(entero)).movePointRight(2).intValue();
        String letras = entero == 0 ? "CERO" : convertir(entero);
        return letras + " CON " + String.format("%02d", centimos) + "/100 SOLES";
    }

    static String convertir(long n) {
        if (n >= 1_000_000) {
            long millones = n / 1_000_000;
            String texto = millones == 1 ? "UN MILLON" : convertir(millones) + " MILLONES";
            return n % 1_000_000 == 0 ? texto : texto + " " + convertir(n % 1_000_000);
        }
        if (n >= 1000) {
            long miles = n / 1000;
            String texto = miles == 1 ? "MIL" : convertir(miles) + " MIL";
            return n % 1000 == 0 ? texto : texto + " " + convertir(n % 1000);
        }
        if (n >= 100) {
            if (n == 100) {
                return "CIEN";
            }
            return n % 100 == 0 ? CENTENAS[(int) (n / 100)] : CENTENAS[(int) (n / 100)] + " " + convertir(n % 100);
        }
        if (n >= 30) {
            return n % 10 == 0 ? DECENAS[(int) (n / 10)] : DECENAS[(int) (n / 10)] + " Y " + UNIDADES[(int) (n % 10)];
        }
        return UNIDADES[(int) n];
    }
}
