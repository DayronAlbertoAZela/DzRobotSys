package pe.edu.upeu.dzrobot.service;

import pe.edu.upeu.dzrobot.dto.ComboBoxOption;
import pe.edu.upeu.dzrobot.model.Repuesto;

import java.util.List;

public interface IRepuestoService extends ICrudGenericoService<Repuesto, Long> {
    List<ComboBoxOption> listarTipoRepuesto();

    List<Repuesto> listarStockBajo();
}
