package pe.edu.upeu.dzrobot.model;

import java.time.LocalDate;

public interface Mantenible {
    LocalDate calcularProximoMantenimiento();

    boolean necesitaMantenimiento();
}
