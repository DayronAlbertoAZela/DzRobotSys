package pe.edu.upeu.dzrobot.enums;

public enum TipoDocumento {
    DNI, RUC
}
