package pe.edu.upeu.dzrobot.model;

import jakarta.validation.constraints.*;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;
import pe.edu.upeu.dzrobot.enums.EstadoRobot;
import pe.edu.upeu.dzrobot.enums.TipoRobot;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

@Data
@NoArgsConstructor
@SuperBuilder
public abstract class Robot implements Mantenible {
    private Long idRobot;
    @NotBlank(message = "El código es obligatorio")
    @Pattern(regexp = "[A-Z0-9-]{3,20}", message = "Código: mayúsculas, números y guiones (3 a 20)")
    private String codigo;
    @NotBlank(message = "El nombre es obligatorio")
    private String nombre;
    @NotBlank(message = "El modelo es obligatorio")
    private String modelo;
    @NotNull(message = "La fecha de adquisición es obligatoria")
    @PastOrPresent(message = "La fecha de adquisición no puede ser futura")
    private LocalDate fechaAdq;
    private LocalDate fechaUltMant;
    @NotNull(message = "El estado es obligatorio")
    private EstadoRobot estado;
    @NotNull(message = "El precio es obligatorio")
    @Positive(message = "El precio debe ser positivo")
    private Double pu;
    @NotNull(message = "La utilidad es obligatoria")
    @PositiveOrZero(message = "La utilidad no puede ser negativa")
    private Double utilidad;
    @NotNull(message = "La marca es obligatoria")
    private Marca idMarca;
    private Cliente dniruc;
    @Builder.Default
    private List<Componente> componentes = new ArrayList<>();

    public abstract TipoRobot getTipoRobot();

    public abstract String getDetalleTecnico();

    @Override
    public abstract LocalDate calcularProximoMantenimiento();

    @Override
    public boolean necesitaMantenimiento() {
        if (!LocalDate.now().isBefore(calcularProximoMantenimiento())) return true;
        return componentes.stream().anyMatch(Componente::necesitaMantenimiento);
    }

    protected LocalDate getFechaBase() {
        return fechaUltMant != null ? fechaUltMant : fechaAdq;
    }

    public double getPrecioVenta() {
        return Math.round((pu + pu * utilidad) * 100.0) / 100.0;
    }

    public LocalDate getProximoMantenimiento() {
        return calcularProximoMantenimiento();
    }

    public String getAlerta() {
        return necesitaMantenimiento() ? "⚠ SÍ" : "No";
    }
}
