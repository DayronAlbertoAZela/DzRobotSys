package pe.edu.upeu.dzrobot.repository;

import pe.edu.upeu.dzrobot.enums.TipoRepuesto;
import pe.edu.upeu.dzrobot.model.Marca;
import pe.edu.upeu.dzrobot.model.Repuesto;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.Optional;

public class RepuestoRepository extends AbstractJpaRepository<Repuesto, Long> {
    private static final String SELECT_JOIN =
            "SELECT r.*, m.nombre AS mar_nombre FROM producto r " +
                    "JOIN marca m ON r.id_marca = m.id_marca " +
                    "WHERE r.tipo NOT IN ('INDUSTRIAL', 'MOVIL', 'EDUCATIVO') ";

    @Override
    protected String getTableName() {return "producto";}

    @Override
    protected String getPkColumn() {return "id_producto";}

    @Override
    public List<Repuesto> findAll() {return executeQuery(SELECT_JOIN + "ORDER BY r.codigo");}

    @Override
    public Optional<Repuesto> findById(Long id) {
        return executeQueryOne(SELECT_JOIN + "AND r.id_producto = ?", id);
    }

    public List<Repuesto> listarStockBajo(double minimo) {
        return executeQuery(SELECT_JOIN + "AND r.stock <= ?", minimo);
    }

    @Override
    protected Repuesto mapRow(ResultSet rs) throws SQLException {
        return Repuesto.builder()
                .idRepuesto(rs.getLong("id_producto"))
                .codigo(rs.getString("codigo"))
                .modelo(rs.getString("modelo"))
                .nombre(rs.getString("nombre"))
                .tipoRepuesto(TipoRepuesto.valueOf(rs.getString("tipo")))
                .pu(rs.getDouble("pu"))
                .utilidad(rs.getDouble("utilidad"))
                .stock(rs.getDouble("stock"))
                .vidaUtil(rs.getDouble("vida_util"))
                .idMarca(Marca.builder()
                        .idMarca(rs.getLong("id_marca"))
                        .nombre(rs.getString("mar_nombre")).build())
                .build();
    }

    @Override
    protected Repuesto insert(Connection conn, Repuesto e) throws SQLException {
        long id = executeInsertGetKey(conn,
                "INSERT INTO producto(codigo,nombre,modelo,tipo,fecha_adq,fecha_ult_mant,estado,pu,utilidad,id_marca,vida_util,stock) "
                        + "VALUES(?,?,?,?,CURRENT_DATE,CURRENT_DATE,?,?,?,?,?,?)",
                e.getCodigo(), e.getNombre(), e.getModelo(), e.getTipoRepuesto().name(), estado(e), e.getPu(),
                e.getUtilidad(), e.getIdMarca().getIdMarca(), e.getVidaUtil(), e.getStock());
        e.setIdRepuesto(id);
        return e;
    }

    @Override
    protected Repuesto updateRow(Connection conn, Repuesto e) throws SQLException {
        executeUpdate(conn,
                "UPDATE producto SET codigo=?,nombre=?,modelo=?,tipo=?,estado=?,pu=?,utilidad=?,stock=?,vida_util=?,id_marca=? "
                        + "WHERE id_producto=?",
                e.getCodigo(), e.getNombre(), e.getModelo(), e.getTipoRepuesto().name(), estado(e), e.getPu(),
                e.getUtilidad(), e.getStock(), e.getVidaUtil(), e.getIdMarca().getIdMarca(), e.getIdRepuesto());
        return e;
    }

    private String estado(Repuesto e) {
        return e.getStock() > 0 ? "EN_STOCK" : "AGOTADO";
    }
}
