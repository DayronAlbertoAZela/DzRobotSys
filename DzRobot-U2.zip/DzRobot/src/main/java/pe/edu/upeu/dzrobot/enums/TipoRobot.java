package pe.edu.upeu.dzrobot.enums;

import lombok.Getter;

@Getter
public enum TipoRobot {
    INDUSTRIAL("Industrial"),
    MOVIL("Móvil"),
    EDUCATIVO("Educativo");

    private final String descripcion;

    TipoRobot(String descripcion) {
        this.descripcion = descripcion;
    }

    @Override
    public String toString() {
        return descripcion;
    }
}
