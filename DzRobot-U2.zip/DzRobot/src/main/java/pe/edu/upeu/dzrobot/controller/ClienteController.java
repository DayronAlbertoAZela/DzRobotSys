package pe.edu.upeu.dzrobot.controller;

import jakarta.validation.ConstraintViolation;
import jakarta.validation.Validation;
import jakarta.validation.Validator;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import lombok.RequiredArgsConstructor;
import pe.edu.upeu.dzrobot.components.ColumnInfo;
import pe.edu.upeu.dzrobot.components.TableViewHelper;
import pe.edu.upeu.dzrobot.components.Toast;
import pe.edu.upeu.dzrobot.components.ToltipCustom;
import pe.edu.upeu.dzrobot.dto.ComboBoxOption;
import pe.edu.upeu.dzrobot.enums.TipoDocumento;
import pe.edu.upeu.dzrobot.model.Cliente;
import pe.edu.upeu.dzrobot.service.IClienteService;

import java.util.*;

import static pe.edu.upeu.dzrobot.components.FormHelper.*;

@RequiredArgsConstructor
public class ClienteController {
    private final IClienteService cs;

    @FXML TextField txtDniRuc, txtNombres, txtRepLegal, txtDireccion, txtCelular, txtFiltroDato;
    @FXML ComboBox<ComboBoxOption> cbxTipoDocumento;
    @FXML TableView<Cliente> tableView;
    @FXML Label lbnMsg;
    @FXML AnchorPane miContenedor;

    private Validator validator;
    private final ToltipCustom ttc = new ToltipCustom();
    private List<Cliente> clientes = new ArrayList<>();
    private boolean editando;

    @FXML
    public void initialize() {
        validator = Validation.buildDefaultValidatorFactory().getValidator();
        Arrays.stream(TipoDocumento.values()).forEach(t -> cbxTipoDocumento.getItems().add(new ComboBoxOption(t.name(), t.name())));

        txtDniRuc.textProperty().addListener((obs, o, n) -> {
            if (n != null && n.length() == 11) seleccionar(cbxTipoDocumento, "RUC");
            else if (n != null && n.length() == 8) seleccionar(cbxTipoDocumento, "DNI");
        });

        LinkedHashMap<String, ColumnInfo> columns = new LinkedHashMap<>();
        columns.put("DNI/RUC", new ColumnInfo("dniruc", 100.0));
        columns.put("Tipo", new ColumnInfo("tipoDocumento", 50.0));
        columns.put("Nombres / Razón social", new ColumnInfo("nombres", 200.0));
        columns.put("Rep. legal", new ColumnInfo("repLegal", 150.0));
        columns.put("Dirección", new ColumnInfo("direccion", 200.0));
        columns.put("Celular", new ColumnInfo("celular", 100.0));
        new TableViewHelper<Cliente>().addColumnsInOrderWithSize(tableView, columns, this::editForm, this::eliminar);
        TableViewHelper.pildoras(tableView, "Tipo", v -> "RUC".equals(v) ? "morado" : "celeste");

        txtFiltroDato.textProperty().addListener((obs, o, n) -> filtrar());
        listar();
    }

    public void listar() {
        try {
            clientes = cs.findAll();
            filtrar();
        } catch (RuntimeException e) {
            mensaje(e.getMessage(), false);
        }
    }

    private void filtrar() {
        String f = txtFiltroDato.getText() == null ? "" : txtFiltroDato.getText().toLowerCase();
        tableView.getItems().setAll(clientes.stream()
                .filter(c -> c.getDniruc().contains(f) || c.getNombres().toLowerCase().contains(f)).toList());
    }

    @FXML
    public void validarFormulario() {
        limpiarError();
        String tipo = key(cbxTipoDocumento);
        Cliente formulario = Cliente.builder()
                .dniruc(txtDniRuc.getText().trim())
                .nombres(txtNombres.getText())
                .repLegal(txtRepLegal.getText())
                .direccion(txtDireccion.getText())
                .tipoDocumento(tipo == null ? null : TipoDocumento.valueOf(tipo))
                .celular(txtCelular.getText().trim())
                .build();

        List<ConstraintViolation<Cliente>> violaciones = validator.validate(formulario).stream()
                .sorted(Comparator.comparing(v -> v.getPropertyPath().toString())).toList();
        if (!violaciones.isEmpty()) {
            mostrarErroresValidacion(violaciones);
            return;
        }
        Stage stage = (Stage) miContenedor.getScene().getWindow();
        double w = stage.getWidth() / 1.5, h = stage.getHeight() / 2;
        try {
            if (editando) {
                cs.update(formulario.getDniruc(), formulario);
                Toast.showToast(stage, "Actualizado correctamente", 2000, w, h);
            } else {
                cs.save(formulario);
                Toast.showToast(stage, "Guardado correctamente", 2000, w, h);
            }
            clearForm();
            listar();
        } catch (RuntimeException ex) {
            mensaje(ex.getMessage(), false);
        }
    }

    private void eliminar(Cliente c) {
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION, "¿Eliminar a " + c.getNombres() + "?", ButtonType.YES, ButtonType.NO);
        if (alert.showAndWait().orElse(ButtonType.NO) != ButtonType.YES) return;
        try {
            cs.delete(c.getDniruc());
            listar();
            mensaje("Se eliminó " + c.getNombres(), true);
        } catch (RuntimeException ex) {
            mensaje("No se puede eliminar: el cliente tiene ventas o robots registrados", false);
        }
    }

    public void editForm(Cliente c) {
        clearForm();
        editando = true;
        txtDniRuc.setText(c.getDniruc());
        txtDniRuc.setDisable(true);
        txtNombres.setText(c.getNombres());
        txtRepLegal.setText(c.getRepLegal());
        txtDireccion.setText(c.getDireccion());
        txtCelular.setText(c.getCelular());
        seleccionar(cbxTipoDocumento, c.getTipoDocumento().name());
        mensaje("Editando " + c.getNombres(), true);
    }

    @FXML
    public void clearForm() {
        editando = false;
        txtDniRuc.setDisable(false);
        List.of(txtDniRuc, txtNombres, txtRepLegal, txtDireccion, txtCelular).forEach(TextInputControl::clear);
        cbxTipoDocumento.getSelectionModel().clearSelection();
        limpiarError();
        lbnMsg.setText("");
    }

    private void mostrarErroresValidacion(List<ConstraintViolation<Cliente>> violaciones) {
        Map<String, Control> campos = new LinkedHashMap<>();
        campos.put("dniruc", txtDniRuc);
        campos.put("nombres", txtNombres);
        campos.put("repLegal", txtRepLegal);
        campos.put("direccion", txtDireccion);
        campos.put("tipoDocumento", cbxTipoDocumento);
        campos.put("celular", txtCelular);
        String primero = null;
        for (Map.Entry<String, Control> c : campos.entrySet()) {
            for (ConstraintViolation<Cliente> v : violaciones) {
                if (v.getPropertyPath().toString().equals(c.getKey())) {
                    ttc.marcarError(c.getValue(), v.getMessage());
                    if (primero == null) primero = v.getMessage();
                }
            }
        }
        mensaje(primero, false);
    }

    private void mensaje(String texto, boolean ok) {
        if (miContenedor.getScene() == null) {
            lbnMsg.setText(texto);
            return;
        }
        lbnMsg.setText("");
        Toast.Tipo tipo = !ok ? Toast.Tipo.ERROR
                : texto != null && texto.startsWith("Editando") ? Toast.Tipo.INFO : Toast.Tipo.OK;
        Toast.mostrar(miContenedor, texto, tipo);
    }

    private void limpiarError() {
        List.of(txtDniRuc, txtNombres, txtRepLegal, txtDireccion, cbxTipoDocumento, txtCelular).forEach(ttc::limpiarCampo);
    }
}
