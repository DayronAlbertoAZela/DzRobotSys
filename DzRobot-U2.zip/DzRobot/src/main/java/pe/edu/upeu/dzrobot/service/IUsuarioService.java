package pe.edu.upeu.dzrobot.service;

import pe.edu.upeu.dzrobot.model.Usuario;

import java.util.Optional;

public interface IUsuarioService extends ICrudGenericoService<Usuario, Long> {
    Optional<Usuario> loginUsuario(String usuario, String clave);
}
