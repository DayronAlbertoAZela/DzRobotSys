package pe.edu.upeu.dzrobot.service.impl;

import lombok.RequiredArgsConstructor;
import pe.edu.upeu.dzrobot.dto.ComboBoxOption;
import pe.edu.upeu.dzrobot.enums.TipoRepuesto;
import pe.edu.upeu.dzrobot.model.Repuesto;
import pe.edu.upeu.dzrobot.repository.ICrudGenericoRepository;
import pe.edu.upeu.dzrobot.repository.RepuestoRepository;
import pe.edu.upeu.dzrobot.service.IRepuestoService;

import java.util.Arrays;
import java.util.List;

@RequiredArgsConstructor
public class RepuestoServiceImp extends CrudGenericoServiceImp<Repuesto, Long> implements IRepuestoService {
    public static final double STOCK_MINIMO = 5;

    private final RepuestoRepository repuestoRepository;

    @Override
    protected ICrudGenericoRepository<Repuesto, Long> getRepo() {
        return repuestoRepository;
    }

    @Override
    public List<ComboBoxOption> listarTipoRepuesto() {
        return Arrays.stream(TipoRepuesto.values())
                .map(t -> new ComboBoxOption(t.name(), t.name()))
                .toList();
    }

    @Override
    public List<Repuesto> listarStockBajo() {
        return repuestoRepository.listarStockBajo(STOCK_MINIMO);
    }
}
