package pe.edu.upeu.dzrobot.service;

import pe.edu.upeu.dzrobot.enums.TipoProducto;
import pe.edu.upeu.dzrobot.model.VentCarrito;

import java.util.List;

public interface IVentCarritoService extends ICrudGenericoService<VentCarrito, Long> {
    VentCarrito agregar(String dniruc, TipoProducto tipo, Long idProducto, double cantidad, Long idUsuario);

    List<VentCarrito> listarPorCliente(String dniruc);

    double total(String dniruc);

    void vaciar(String dniruc);
}
