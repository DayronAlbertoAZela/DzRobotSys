package pe.edu.upeu.dzrobot.modulos;

import javafx.beans.property.SimpleObjectProperty;
import javafx.scene.control.Label;
import javafx.scene.control.TableCell;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;

import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.util.List;
import java.util.Locale;
import java.util.Map;

final class TablaMapa {
    static final DecimalFormat SOLES = new DecimalFormat("S/ #,##0.00", DecimalFormatSymbols.getInstance(Locale.US));
    private static final DecimalFormat NUM = new DecimalFormat("#,##0.##", DecimalFormatSymbols.getInstance(Locale.US));

    private TablaMapa() {
    }

    static TableView<Map<String, Object>> crear(List<Columna> columnas) {
        TableView<Map<String, Object>> tabla = new TableView<>();
        for (Columna c : columnas) {
            TableColumn<Map<String, Object>, Object> col = new TableColumn<>(c.titulo());
            col.setPrefWidth(c.ancho());
            col.setCellValueFactory(f -> new SimpleObjectProperty<>(f.getValue().get(c.clave())));
            col.setCellFactory(x -> new TableCell<>() {
                @Override
                protected void updateItem(Object item, boolean empty) {
                    super.updateItem(item, empty);
                    setGraphic(null);
                    setText(null);
                    if (empty || item == null) {
                        return;
                    }
                    switch (c.tipo()) {
                        case MONEDA -> setText(SOLES.format(((Number) item).doubleValue()));
                        case NUMERO -> setText(NUM.format(((Number) item).doubleValue()));
                        case PILDORA -> {
                            Label p = new Label(item.toString().replace('_', ' '));
                            p.getStyleClass().addAll("pildora", "pildora-" + c.color().apply(item.toString()));
                            setGraphic(p);
                        }
                        default -> setText(item.toString());
                    }
                }
            });
            tabla.getColumns().add(col);
        }
        tabla.setPlaceholder(new Label("Sin registros"));
        return tabla;
    }
}
