package pe.edu.upeu.dzrobot.componentes;

import javafx.scene.Scene;
import javafx.scene.text.Font;
import pe.edu.upeu.dzrobot.DzRobot;

public final class Tema {

    public static final String NOMBRE = "DzRobot";
    public static final String VERSION = "2.0";

    private Tema() {
    }

    public static void cargarFuentes() {
        for (String f : new String[]{"Inter-Regular.otf", "Inter-SemiBold.otf", "Inter-Bold.otf"}) {
            Font.loadFont(DzRobot.class.getResourceAsStream("/fonts/" + f), 13);
        }
    }

    public static void aplicar(Scene scene) {
        scene.getStylesheets().setAll(DzRobot.class.getResource("/css/dzrobot.css").toExternalForm());
    }
}
