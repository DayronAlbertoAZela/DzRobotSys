package pe.edu.upeu.dzrobot.enums;

public enum TipoRepuesto {
    MOTOR, SENSOR, BATERIA, CONTROLADOR
}
