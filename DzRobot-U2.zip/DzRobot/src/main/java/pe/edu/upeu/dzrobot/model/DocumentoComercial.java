package pe.edu.upeu.dzrobot.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public abstract class DocumentoComercial {
    public static final double TASA_IGV = 0.18;

    private Long id;
    private double precioBase;
    private double igv;
    private double precioTotal;
    private String serie;
    private String numDoc;
    private String tipoDoc;

    public abstract double calcularTotal();

    protected static double redondear(double v) {
        return Math.round(v * 100.0) / 100.0;
    }
}
