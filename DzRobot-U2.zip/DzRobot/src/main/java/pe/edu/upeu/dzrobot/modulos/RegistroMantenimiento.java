package pe.edu.upeu.dzrobot.modulos;

import javafx.beans.property.SimpleObjectProperty;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.TableCell;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.layout.Priority;
import javafx.scene.layout.VBox;
import pe.edu.upeu.dzrobot.components.Toast;
import pe.edu.upeu.dzrobot.dto.SessionManager;
import pe.edu.upeu.dzrobot.operaciones.LineaMantenimiento;
import pe.edu.upeu.dzrobot.operaciones.OperacionRepository;
import pe.edu.upeu.dzrobot.repository.ConsultaRepository;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;
import java.util.function.Function;

public class RegistroMantenimiento {

    private final ConsultaRepository consultas;
    private final OperacionRepository operaciones = new OperacionRepository();

    private final ComboBox<Opcion> cbRobot = new ComboBox<>();
    private final ComboBox<Opcion> cbTecnico = new ComboBox<>();
    private final ComboBox<String> cbTipo = new ComboBox<>();
    private final ComboBox<String> cbEstado = new ComboBox<>();
    private final DatePicker dpFecha = new DatePicker(LocalDate.now());
    private final TextField txtDescripcion = new TextField();
    private final TextField txtManoObra = new TextField("0");
    private final ComboBox<Opcion> cbComponente = new ComboBox<>();
    private final ComboBox<String> cbAccion = new ComboBox<>();
    private final TextField txtObservacion = new TextField();
    private final TextField txtCosto = new TextField("0");
    private final TableView<LineaMantenimiento> tabla = new TableView<>();
    private final Label lblTotal = new Label();
    private final Label lblFallas = new Label();

    public RegistroMantenimiento(ConsultaRepository consultas) {
        this.consultas = consultas;
    }

    public Node crear() {
        Label titulo = new Label("Registrar mantenimiento");
        titulo.getStyleClass().add("titulo-modulo");

        cbRobot.setPrefWidth(280);
        cbRobot.valueProperty().addListener((o, a, b) -> {
            tabla.getItems().clear();
            mostrarFallas();
            cargarComponentes();
            actualizarTotal();
        });
        cbTecnico.setPrefWidth(300);
        cbTipo.getItems().addAll("PREVENTIVO", "CORRECTIVO");
        cbTipo.setValue("PREVENTIVO");
        cbEstado.getItems().addAll("PENDIENTE", "EN_PROCESO", "FINALIZADO");
        cbEstado.setValue("EN_PROCESO");
        txtDescripcion.setPromptText("Qué se hará o se hizo");
        txtDescripcion.setPrefWidth(280);
        txtManoObra.setPrefWidth(100);
        txtManoObra.setMaxWidth(120);
        txtManoObra.textProperty().addListener((o, a, b) -> actualizarTotal());

        GridPane cabecera = new GridPane();
        cabecera.setHgap(10);
        cabecera.setVgap(8);
        cabecera.addRow(0, new Label("Robot"), cbRobot, new Label("Técnico"), cbTecnico);
        cabecera.addRow(1, new Label("Tipo"), cbTipo, new Label("Fecha"), dpFecha);
        cabecera.addRow(2, new Label("Descripción"), txtDescripcion, new Label("Mano de obra"), txtManoObra);
        cabecera.addRow(3, new Label("Estado"), cbEstado, new Label("Fallas"), lblFallas);
        lblFallas.getStyleClass().add("texto-suave");
        cabecera.getStyleClass().add("panel");

        cbComponente.setPrefWidth(260);
        cbAccion.getItems().addAll("REVISADO", "REPARADO", "REEMPLAZADO");
        cbAccion.setValue("REVISADO");
        txtObservacion.setPrefWidth(220);
        txtCosto.setPrefWidth(90);
        Button btnAgregar = new Button("Agregar");
        btnAgregar.getStyleClass().add("btn-primario");
        btnAgregar.setOnAction(e -> agregar());
        HBox linea = new HBox(8, new Label("Componente"), cbComponente, cbAccion,
                new Label("Observación"), txtObservacion, new Label("Costo"), txtCosto, btnAgregar);
        linea.setAlignment(Pos.CENTER_LEFT);
        linea.getStyleClass().add("panel");

        armarTabla();
        VBox.setVgrow(tabla, Priority.ALWAYS);

        Button btnGuardar = new Button("Registrar mantenimiento");
        btnGuardar.getStyleClass().add("btn-primario");
        btnGuardar.setOnAction(e -> guardar());
        Button btnLimpiar = new Button("Limpiar");
        btnLimpiar.setOnAction(e -> limpiar());
        lblTotal.getStyleClass().add("total-importe");
        Pane espacio = new Pane();
        HBox.setHgrow(espacio, Priority.ALWAYS);
        HBox pie = new HBox(18, new Label("Costo total:"), lblTotal, espacio, btnLimpiar, btnGuardar);
        pie.setAlignment(Pos.CENTER_LEFT);
        pie.getStyleClass().add("panel");

        VBox raiz = new VBox(10, titulo, cabecera, linea, tabla, pie);
        raiz.setPadding(new Insets(10));

        cargarRobots();
        cargarTecnicos();
        actualizarTotal();
        return raiz;
    }

    private void armarTabla() {
        tabla.getColumns().add(columna("Componente", 240, LineaMantenimiento::getComponente));
        tabla.getColumns().add(columna("Acción", 120, LineaMantenimiento::getAccion));
        tabla.getColumns().add(columna("Observación", 280, LineaMantenimiento::getObservacion));
        tabla.getColumns().add(columna("Costo", 110, l -> TablaMapa.SOLES.format(l.getCosto())));
        TableColumn<LineaMantenimiento, Void> quitar = new TableColumn<>("");
        quitar.setPrefWidth(90);
        quitar.setCellFactory(x -> new TableCell<>() {
            private final Button boton = new Button("Quitar");

            {
                boton.getStyleClass().add("btn-peligro");
                boton.setOnAction(e -> {
                    tabla.getItems().remove(getIndex());
                    actualizarTotal();
                });
            }

            @Override
            protected void updateItem(Void item, boolean empty) {
                super.updateItem(item, empty);
                setGraphic(empty ? null : boton);
            }
        });
        tabla.getColumns().add(quitar);
        tabla.setPlaceholder(new Label("Agregue los componentes revisados (opcional)"));
    }

    private TableColumn<LineaMantenimiento, String> columna(String titulo, double ancho,
                                                           Function<LineaMantenimiento, String> valor) {
        TableColumn<LineaMantenimiento, String> col = new TableColumn<>(titulo);
        col.setPrefWidth(ancho);
        col.setCellValueFactory(f -> new SimpleObjectProperty<>(valor.apply(f.getValue())));
        return col;
    }

    private void mostrarFallas() {
        Opcion robot = cbRobot.getValue();
        if (robot == null) {
            lblFallas.setText("");
            return;
        }
        int abiertas = (int) consultas.numero("SELECT COUNT(*) FROM falla WHERE id_producto = ? AND estado <> 'RESUELTA'", robot.id());
        lblFallas.setText(abiertas == 0 ? "Sin fallas pendientes"
                : abiertas == 1 ? "1 falla pendiente se ligará a este mantenimiento"
                : abiertas + " fallas pendientes se ligarán a este mantenimiento");
    }

    private void cargarRobots() {
        cbRobot.getItems().clear();
        for (Map<String, Object> f : consultas.filas(
                "SELECT id_producto, codigo, nombre, estado, dniruc FROM producto WHERE tipo IN ('INDUSTRIAL', 'MOVIL', 'EDUCATIVO') AND estado <> 'DE_BAJA' ORDER BY codigo")) {
            cbRobot.getItems().add(new Opcion(f.get("id_producto"),
                    f.get("codigo") + " " + f.get("nombre") + " [" + String.valueOf(f.get("estado")).replace('_', ' ') + "]",
                    0, f.get("dniruc") == null ? null : f.get("dniruc").toString()));
        }
    }

    private void cargarTecnicos() {
        cbTecnico.getItems().clear();
        for (Map<String, Object> f : consultas.filas("SELECT id_tecnico, nombres, especialidad FROM tecnico ORDER BY nombres")) {
            cbTecnico.getItems().add(new Opcion(f.get("id_tecnico"),
                    f.get("nombres") + " - " + f.get("especialidad"), 0, null));
        }
    }

    private void cargarComponentes() {
        cbComponente.getItems().clear();
        Opcion robot = cbRobot.getValue();
        if (robot == null) {
            return;
        }
        for (Map<String, Object> f : consultas.filas(
                "SELECT c.id_componente, c.num_serie, c.id_repuesto, p.nombre, c.horas_uso, p.stock FROM componente c "
                        + "JOIN producto p ON p.id_producto = c.id_repuesto WHERE c.id_producto = ? ORDER BY c.num_serie", robot.id())) {
            cbComponente.getItems().add(new Opcion(f.get("id_componente"),
                    f.get("num_serie") + " " + f.get("nombre") + " (" + ((Number) f.get("horas_uso")).intValue() + " h)",
                    ((Number) f.get("stock")).doubleValue(), f.get("id_repuesto").toString()));
        }
        cbComponente.setPromptText(cbComponente.getItems().isEmpty() ? "Sin componentes" : "Elija");
    }

    private void agregar() {
        Opcion c = cbComponente.getValue();
        if (c == null) {
            Toast.mostrar(tabla, "Elija un componente", Toast.Tipo.ERROR);
            return;
        }
        if (tabla.getItems().stream().anyMatch(l -> l.idComponente().equals(c.id()))) {
            Toast.mostrar(tabla, "Ese componente ya está en la lista", Toast.Tipo.ERROR);
            return;
        }
        if ("REEMPLAZADO".equals(cbAccion.getValue()) && c.stock() < 1) {
            Toast.mostrar(tabla, "No hay stock del repuesto para reemplazarlo", Toast.Tipo.ERROR);
            return;
        }
        double costo;
        try {
            costo = Double.parseDouble(txtCosto.getText().trim());
        } catch (NumberFormatException e) {
            Toast.mostrar(tabla, "El costo debe ser un número", Toast.Tipo.ERROR);
            return;
        }
        if (costo < 0) {
            Toast.mostrar(tabla, "El costo no puede ser negativo", Toast.Tipo.ERROR);
            return;
        }
        String observacion = txtObservacion.getText().trim().isEmpty() ? "-" : txtObservacion.getText().trim();
        tabla.getItems().add(new LineaMantenimiento(c.id(), Integer.valueOf(c.extra()), c.texto(),
                cbAccion.getValue(), observacion, costo));
        txtObservacion.clear();
        txtCosto.setText("0");
        cbComponente.setValue(null);
        actualizarTotal();
    }

    private double manoObra() {
        try {
            return Double.parseDouble(txtManoObra.getText().trim());
        } catch (NumberFormatException e) {
            return -1;
        }
    }

    private void actualizarTotal() {
        double mano = Math.max(manoObra(), 0);
        lblTotal.setText(TablaMapa.SOLES.format(mano + tabla.getItems().stream().mapToDouble(LineaMantenimiento::getCosto).sum()));
    }

    private void guardar() {
        Opcion robot = cbRobot.getValue();
        if (robot == null || cbTecnico.getValue() == null) {
            Toast.mostrar(tabla, "Elija el robot y el técnico", Toast.Tipo.ERROR);
            return;
        }
        String descripcion = txtDescripcion.getText().trim();
        if (descripcion.length() < 5 || descripcion.length() > 100) {
            Toast.mostrar(tabla, "La descripción debe tener de 5 a 100 caracteres", Toast.Tipo.ERROR);
            return;
        }
        if (manoObra() < 0) {
            Toast.mostrar(tabla, "La mano de obra debe ser un número positivo", Toast.Tipo.ERROR);
            return;
        }
        if (dpFecha.getValue() == null) {
            Toast.mostrar(tabla, "Elija la fecha", Toast.Tipo.ERROR);
            return;
        }
        try {
            long id = operaciones.registrarMantenimiento(robot.id(), cbTecnico.getValue().id(), cbTipo.getValue(),
                    dpFecha.getValue(), descripcion, manoObra(), cbEstado.getValue(),
                    SessionManager.getInstance().getUserId(), robot.extra() != null, List.copyOf(tabla.getItems()));
            Toast.mostrar(tabla, "Mantenimiento N° " + id + " registrado", Toast.Tipo.OK);
            limpiar();
        } catch (RuntimeException e) {
            Toast.mostrar(tabla, e.getMessage(), Toast.Tipo.ERROR);
        }
    }

    private void limpiar() {
        tabla.getItems().clear();
        txtDescripcion.clear();
        txtManoObra.setText("0");
        dpFecha.setValue(LocalDate.now());
        cbEstado.setValue("EN_PROCESO");
        cbRobot.setValue(null);
        cargarRobots();
        actualizarTotal();
    }
}
