package pe.edu.upeu.dzrobot.enums;

public enum TipoProducto {
    ROBOT, REPUESTO
}
