package pe.edu.upeu.dzrobot.components;

import javafx.beans.property.SimpleObjectProperty;
import javafx.scene.control.Button;
import javafx.scene.control.TableCell;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.geometry.Pos;
import javafx.scene.control.Label;
import javafx.scene.control.Tooltip;
import javafx.scene.shape.Circle;
import pe.edu.upeu.dzrobot.componentes.Iconos;
import javafx.scene.layout.HBox;
import javafx.util.Callback;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.function.Consumer;
import java.util.function.Function;

public class TableViewHelper<T> {
    public void addColumnsInOrderWithSize(TableView<T> tableView, LinkedHashMap<String, ColumnInfo> columns, Consumer<T> updateAction, Consumer<T> deleteAction) {
        for (Map.Entry<String, ColumnInfo> entry : columns.entrySet()) {
            TableColumn<T, Object> column = new TableColumn<>(entry.getKey());
            String field = entry.getValue().getField();

            if (field.contains(".")) {
                column.setCellValueFactory(cellData -> {
                    T item = cellData.getValue();
                    String[] fieldPath = field.split("\\.");

                    try {
                        Object value = item.getClass().getMethod("get" + capitalize(fieldPath[0])).invoke(item);
                        if (value != null) {
                            Object nestedValue = value.getClass().getMethod("get" + capitalize(fieldPath[1])).invoke(value);
                            return new SimpleObjectProperty<>(nestedValue != null ? nestedValue : "N/A");
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                    }

                    return new SimpleObjectProperty("N/A");
                });
            } else {
                column.setCellValueFactory(new PropertyValueFactory<>(field));
            }

            if (entry.getValue().getWidth() != null) {
                column.setPrefWidth(entry.getValue().getWidth());
            }

            tableView.getColumns().add(column);
        }

        addActionColumn(tableView, updateAction, deleteAction);

        tableView.setColumnResizePolicy(TableView.UNCONSTRAINED_RESIZE_POLICY);
    }

    private void addActionColumn(TableView<T> tableView, Consumer<T> updateAction, Consumer<T> deleteAction) {
        TableColumn<T, Void> actionColumn = new TableColumn<>("Acciones");

        Callback<TableColumn<T, Void>, TableCell<T, Void>> cellFactory = new Callback<>() {
            @Override
            public TableCell<T, Void> call(final TableColumn<T, Void> param) {
                final TableCell<T, Void> cell = new TableCell<>() {
                    private final Button btnUpdate = botonIcono(Iconos.EDITAR, "Editar", false);
                    private final Button btnDelete = botonIcono(Iconos.ELIMINAR, "Eliminar", true);

                    {
                        btnUpdate.setOnAction(event -> {
                            T data = getTableView().getItems().get(getIndex());
                            updateAction.accept(data);
                        });

                        btnDelete.setOnAction(event -> {
                            T data = getTableView().getItems().get(getIndex());
                            deleteAction.accept(data);
                        });
                    }

                    @Override
                    public void updateItem(Void item, boolean empty) {
                        super.updateItem(item, empty);
                        if (empty) {
                            setGraphic(null);
                        } else {
                            HBox buttons = updateAction == null ? new HBox(btnDelete) : new HBox(btnUpdate, btnDelete);
                            buttons.setSpacing(6);
                            setGraphic(buttons);
                        }
                    }
                };
                return cell;
            }
        };

        actionColumn.setCellFactory(cellFactory);
        actionColumn.setPrefWidth(95);
        tableView.getColumns().add(actionColumn);
    }

    public static <T> void agregarAcciones(TableView<T> tabla, Consumer<T> editar, Consumer<T> eliminar) {
        new TableViewHelper<T>().addActionColumn(tabla, editar, eliminar);
    }

    private static Button botonIcono(String svg, String ayuda, boolean peligro) {
        Button b = new Button("", Iconos.crear(svg, 16));
        b.getStyleClass().add("btn-icono");
        if (peligro) {
            b.getStyleClass().add("btn-icono-peligro");
        }
        b.setTooltip(new Tooltip(ayuda));
        return b;
    }

    public static <T> void pildoras(TableView<T> tabla, String encabezado, Function<String, String> color) {
        columna(tabla, encabezado).ifPresent(col -> col.setCellFactory(c -> new TableCell<T, Object>() {
            @Override
            protected void updateItem(Object item, boolean empty) {
                super.updateItem(item, empty);
                setText(null);
                if (empty || item == null) {
                    setGraphic(null);
                    return;
                }
                String texto = item.toString().replace('_', ' ');
                if (texto.endsWith(".0")) {
                    texto = texto.substring(0, texto.length() - 2);
                }
                Label p = new Label(texto);
                p.getStyleClass().addAll("pildora", "pildora-" + color.apply(item.toString()));
                setGraphic(p);
            }
        }));
    }

    public static <T> void puntoAlerta(TableView<T> tabla, String encabezado, String textoSi, String textoNo) {
        columna(tabla, encabezado).ifPresent(col -> col.setCellFactory(c -> new TableCell<T, Object>() {
            @Override
            protected void updateItem(Object item, boolean empty) {
                super.updateItem(item, empty);
                setText(null);
                if (empty || item == null) {
                    setGraphic(null);
                    return;
                }
                boolean si = item instanceof Boolean b ? b : item.toString().toUpperCase().contains("S");
                Circle punto = new Circle(5);
                punto.getStyleClass().add(si ? "punto-mant" : "punto-ok");
                Label l = new Label(si ? textoSi : textoNo, punto);
                l.setGraphicTextGap(6);
                setGraphic(l);
                setAlignment(Pos.CENTER_LEFT);
            }
        }));
    }

    @SuppressWarnings("unchecked")
    private static <T> java.util.Optional<TableColumn<T, Object>> columna(TableView<T> tabla, String encabezado) {
        return tabla.getColumns().stream().filter(c -> c.getText().equals(encabezado))
                .map(c -> (TableColumn<T, Object>) c).findFirst();
    }

    private String capitalize(String str) {
        if (str == null || str.isEmpty()) {
            return str;
        }
        return str.substring(0, 1).toUpperCase() + str.substring(1);
    }
}
