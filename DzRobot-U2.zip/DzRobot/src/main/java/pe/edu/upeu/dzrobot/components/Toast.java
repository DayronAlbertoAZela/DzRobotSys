package pe.edu.upeu.dzrobot.components;

import javafx.animation.PauseTransition;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.control.Label;
import javafx.scene.layout.Region;
import javafx.scene.layout.StackPane;
import javafx.stage.Popup;
import javafx.stage.Stage;
import javafx.stage.Window;
import javafx.util.Duration;
import pe.edu.upeu.dzrobot.DzRobot;

public class Toast {

    public enum Tipo { OK, ERROR, INFO }

    public static void mostrar(Node nodo, String mensaje, Tipo tipo) {
        if (nodo == null || nodo.getScene() == null || mensaje == null || mensaje.isBlank()) {
            return;
        }
        mostrar(nodo.getScene().getWindow(), mensaje, tipo, tipo == Tipo.ERROR ? 3500 : 2200);
    }

    public static void showToast(Stage ownerStage, String message, int durationInMillis, double x, double y) {
        mostrar(ownerStage, message, Tipo.OK, durationInMillis);
    }

    public static void mostrar(Window ventana, String mensaje, Tipo tipo, int milisegundos) {
        Label caja = new Label(mensaje);
        caja.setWrapText(true);
        caja.setMaxWidth(460);
        caja.getStyleClass().addAll("toast", switch (tipo) {
            case OK -> "toast-ok";
            case ERROR -> "toast-error";
            case INFO -> "toast-info";
        });
        caja.getStylesheets().add(DzRobot.class.getResource("/css/dzrobot.css").toExternalForm());

        Runnable quitar;
        if (ventana.getScene() != null && ventana.getScene().getRoot() instanceof StackPane raiz) {
            caja.setMaxSize(Region.USE_PREF_SIZE, Region.USE_PREF_SIZE);
            caja.setMouseTransparent(true);
            StackPane.setAlignment(caja, Pos.BOTTOM_CENTER);
            StackPane.setMargin(caja, new Insets(0, 0, 50, 0));
            raiz.getChildren().add(caja);
            quitar = () -> raiz.getChildren().remove(caja);
        } else {
            Popup popup = new Popup();
            popup.getContent().add(caja);
            popup.setAutoFix(true);
            popup.show(ventana);
            caja.applyCss();
            caja.layout();
            popup.setX(ventana.getX() + (ventana.getWidth() - caja.prefWidth(-1)) / 2);
            popup.setY(ventana.getY() + ventana.getHeight() - 110);
            quitar = popup::hide;
        }

        PauseTransition espera = new PauseTransition(Duration.millis(milisegundos));
        espera.setOnFinished(e -> quitar.run());
        espera.play();
    }
}
