package pe.edu.upeu.dzrobot.service.impl;

import lombok.RequiredArgsConstructor;
import pe.edu.upeu.dzrobot.dto.ModeloDataAutocomplet;
import pe.edu.upeu.dzrobot.dto.comprobante.Comprobante;
import pe.edu.upeu.dzrobot.dto.comprobante.ItemComprobante;
import pe.edu.upeu.dzrobot.enums.EstadoRobot;
import pe.edu.upeu.dzrobot.enums.TipoDocumento;
import pe.edu.upeu.dzrobot.enums.TipoProducto;
import pe.edu.upeu.dzrobot.exception.ModelNotFoundException;
import pe.edu.upeu.dzrobot.model.Cliente;
import pe.edu.upeu.dzrobot.model.Emisor;
import pe.edu.upeu.dzrobot.model.Repuesto;
import pe.edu.upeu.dzrobot.model.Robot;
import pe.edu.upeu.dzrobot.model.Usuario;
import pe.edu.upeu.dzrobot.model.VentCarrito;
import pe.edu.upeu.dzrobot.model.Venta;
import pe.edu.upeu.dzrobot.model.VentaDetalle;
import pe.edu.upeu.dzrobot.repository.EmisorRepository;
import pe.edu.upeu.dzrobot.repository.ICrudGenericoRepository;
import pe.edu.upeu.dzrobot.repository.VentaRepository;
import pe.edu.upeu.dzrobot.service.IClienteService;
import pe.edu.upeu.dzrobot.service.IRepuestoService;
import pe.edu.upeu.dzrobot.service.IRobotService;
import pe.edu.upeu.dzrobot.service.IUsuarioService;
import pe.edu.upeu.dzrobot.service.IVentCarritoService;
import pe.edu.upeu.dzrobot.service.IVentaService;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

@RequiredArgsConstructor
public class VentaServiceImp extends CrudGenericoServiceImp<Venta, Long> implements IVentaService {
    private final VentaRepository ventaRepository;
    private final EmisorRepository emisorRepository;
    private final IVentCarritoService carritoService;
    private final IClienteService clienteService;
    private final IUsuarioService usuarioService;
    private final IRobotService robotService;
    private final IRepuestoService repuestoService;

    @Override
    protected ICrudGenericoRepository<Venta, Long> getRepo() {
        return ventaRepository;
    }

    @Override
    public String siguienteNumero(String tipoDoc) {
        return ventaRepository.siguienteNumero(serie(tipoDoc));
    }

    private String serie(String tipoDoc) {
        return "FACTURA".equals(tipoDoc) ? "F001" : "B001";
    }

    @Override
    public Venta registrarVenta(String dniruc, String tipoDoc, LocalDate fecha, Long idUsuario) {
        Cliente cliente = clienteService.findById(dniruc);
        if ("FACTURA".equals(tipoDoc) && cliente.getTipoDocumento() != TipoDocumento.RUC) {
            throw new IllegalArgumentException("La factura solo se emite a clientes con RUC");
        }
        if (fecha == null || fecha.isAfter(LocalDate.now())) {
            throw new IllegalArgumentException("La fecha de la venta no puede ser futura");
        }
        List<VentCarrito> carrito = carritoService.listarPorCliente(dniruc);
        if (carrito.isEmpty()) {
            throw new IllegalArgumentException("No hay productos en el carrito");
        }
        Venta venta = new Venta();
        venta.setDniruc(cliente);
        venta.setIdUsuario(Usuario.builder().idUsuario(idUsuario).build());
        venta.setFechaGener(fecha);
        venta.setTipoDoc(tipoDoc);
        venta.setSerie(serie(tipoDoc));
        for (VentCarrito c : carrito) {
            VentaDetalle.VentaDetalleBuilder d = VentaDetalle.builder()
                    .pu(c.getPunitario()).cantidad(c.getCantidad()).descuento(0).descripcion(c.getNombreProducto());
            if (c.getTipoProducto() == TipoProducto.ROBOT) {
                d.idRobot(robotService.findById(c.getIdRobot()));
            } else {
                d.idRepuesto(repuestoService.findById(c.getIdRepuesto()));
            }
            venta.getDetalleVenta().add(d.build());
        }
        venta.calcularTotal();
        Venta guardada = ventaRepository.save(venta);
        carritoService.vaciar(dniruc);
        return guardada;
    }

    @Override
    public Comprobante generarComprobante(Long idVenta) {
        Venta venta = ventaRepository.findConDetalle(idVenta)
                .orElseThrow(() -> new ModelNotFoundException("La venta no existe: " + idVenta));
        Cliente cliente = clienteService.findById(venta.getDniruc().getDniruc());
        Emisor emisor = emisorRepository.principal()
                .orElseThrow(() -> new ModelNotFoundException("Registre los datos del emisor"));
        Comprobante b = new Comprobante();
        b.setRucEmisor(emisor.getRuc());
        b.setRazonSocial(emisor.getNombreComercial());
        b.setDireccion(emisor.getDomicilioFiscal());
        b.setUbigeo(emisor.getDistrito() + ", " + emisor.getProvincia() + ", " + emisor.getDepartamento());
        b.setTipoDocumento("FACTURA".equals(venta.getTipoDoc()) ? "FACTURA ELECTRÓNICA" : "BOLETA DE VENTA ELECTRÓNICA");
        b.setSerie(venta.getSerie());
        b.setNumero(venta.getNumDoc());
        b.setFechaEmision(venta.getFechaGener().format(DateTimeFormatter.ofPattern("dd/MM/yyyy")));
        b.setVendedor(usuarioService.findById(venta.getIdUsuario().getIdUsuario()).getUsuario());
        b.setTipoDocCliente(cliente.getTipoDocumento().name());
        b.setNroDocCliente(cliente.getDniruc());
        b.setNombreCliente(cliente.getNombres());
        b.setDireccionCliente(cliente.getDireccion());
        List<ItemComprobante> items = new ArrayList<>();
        for (VentaDetalle d : venta.getDetalleVenta()) {
            items.add(new ItemComprobante(d.getDescripcion(), d.getCantidad(),
                    BigDecimal.valueOf(d.getPu()), BigDecimal.valueOf(d.getDescuento())));
        }
        b.setItems(items);
        BigDecimal total = BigDecimal.valueOf(venta.getPrecioTotal()).setScale(2, RoundingMode.HALF_UP);
        b.setOpGravadas(BigDecimal.valueOf(venta.getPrecioBase()).setScale(2, RoundingMode.HALF_UP));
        b.setIgv(total.subtract(b.getOpGravadas()));
        b.setTotal(total);
        return b;
    }

    @Override
    public List<ModeloDataAutocomplet> listAutoCompletProducto() {
        List<ModeloDataAutocomplet> lista = new ArrayList<>();
        for (Robot r : robotService.findAll()) {
            if (r.getEstado() == EstadoRobot.EN_STOCK) {
                lista.add(new ModeloDataAutocomplet("R" + r.getIdRobot(), r.getCodigo() + " " + r.getNombre(),
                        r.getPrecioVenta() + ":1:ROBOT"));
            }
        }
        for (Repuesto p : repuestoService.findAll()) {
            if (p.getStock() > 0) {
                lista.add(new ModeloDataAutocomplet("P" + p.getIdRepuesto(), p.getNombre(),
                        p.getPrecioVenta() + ":" + p.getStock().intValue() + ":REPUESTO"));
            }
        }
        return lista;
    }
}
