package pe.edu.upeu.dzrobot.enums;

public enum NivelEducativo {
    BASICO, INTERMEDIO, AVANZADO
}
