package pe.edu.upeu.dzrobot.model;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;
import pe.edu.upeu.dzrobot.enums.NivelEducativo;
import pe.edu.upeu.dzrobot.enums.TipoRobot;

import java.time.LocalDate;

@Data
@EqualsAndHashCode(callSuper = true)
@NoArgsConstructor
@SuperBuilder
public class RobotEducativo extends Robot {
    @NotBlank(message = "La plataforma es obligatoria")
    private String plataforma;
    @NotNull(message = "El nivel es obligatorio")
    private NivelEducativo nivel;

    @Override
    public LocalDate calcularProximoMantenimiento() {
        return getFechaBase().plusYears(1);
    }

    @Override
    public TipoRobot getTipoRobot() {
        return TipoRobot.EDUCATIVO;
    }

    @Override
    public String getDetalleTecnico() {
        return plataforma + ", nivel " + nivel;
    }
}
