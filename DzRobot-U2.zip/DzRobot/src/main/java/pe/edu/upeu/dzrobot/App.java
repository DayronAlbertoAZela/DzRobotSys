package pe.edu.upeu.dzrobot;

import javafx.application.Application;

public class App {
    public static void main(String[] args) {
        Application.launch(DzRobot.class, args);
    }
}
