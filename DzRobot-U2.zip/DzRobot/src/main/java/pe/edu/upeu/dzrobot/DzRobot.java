package pe.edu.upeu.dzrobot;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;
import pe.edu.upeu.dzrobot.componentes.Tema;
import pe.edu.upeu.dzrobot.components.StageManager;
import pe.edu.upeu.dzrobot.config.AppContext;
import pe.edu.upeu.dzrobot.config.DatabaseConfig;

import java.io.IOException;

public class DzRobot extends Application {
    @Override
    public void start(Stage stage) throws IOException {
        Tema.cargarFuentes();
        DatabaseConfig.init();
        StageManager.setPrimaryStage(stage);
        FXMLLoader fxmlLoader = new FXMLLoader(DzRobot.class.getResource("/view/login.fxml"));
        fxmlLoader.setControllerFactory(AppContext.getInstance()::getBean);
        Scene scene = new Scene(fxmlLoader.load());
        Tema.aplicar(scene);
        stage.getIcons().add(new javafx.scene.image.Image(
                DzRobot.class.getResourceAsStream("/img/dzrobot-logo.png")));
        stage.setTitle(Tema.NOMBRE + " - Login");
        stage.setResizable(false);
        stage.setScene(scene);
        stage.show();
    }

    @Override
    public void stop() {
        DatabaseConfig.shutdown();
    }
}
