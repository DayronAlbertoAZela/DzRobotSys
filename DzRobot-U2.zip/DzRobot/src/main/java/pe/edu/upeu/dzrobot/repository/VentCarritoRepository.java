package pe.edu.upeu.dzrobot.repository;

import pe.edu.upeu.dzrobot.enums.TipoProducto;
import pe.edu.upeu.dzrobot.model.VentCarrito;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

public class VentCarritoRepository extends AbstractJpaRepository<VentCarrito, Long> {
    @Override
    protected String getTableName() {return "vent_carrito";}

    @Override
    protected String getPkColumn() {return "id_carrito";}

    public List<VentCarrito> listarPorCliente(String dniruc) {
        return executeQuery("SELECT * FROM vent_carrito WHERE dniruc = ? ORDER BY id_carrito", dniruc);
    }

    public void vaciar(String dniruc) {
        executeUpdateStandalone("DELETE FROM vent_carrito WHERE dniruc = ?", dniruc);
    }

    @Override
    protected VentCarrito insert(Connection conn, VentCarrito e) throws SQLException {
        long id = executeInsertGetKey(conn,
                "INSERT INTO vent_carrito(dniruc,tipo_producto,id_producto,nombre_producto,cantidad,punitario,ptotal,estado,id_usuario) "
                        + "VALUES(?,?,?,?,?,?,?,?,?)",
                e.getDniruc(), e.getTipoProducto().name(), e.getIdProducto(), e.getNombreProducto(),
                e.getCantidad(), e.getPunitario(), e.getPtotal(), e.getEstado(), e.getIdUsuario());
        e.setIdCarrito(id);
        return e;
    }

    @Override
    protected VentCarrito updateRow(Connection conn, VentCarrito e) throws SQLException {
        executeUpdate(conn, "UPDATE vent_carrito SET cantidad=?, ptotal=? WHERE id_carrito=?",
                e.getCantidad(), e.getPtotal(), e.getIdCarrito());
        return e;
    }

    @Override
    protected VentCarrito mapRow(ResultSet rs) throws SQLException {
        TipoProducto tipo = TipoProducto.valueOf(rs.getString("tipo_producto"));
        long idProducto = rs.getLong("id_producto");
        Long robot = tipo == TipoProducto.ROBOT ? idProducto : null;
        Long repuesto = tipo == TipoProducto.REPUESTO ? idProducto : null;
        return VentCarrito.builder()
                .idCarrito(rs.getLong("id_carrito"))
                .dniruc(rs.getString("dniruc"))
                .tipoProducto(TipoProducto.valueOf(rs.getString("tipo_producto")))
                .idRobot(robot)
                .idRepuesto(repuesto)
                .nombreProducto(rs.getString("nombre_producto"))
                .cantidad(rs.getDouble("cantidad"))
                .punitario(rs.getDouble("punitario"))
                .ptotal(rs.getDouble("ptotal"))
                .estado(rs.getInt("estado"))
                .idUsuario(rs.getLong("id_usuario"))
                .build();
    }
}
