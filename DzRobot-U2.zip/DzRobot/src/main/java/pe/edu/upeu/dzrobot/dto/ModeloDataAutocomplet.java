package pe.edu.upeu.dzrobot.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ModeloDataAutocomplet {
    private String idx;
    private String nameDysplay;
    private String otherData;

    @Override
    public String toString() {
        return idx + " - " + nameDysplay;
    }
}
