package pe.edu.upeu.dzrobot.modulos;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableCell;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.layout.Priority;
import javafx.scene.layout.VBox;
import pe.edu.upeu.dzrobot.components.Toast;
import pe.edu.upeu.dzrobot.repository.ConsultaRepository;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.function.BiFunction;
import java.util.function.Function;

public class ModuloConsulta {
    public record Resumen(String titulo, Function<List<Map<String, Object>>, String> calculo) { }

    public record Accion(Function<Map<String, Object>, String> texto, BiFunction<ConsultaRepository, Map<String, Object>, String> hacer) { }

    private final ConsultaRepository repo;
    private final String titulo;
    private final String sql;
    private final List<Columna> columnas;
    private final String clave;
    private final String sqlDetalle;
    private final List<Columna> columnasDetalle;
    private final List<Resumen> resumenes;
    private final Accion accion;

    private List<Map<String, Object>> filas = new ArrayList<>();
    private TableView<Map<String, Object>> tabla;
    private TableView<Map<String, Object>> detalle;
    private HBox tarjetas;
    private TextField filtro;

    public ModuloConsulta(ConsultaRepository repo, String titulo, String sql, List<Columna> columnas,
                          String clave, String sqlDetalle, List<Columna> columnasDetalle,
                          List<Resumen> resumenes, Accion accion) {
        this.repo = repo;
        this.titulo = titulo;
        this.sql = sql;
        this.columnas = columnas;
        this.clave = clave;
        this.sqlDetalle = sqlDetalle;
        this.columnasDetalle = columnasDetalle;
        this.resumenes = resumenes;
        this.accion = accion;
    }

    public Node crear() {
        Label lblTitulo = new Label(titulo);
        lblTitulo.getStyleClass().add("titulo-modulo");
        filtro = new TextField();
        filtro.setPromptText("Buscar...");
        filtro.setPrefWidth(220);
        Pane espacio = new Pane();
        HBox.setHgrow(espacio, Priority.ALWAYS);
        HBox cabecera = new HBox(10, lblTitulo, espacio, new Label("Filtrar"), filtro);
        cabecera.setAlignment(Pos.CENTER_LEFT);
        cabecera.getStyleClass().add("panel");

        tarjetas = new HBox(10);

        tabla = TablaMapa.crear(columnas);
        if (accion != null) {
            agregarAccion();
        }
        VBox.setVgrow(tabla, Priority.ALWAYS);

        VBox raiz = new VBox(10, cabecera, tarjetas, tabla);
        if (sqlDetalle != null) {
            detalle = TablaMapa.crear(columnasDetalle);
            detalle.setPrefHeight(170);
            detalle.setPlaceholder(new Label("Elija una fila de arriba para ver su detalle"));
            Label lblDet = new Label("Detalle");
            lblDet.getStyleClass().add("dash-subtitulo");
            raiz.getChildren().addAll(lblDet, detalle);
            tabla.getSelectionModel().selectedItemProperty().addListener((o, a, fila) -> cargarDetalle(fila));
        }
        raiz.setPadding(new Insets(5));
        filtro.textProperty().addListener((o, a, b) -> filtrar());
        listar();
        return raiz;
    }

    private void listar() {
        try {
            filas = repo.filas(sql);
        } catch (RuntimeException e) {
            filas = new ArrayList<>();
            Toast.mostrar(tabla, e.getMessage(), Toast.Tipo.ERROR);
        }
        filtrar();
    }

    private void filtrar() {
        String f = filtro.getText() == null ? "" : filtro.getText().toLowerCase();
        List<Map<String, Object>> vistas = filas.stream()
                .filter(m -> m.values().stream().anyMatch(v -> v != null && v.toString().toLowerCase().contains(f)))
                .toList();
        tabla.getItems().setAll(vistas);
        tarjetas.getChildren().clear();
        for (Resumen r : resumenes) {
            Label numero = new Label(r.calculo().apply(vistas));
            numero.getStyleClass().add("kpi-numero");
            numero.setStyle("-fx-font-size: 20px;");
            Label t = new Label(r.titulo());
            t.getStyleClass().add("kpi-titulo");
            VBox card = new VBox(2, t, numero);
            card.getStyleClass().add("panel");
            card.setPadding(new Insets(10, 16, 10, 16));
            card.setMinWidth(170);
            tarjetas.getChildren().add(card);
        }
    }

    private void cargarDetalle(Map<String, Object> fila) {
        if (fila == null) {
            detalle.getItems().clear();
            return;
        }
        try {
            detalle.getItems().setAll(repo.filas(sqlDetalle, fila.get(clave)));
        } catch (RuntimeException e) {
            Toast.mostrar(tabla, e.getMessage(), Toast.Tipo.ERROR);
        }
    }

    private void agregarAccion() {
        TableColumn<Map<String, Object>, Void> col = new TableColumn<>("Acción");
        col.setPrefWidth(130);
        col.setCellFactory(x -> new TableCell<>() {
            private final Button boton = new Button();

            {
                boton.getStyleClass().add("btn-tema");
                boton.setOnAction(e -> {
                    Map<String, Object> fila = getTableView().getItems().get(getIndex());
                    try {
                        String msg = accion.hacer().apply(repo, fila);
                        Toast.mostrar(tabla, msg, Toast.Tipo.OK);
                        listar();
                    } catch (RuntimeException ex) {
                        Toast.mostrar(tabla, ex.getMessage(), Toast.Tipo.ERROR);
                    }
                });
            }

            @Override
            protected void updateItem(Void item, boolean empty) {
                super.updateItem(item, empty);
                if (empty || getIndex() >= getTableView().getItems().size()) {
                    setGraphic(null);
                    return;
                }
                boton.setText(accion.texto().apply(getTableView().getItems().get(getIndex())));
                setGraphic(boton);
            }
        });
        tabla.getColumns().add(col);
    }

    public static Function<List<Map<String, Object>>, String> suma(String columna) {
        return filas -> TablaMapa.SOLES.format(filas.stream()
                .mapToDouble(f -> f.get(columna) == null ? 0 : ((Number) f.get(columna)).doubleValue()).sum());
    }

    public static Function<List<Map<String, Object>>, String> cantidad() {
        return filas -> String.valueOf(filas.size());
    }

    public static Function<List<Map<String, Object>>, String> promedio(String columna) {
        return filas -> TablaMapa.SOLES.format(filas.stream()
                .mapToDouble(f -> f.get(columna) == null ? 0 : ((Number) f.get(columna)).doubleValue()).average().orElse(0));
    }

    public static Function<List<Map<String, Object>>, String> contar(String columna, String valor) {
        return filas -> String.valueOf(filas.stream().filter(f -> valor.equals(String.valueOf(f.get(columna)))).count());
    }
}
