package pe.edu.upeu.dzrobot.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Componente implements Mantenible {
    public static final double UMBRAL_DESGASTE = 0.80;
    public static final int HORAS_USO_DIARIO = 8;

    private Long idComponente;
    private String numSerie;
    private Double horasUso;
    private LocalDate fechaInst;
    private String estado;
    private Long idRobot;
    private Repuesto idRepuesto;

    public double getPorcentajeDesgaste() {
        return horasUso / idRepuesto.getVidaUtil();
    }

    @Override
    public boolean necesitaMantenimiento() {
        return getPorcentajeDesgaste() >= UMBRAL_DESGASTE;
    }

    @Override
    public LocalDate calcularProximoMantenimiento() {
        double horasRestantes = idRepuesto.getVidaUtil() * UMBRAL_DESGASTE - horasUso;
        if (horasRestantes <= 0) return LocalDate.now();
        return LocalDate.now().plusDays((long) Math.ceil(horasRestantes / HORAS_USO_DIARIO));
    }
}
