package pe.edu.upeu.dzrobot.utils;

import org.jsoup.Connection;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;
import pe.edu.upeu.dzrobot.dto.PersonaDto;

import java.io.IOException;
import java.util.Optional;

public class ConsultaDNI {
    private static final String URL = "https://eldni.com/pe/buscar-datos-por-dni";

    public Optional<PersonaDto> consultarDNI(String dni) {
        if (dni == null || !dni.matches("\\d{8}")) {
            return Optional.empty();
        }
        try {
            Connection.Response get = Jsoup.connect(URL).method(Connection.Method.GET).timeout(8000).execute();
            String token = get.parse().select("input[name=_token]").attr("value");
            Connection.Response post = Jsoup.connect(URL)
                    .cookies(get.cookies())
                    .data("_token", token)
                    .data("dni", dni)
                    .method(Connection.Method.POST)
                    .ignoreContentType(true)
                    .timeout(8000)
                    .execute();
            Document doc = Jsoup.parse(post.body());
            Element fila = doc.select("table tbody tr").first();
            if (fila == null) {
                return Optional.empty();
            }
            Elements celdas = fila.select("td");
            if (celdas.size() < 4) {
                return Optional.empty();
            }
            return Optional.of(new PersonaDto(celdas.get(0).text(), celdas.get(1).text(),
                    celdas.get(2).text(), celdas.get(3).text()));
        } catch (IOException | RuntimeException e) {
            return Optional.empty();
        }
    }
}
