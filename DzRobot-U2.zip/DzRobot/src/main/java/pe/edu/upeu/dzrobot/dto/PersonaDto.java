package pe.edu.upeu.dzrobot.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class PersonaDto {
    private String dni;
    private String nombre;
    private String apellidoPaterno;
    private String apellidoMaterno;

    public String getNombreCompleto() {
        return (nombre + " " + apellidoPaterno + " " + apellidoMaterno).trim();
    }
}
