package pe.edu.upeu.dzrobot.controller;

import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Rectangle2D;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Screen;
import javafx.stage.Stage;
import lombok.RequiredArgsConstructor;
import pe.edu.upeu.dzrobot.DzRobot;
import pe.edu.upeu.dzrobot.componentes.Tema;
import pe.edu.upeu.dzrobot.config.AppContext;
import pe.edu.upeu.dzrobot.dto.SessionManager;
import pe.edu.upeu.dzrobot.model.Usuario;
import pe.edu.upeu.dzrobot.service.IUsuarioService;

@RequiredArgsConstructor
public class LoginController {
    private final IUsuarioService us;

    @FXML
    TextField txtUsuario;
    @FXML
    PasswordField txtClave;
    @FXML
    Label lblMsg;

    @FXML
    public void login(ActionEvent e) {
        if (txtUsuario.getText().isBlank() || txtClave.getText().isEmpty()) {
            lblMsg.setText("Ingrese usuario y clave");
            return;
        }
        us.loginUsuario(txtUsuario.getText().trim(), txtClave.getText()).ifPresentOrElse(
                usuario -> abrirPantalla(e, usuario),
                () -> {
                    lblMsg.setText("Usuario o clave incorrectos");
                    txtClave.clear();
                });
    }

    @FXML
    public void cerrar() {
        Platform.exit();
    }

    public void abrirPantalla(ActionEvent e, Usuario usuario) {
        SessionManager.getInstance().setUserId(usuario.getIdUsuario());
        SessionManager.getInstance().setUserName(usuario.getUsuario());
        SessionManager.getInstance().setUserPerfil(usuario.getIdPerfil().getNombre());
        try {
            Rectangle2D rectangle2D = Screen.getPrimary().getVisualBounds();
            FXMLLoader fxmlLoader = new FXMLLoader(DzRobot.class.getResource("/view/maingui.fxml"));
            fxmlLoader.setControllerFactory(AppContext.getInstance()::getBean);
            Scene scene = new Scene(fxmlLoader.load(), rectangle2D.getWidth(), rectangle2D.getHeight());
            Tema.aplicar(scene);
            Stage stage = (Stage) ((Node) e.getSource()).getScene().getWindow();
            stage.setTitle(Tema.NOMBRE + " - " + usuario.getUsuario() + " (" + usuario.getIdPerfil().getNombre() + ")");
            stage.setScene(scene);
            stage.setX(rectangle2D.getMinX());
            stage.setY(rectangle2D.getMinY());
            stage.setResizable(true);
            stage.show();
        } catch (Exception ex) {
            ex.printStackTrace();
            lblMsg.setText("Error al abrir el menú: " + ex.getMessage());
        }
    }
}
