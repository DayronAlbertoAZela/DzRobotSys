package pe.edu.upeu.dzrobot.service;

import pe.edu.upeu.dzrobot.dto.ComboBoxOption;
import pe.edu.upeu.dzrobot.model.Robot;

import java.util.List;

public interface IRobotService extends ICrudGenericoService<Robot, Long> {
    List<ComboBoxOption> listarTipoRobot();

    List<ComboBoxOption> listarEstados();

    List<Robot> listarQueNecesitanMantenimiento();
}
