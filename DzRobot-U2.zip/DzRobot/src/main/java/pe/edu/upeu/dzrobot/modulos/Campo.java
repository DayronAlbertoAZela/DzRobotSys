package pe.edu.upeu.dzrobot.modulos;

import java.util.List;

public record Campo(String etiqueta, String columna, String regex, String error, List<String> opciones, String seccion) {
    public static Campo texto(String seccion, String etiqueta, String columna, String regex, String error) {
        return new Campo(etiqueta, columna, regex, error, null, seccion);
    }

    public static Campo combo(String seccion, String etiqueta, String columna, List<String> opciones) {
        return new Campo(etiqueta, columna, ".+", "Elija " + etiqueta.toLowerCase(), opciones, seccion);
    }
}
