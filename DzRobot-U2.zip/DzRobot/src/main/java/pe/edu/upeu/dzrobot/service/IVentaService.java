package pe.edu.upeu.dzrobot.service;

import pe.edu.upeu.dzrobot.dto.ModeloDataAutocomplet;
import pe.edu.upeu.dzrobot.dto.comprobante.Comprobante;
import pe.edu.upeu.dzrobot.model.Venta;

import java.time.LocalDate;
import java.util.List;

public interface IVentaService extends ICrudGenericoService<Venta, Long> {
    Venta registrarVenta(String dniruc, String tipoDoc, LocalDate fecha, Long idUsuario);

    String siguienteNumero(String tipoDoc);

    Comprobante generarComprobante(Long idVenta);

    List<ModeloDataAutocomplet> listAutoCompletProducto();
}
