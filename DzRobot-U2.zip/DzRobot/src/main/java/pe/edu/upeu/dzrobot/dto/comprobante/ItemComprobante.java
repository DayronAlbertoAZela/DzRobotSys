package pe.edu.upeu.dzrobot.dto.comprobante;

import lombok.Data;

import java.math.BigDecimal;
import java.math.RoundingMode;

@Data
public class ItemComprobante {
    private String descripcion;
    private Double cantidad;
    private BigDecimal precioUnitario;
    private BigDecimal descuento;
    private BigDecimal subtotal;

    public ItemComprobante(String descripcion, Double cantidad, BigDecimal precioUnitario, BigDecimal descuento) {
        this.descripcion = descripcion;
        this.cantidad = cantidad;
        this.precioUnitario = precioUnitario.setScale(2, RoundingMode.HALF_UP);
        this.descuento = descuento.setScale(2, RoundingMode.HALF_UP);
        this.subtotal = precioUnitario.multiply(BigDecimal.valueOf(cantidad)).subtract(descuento)
                .setScale(2, RoundingMode.HALF_UP);
    }

    public String getCantidadTexto() {
        return cantidad % 1 == 0 ? String.valueOf(cantidad.intValue()) : String.valueOf(cantidad);
    }
}
