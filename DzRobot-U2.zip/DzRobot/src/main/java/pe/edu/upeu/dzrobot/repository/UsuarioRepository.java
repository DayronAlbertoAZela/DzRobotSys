package pe.edu.upeu.dzrobot.repository;

import pe.edu.upeu.dzrobot.model.Perfil;
import pe.edu.upeu.dzrobot.model.Usuario;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.Optional;

public class UsuarioRepository extends AbstractJpaRepository<Usuario, Long> {
    private static final String SELECT_JOIN =
            "SELECT u.*, p.nombre AS perfil_nombre " +
                    "FROM usuario u JOIN perfil p ON u.id_perfil = p.id_perfil ";

    @Override
    protected String getTableName() {return "usuario";}

    @Override
    protected String getPkColumn() {return "id_usuario";}

    @Override
    public List<Usuario> findAll() {
        return executeQuery(SELECT_JOIN);
    }

    @Override
    public Optional<Usuario> findById(Long id) {
        return executeQueryOne(SELECT_JOIN + "WHERE u.id_usuario = ?", id);
    }

    public Optional<Usuario> buscarUsuario(String usuario) {
        return executeQueryOne(SELECT_JOIN + "WHERE LOWER(u.usuario) = LOWER(?)", usuario.trim());
    }

    @Override
    protected Usuario mapRow(ResultSet rs) throws SQLException {
        return Usuario.builder()
                .idUsuario(rs.getLong("id_usuario"))
                .usuario(rs.getString("usuario"))
                .clave(rs.getString("clave"))
                .estado(rs.getString("estado"))
                .idPerfil(Perfil.builder()
                        .idPerfil(rs.getLong("id_perfil"))
                        .nombre(rs.getString("perfil_nombre")).build())
                .build();
    }

    @Override
    protected Usuario insert(Connection conn, Usuario e) throws SQLException {
        long id = executeInsertGetKey(conn,
                "INSERT INTO usuario(usuario,clave,estado,id_perfil) VALUES(?,?,?,?)",
                e.getUsuario(), e.getClave(), e.getEstado(), e.getIdPerfil().getIdPerfil());
        e.setIdUsuario(id);
        return e;
    }

    @Override
    protected Usuario updateRow(Connection conn, Usuario e) throws SQLException {
        executeUpdate(conn,
                "UPDATE usuario SET usuario=?,clave=?,estado=?,id_perfil=? WHERE id_usuario=?",
                e.getUsuario(), e.getClave(), e.getEstado(), e.getIdPerfil().getIdPerfil(), e.getIdUsuario());
        return e;
    }
}
