package pe.edu.upeu.dzrobot.model;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

@Data
@EqualsAndHashCode(callSuper = true)
@NoArgsConstructor
public class Venta extends DocumentoComercial {
    private Cliente dniruc;
    private Usuario idUsuario;
    private LocalDate fechaGener;
    private List<VentaDetalle> detalleVenta = new ArrayList<>();

    @Override
    public double calcularTotal() {
        double total = redondear(detalleVenta.stream().mapToDouble(VentaDetalle::getSubtotal).sum());
        setPrecioTotal(total);
        setPrecioBase(redondear(total / (1 + TASA_IGV)));
        setIgv(redondear(total - getPrecioBase()));
        return total;
    }
}
