package pe.edu.upeu.dzrobot.enums;

public enum EstadoRobot {
    EN_STOCK, VENDIDO, EN_REPARACION, OPERATIVO, DE_BAJA
}
