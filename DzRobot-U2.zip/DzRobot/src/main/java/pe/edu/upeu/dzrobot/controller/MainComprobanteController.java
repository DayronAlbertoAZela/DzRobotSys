package pe.edu.upeu.dzrobot.controller;

import javafx.concurrent.Task;
import javafx.fxml.FXML;
import javafx.geometry.Pos;
import javafx.print.PrinterJob;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.layout.VBox;
import javafx.stage.FileChooser;
import pe.edu.upeu.dzrobot.components.Toast;
import pe.edu.upeu.dzrobot.components.comprob.ComprobantePdfService;
import pe.edu.upeu.dzrobot.components.comprob.ComprobanteView;
import pe.edu.upeu.dzrobot.dto.comprobante.Comprobante;

import java.awt.Desktop;
import java.io.File;

public class MainComprobanteController {
    private final Comprobante comprobante;
    private final ComprobantePdfService pdfService = new ComprobantePdfService();

    @FXML ScrollPane scrollVisor;
    @FXML Button btnExportarPdf, btnImprimir;
    @FXML Label lblTitulo;

    private VBox vista;

    public MainComprobanteController(Comprobante comprobante) {
        this.comprobante = comprobante;
    }

    @FXML
    public void initialize() {
        lblTitulo.setText(comprobante.getTipoDocumento() + "  " + comprobante.getSerie() + "-" + comprobante.getNumero());
        vista = new ComprobanteView(comprobante).construir();
        VBox fondo = new VBox(vista);
        fondo.setAlignment(Pos.TOP_CENTER);
        fondo.setStyle("-fx-background-color: #d1d5db; -fx-padding: 16;");
        scrollVisor.setContent(fondo);
    }

    @FXML
    public void onExportarPdf() {
        FileChooser chooser = new FileChooser();
        chooser.setTitle("Guardar comprobante como PDF");
        chooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("Archivo PDF (*.pdf)", "*.pdf"));
        chooser.setInitialFileName(comprobante.getSerie() + "-" + comprobante.getNumero() + ".pdf");
        File archivo = chooser.showSaveDialog(btnExportarPdf.getScene().getWindow());
        if (archivo == null) {
            return;
        }
        btnExportarPdf.setDisable(true);
        Task<Void> tarea = new Task<>() {
            @Override
            protected Void call() throws Exception {
                pdfService.exportar(comprobante, archivo.toPath());
                return null;
            }
        };
        tarea.setOnSucceeded(e -> {
            btnExportarPdf.setDisable(false);
            Toast.mostrar(scrollVisor, "PDF guardado en " + archivo.getName(), Toast.Tipo.OK);
            try {
                if (Desktop.isDesktopSupported()) {
                    Desktop.getDesktop().open(archivo);
                }
            } catch (Exception ignorado) {
                Toast.mostrar(scrollVisor, "PDF guardado; ábralo desde " + archivo.getParent(), Toast.Tipo.INFO);
            }
        });
        tarea.setOnFailed(e -> {
            btnExportarPdf.setDisable(false);
            Toast.mostrar(scrollVisor, "No se pudo generar el PDF: " + tarea.getException().getMessage(), Toast.Tipo.ERROR);
        });
        Thread hilo = new Thread(tarea);
        hilo.setDaemon(true);
        hilo.start();
    }

    @FXML
    public void onImprimir() {
        PrinterJob job = PrinterJob.createPrinterJob();
        if (job == null) {
            Toast.mostrar(scrollVisor, "No hay impresora instalada: use Exportar PDF", Toast.Tipo.ERROR);
            return;
        }
        if (job.showPrintDialog(btnImprimir.getScene().getWindow()) && job.printPage(vista)) {
            job.endJob();
        }
    }

    @FXML
    public void cerrar() {
        btnImprimir.getScene().getWindow().hide();
    }
}
