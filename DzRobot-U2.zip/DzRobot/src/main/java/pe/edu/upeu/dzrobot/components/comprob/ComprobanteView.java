package pe.edu.upeu.dzrobot.components.comprob;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Border;
import javafx.scene.layout.BorderStroke;
import javafx.scene.layout.BorderStrokeStyle;
import javafx.scene.layout.BorderWidths;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.CornerRadii;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import pe.edu.upeu.dzrobot.DzRobot;
import pe.edu.upeu.dzrobot.dto.comprobante.Comprobante;
import pe.edu.upeu.dzrobot.dto.comprobante.ItemComprobante;
import pe.edu.upeu.dzrobot.utils.NumeroLetras;

public class ComprobanteView {
    private static final Color PRIMARIO = Color.web("#1f2937");
    private static final Color ACENTO = Color.web("#ea580c");
    private static final Color CLARO = Color.web("#f3f4f6");

    private static final Font F_NORMAL = Font.font("Inter", 11);
    private static final Font F_BOLD = Font.font("Inter", FontWeight.BOLD, 12);
    private static final Font F_TITULO = Font.font("Inter", FontWeight.BOLD, 14);

    private final Comprobante b;

    public ComprobanteView(Comprobante comprobante) {
        this.b = comprobante;
    }

    public VBox construir() {
        VBox pagina = new VBox(14, cabecera(), cliente(), items(), totales(), pie());
        pagina.setStyle("-fx-background-color: white;");
        pagina.setPadding(new Insets(24));
        pagina.setMinWidth(720);
        pagina.setMaxWidth(720);
        return pagina;
    }

    private HBox cabecera() {
        ImageView logo = new ImageView(new Image(DzRobot.class.getResourceAsStream("/img/dzrobot-logo.png")));
        logo.setFitHeight(54);
        logo.setPreserveRatio(true);
        VBox emisor = new VBox(3,
                lbl(b.getRazonSocial(), F_TITULO, PRIMARIO),
                lbl("RUC: " + b.getRucEmisor(), F_BOLD, PRIMARIO),
                lbl(b.getDireccion(), F_NORMAL, PRIMARIO),
                lbl(b.getUbigeo(), F_NORMAL, PRIMARIO));
        HBox izq = new HBox(12, logo, emisor);
        izq.setAlignment(Pos.CENTER_LEFT);
        HBox.setHgrow(izq, Priority.ALWAYS);

        VBox doc = new VBox(4,
                lbl(b.getTipoDocumento(), F_TITULO, ACENTO),
                lbl("R.U.C. " + b.getRucEmisor(), F_BOLD, PRIMARIO),
                lbl(b.getSerie() + " - " + b.getNumero(), F_TITULO, ACENTO));
        doc.setAlignment(Pos.CENTER);
        doc.setPrefWidth(250);
        doc.setPadding(new Insets(10));
        doc.setBorder(borde(ACENTO, 2));
        return new HBox(16, izq, doc);
    }

    private VBox cliente() {
        GridPane grid = new GridPane();
        grid.setBorder(borde(CLARO, 2));
        fila(grid, 0, b.getTipoDocCliente(), b.getNroDocCliente());
        fila(grid, 1, "Cliente", b.getNombreCliente());
        fila(grid, 2, "Dirección", b.getDireccionCliente());
        fila(grid, 3, "Fecha / Moneda", b.getFechaEmision() + "  |  " + b.getMoneda() + "  |  Vendedor: " + b.getVendedor());
        ColumnConstraints c1 = new ColumnConstraints(130);
        ColumnConstraints c2 = new ColumnConstraints();
        c2.setHgrow(Priority.ALWAYS);
        grid.getColumnConstraints().addAll(c1, c2);
        return new VBox(4, lbl("DATOS DEL CLIENTE", F_BOLD, PRIMARIO), grid);
    }

    private VBox items() {
        GridPane cab = new GridPane();
        cab.setStyle("-fx-background-color: #1f2937;");
        cab.setPadding(new Insets(5, 8, 5, 8));
        cab.addRow(0, celda("CANT.", Color.WHITE, F_BOLD, 50, Pos.CENTER),
                celda("DESCRIPCIÓN", Color.WHITE, F_BOLD, 330, Pos.CENTER_LEFT),
                celda("P. UNIT", Color.WHITE, F_BOLD, 100, Pos.CENTER_RIGHT),
                celda("DSCTO.", Color.WHITE, F_BOLD, 80, Pos.CENTER_RIGHT),
                celda("SUBTOTAL", Color.WHITE, F_BOLD, 100, Pos.CENTER_RIGHT));
        VBox filas = new VBox();
        filas.setBorder(borde(CLARO, 1));
        for (int i = 0; i < b.getItems().size(); i++) {
            ItemComprobante it = b.getItems().get(i);
            GridPane f = new GridPane();
            f.setPadding(new Insets(5, 8, 5, 8));
            f.setStyle("-fx-background-color: " + (i % 2 == 0 ? "white" : "#f3f4f6") + ";");
            f.addRow(0, celda(it.getCantidadTexto(), PRIMARIO, F_NORMAL, 50, Pos.CENTER),
                    celda(it.getDescripcion(), PRIMARIO, F_NORMAL, 330, Pos.CENTER_LEFT),
                    celda("S/ " + it.getPrecioUnitario(), PRIMARIO, F_NORMAL, 100, Pos.CENTER_RIGHT),
                    celda("S/ " + it.getDescuento(), PRIMARIO, F_NORMAL, 80, Pos.CENTER_RIGHT),
                    celda("S/ " + it.getSubtotal(), PRIMARIO, F_NORMAL, 100, Pos.CENTER_RIGHT));
            filas.getChildren().add(f);
        }
        return new VBox(4, lbl("DETALLE", F_BOLD, PRIMARIO), cab, filas);
    }

    private HBox totales() {
        VBox izq = new VBox(4, lbl("SON:", F_BOLD, PRIMARIO), lbl(NumeroLetras.soles(b.getTotal()), F_NORMAL, PRIMARIO));
        izq.setPrefWidth(380);
        HBox.setHgrow(izq, Priority.ALWAYS);
        VBox der = new VBox(totalFila("Op. Gravadas", b.getOpGravadas().toString(), false),
                totalFila("IGV (18%)", b.getIgv().toString(), false),
                totalFila("TOTAL", b.getTotal().toString(), true));
        return new HBox(16, izq, der);
    }

    private VBox pie() {
        VBox pie = new VBox(4,
                lbl("Representación impresa de la " + b.getTipoDocumento(), F_NORMAL, PRIMARIO),
                lbl("Gracias por confiar en DzRobot", F_NORMAL, PRIMARIO));
        pie.setAlignment(Pos.CENTER);
        pie.setPadding(new Insets(10, 0, 0, 0));
        pie.setBorder(new Border(new BorderStroke(CLARO, BorderStrokeStyle.DASHED, CornerRadii.EMPTY, new BorderWidths(2, 0, 0, 0))));
        return pie;
    }

    private Label lbl(String texto, Font font, Color color) {
        Label l = new Label(texto);
        l.setFont(font);
        l.setTextFill(color);
        l.setStyle(String.format("-fx-text-fill: #%02x%02x%02x;", (int) Math.round(color.getRed() * 255),
                (int) Math.round(color.getGreen() * 255), (int) Math.round(color.getBlue() * 255)));
        l.setWrapText(true);
        return l;
    }

    private Label celda(String texto, Color color, Font font, double ancho, Pos pos) {
        Label l = lbl(texto, font, color);
        l.setPrefWidth(ancho);
        l.setAlignment(pos);
        return l;
    }

    private void fila(GridPane grid, int row, String etiqueta, String valor) {
        Label e = lbl(etiqueta, F_BOLD, PRIMARIO);
        e.setPadding(new Insets(4, 8, 4, 8));
        Label v = lbl(valor, F_NORMAL, PRIMARIO);
        v.setPadding(new Insets(4, 8, 4, 8));
        grid.addRow(row, e, v);
    }

    private HBox totalFila(String etiqueta, String valor, boolean esTotal) {
        Label e = lbl(etiqueta, esTotal ? F_TITULO : F_BOLD, esTotal ? Color.WHITE : PRIMARIO);
        e.setPrefWidth(150);
        e.setPadding(new Insets(4, 8, 4, 8));
        Label v = lbl("S/ " + valor, esTotal ? F_TITULO : F_NORMAL, esTotal ? Color.WHITE : PRIMARIO);
        v.setPrefWidth(130);
        v.setAlignment(Pos.CENTER_RIGHT);
        v.setPadding(new Insets(4, 8, 4, 8));
        HBox f = new HBox(e, v);
        f.setStyle("-fx-background-color: " + (esTotal ? "#ea580c" : "#f3f4f6") + ";");
        return f;
    }

    private Border borde(Color color, double ancho) {
        return new Border(new BorderStroke(color, BorderStrokeStyle.SOLID, CornerRadii.EMPTY, new BorderWidths(ancho)));
    }
}
