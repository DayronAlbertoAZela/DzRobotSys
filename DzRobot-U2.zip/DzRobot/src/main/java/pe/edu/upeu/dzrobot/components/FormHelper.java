package pe.edu.upeu.dzrobot.components;

import javafx.scene.control.ComboBox;
import pe.edu.upeu.dzrobot.dto.ComboBoxOption;

public final class FormHelper {
    private FormHelper() {
    }

    public static Double parseDouble(String value) {
        if (value == null || value.isBlank()) return null;
        try {
            return Double.parseDouble(value.trim().replace(",", "."));
        } catch (NumberFormatException e) {
            return null;
        }
    }

    public static Integer parseInt(String value) {
        Double d = parseDouble(value);
        return d == null ? null : d.intValue();
    }

    public static String key(ComboBox<ComboBoxOption> cbx) {
        ComboBoxOption o = cbx.getSelectionModel().getSelectedItem();
        return o == null ? null : o.getKey();
    }

    public static void seleccionar(ComboBox<ComboBoxOption> cbx, String key) {
        cbx.getSelectionModel().select(cbx.getItems().stream()
                .filter(o -> o.getKey().equals(key)).findFirst().orElse(null));
    }
}
