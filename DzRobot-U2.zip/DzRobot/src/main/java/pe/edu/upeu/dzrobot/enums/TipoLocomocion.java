package pe.edu.upeu.dzrobot.enums;

public enum TipoLocomocion {
    RUEDAS, ORUGAS, PATAS, AEREO
}
