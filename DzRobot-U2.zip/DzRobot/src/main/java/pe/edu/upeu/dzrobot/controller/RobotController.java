package pe.edu.upeu.dzrobot.controller;

import jakarta.validation.ConstraintViolation;
import jakarta.validation.Validation;
import jakarta.validation.Validator;
import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;
import lombok.RequiredArgsConstructor;
import pe.edu.upeu.dzrobot.components.ColumnInfo;
import pe.edu.upeu.dzrobot.components.TableViewHelper;
import pe.edu.upeu.dzrobot.components.Toast;
import pe.edu.upeu.dzrobot.components.ToltipCustom;
import pe.edu.upeu.dzrobot.dto.ComboBoxOption;
import pe.edu.upeu.dzrobot.enums.*;
import pe.edu.upeu.dzrobot.model.*;
import pe.edu.upeu.dzrobot.service.IClienteService;
import pe.edu.upeu.dzrobot.service.IMarcaService;
import pe.edu.upeu.dzrobot.service.IRobotService;

import java.time.LocalDate;
import java.util.*;
import java.util.function.Consumer;

import static pe.edu.upeu.dzrobot.components.FormHelper.*;

@RequiredArgsConstructor
public class RobotController {
    private final IRobotService rs;
    private final IMarcaService ms;
    private final IClienteService cs;

    @FXML TextField txtCodigo, txtNombre, txtModelo, txtPu, txtUtilidad,
            txtCarga, txtEjes, txtAutonomia, txtPlataforma, txtFiltroDato;
    @FXML DatePicker dpFechaAdq;
    @FXML ComboBox<ComboBoxOption> cbxTipoRobot, cbxEstado, cbxMarca, cbxCliente, cbxLocomocion, cbxNivel;
    @FXML GridPane gpIndustrial, gpMovil, gpEducativo;
    @FXML CheckBox chkAlertas;
    @FXML TableView<Robot> tableView;
    @FXML Label lbnMsg;
    @FXML AnchorPane miContenedor;

    private Validator validator;
    private final ToltipCustom ttc = new ToltipCustom();
    private List<Robot> robots = new ArrayList<>();
    private Robot seleccionado;

    @FXML
    public void initialize() {
        validator = Validation.buildDefaultValidatorFactory().getValidator();

        cbxTipoRobot.getItems().setAll(rs.listarTipoRobot());
        cbxEstado.getItems().setAll(rs.listarEstados());
        cbxMarca.getItems().setAll(ms.listarCombobox());
        cbxCliente.getItems().add(new ComboBoxOption("", "(Empresa - sin dueño)"));
        cbxCliente.getItems().addAll(cs.listarCombobox());
        Arrays.stream(TipoLocomocion.values()).forEach(t -> cbxLocomocion.getItems().add(new ComboBoxOption(t.name(), t.name())));
        Arrays.stream(NivelEducativo.values()).forEach(n -> cbxNivel.getItems().add(new ComboBoxOption(n.name(), n.name())));

        for (GridPane gp : List.of(gpIndustrial, gpMovil, gpEducativo)) gp.managedProperty().bind(gp.visibleProperty());
        cbxTipoRobot.valueProperty().addListener((obs, o, n) -> mostrarCamposTipo());

        LinkedHashMap<String, ColumnInfo> columns = new LinkedHashMap<>();
        columns.put("ID", new ColumnInfo("idRobot", 35.0));
        columns.put("Código", new ColumnInfo("codigo", 70.0));
        columns.put("Tipo", new ColumnInfo("tipoRobot", 95.0));
        columns.put("Nombre", new ColumnInfo("nombre", 112.0));
        columns.put("Estado", new ColumnInfo("estado", 105.0));
        columns.put("Marca", new ColumnInfo("idMarca.nombre", 60.0));
        columns.put("P. Venta", new ColumnInfo("precioVenta", 75.0));
        columns.put("Detalle técnico", new ColumnInfo("detalleTecnico", 115.0));
        columns.put("Próx. mant.", new ColumnInfo("proximoMantenimiento", 85.0));
        columns.put("¿Mant.?", new ColumnInfo("alerta", 60.0));

        Consumer<Robot> updateAction = this::editForm;
        Consumer<Robot> deleteAction = this::eliminar;
        new TableViewHelper<Robot>().addColumnsInOrderWithSize(tableView, columns, updateAction, deleteAction);
        TableViewHelper.pildoras(tableView, "Estado", v -> switch (v) {
            case "EN_STOCK" -> "verde";
            case "VENDIDO" -> "gris";
            case "EN_REPARACION" -> "naranja";
            case "OPERATIVO" -> "celeste";
            default -> "rojo";
        });
        TableViewHelper.pildoras(tableView, "Tipo", v -> v.toUpperCase().startsWith("IND") ? "morado"
                : v.toUpperCase().startsWith("M") ? "celeste" : "naranja");
        TableViewHelper.puntoAlerta(tableView, "¿Mant.?", "Sí", "No");
        tableView.setTableMenuButtonVisible(true);

        txtFiltroDato.textProperty().addListener((obs, o, n) -> filtrar());
        chkAlertas.selectedProperty().addListener((obs, o, n) -> filtrar());
        clearForm();
        listar();
    }

    private void mostrarCamposTipo() {
        String tipo = key(cbxTipoRobot);
        gpIndustrial.setVisible("INDUSTRIAL".equals(tipo));
        gpMovil.setVisible("MOVIL".equals(tipo));
        gpEducativo.setVisible("EDUCATIVO".equals(tipo));
    }

    public void listar() {
        try {
            robots = rs.findAll();
            filtrar();
        } catch (RuntimeException e) {
            mensaje(e.getMessage(), false);
        }
    }

    private void filtrar() {
        String f = txtFiltroDato.getText() == null ? "" : txtFiltroDato.getText().toLowerCase();
        tableView.getItems().setAll(robots.stream()
                .filter(r -> r.getCodigo().toLowerCase().contains(f) || r.getNombre().toLowerCase().contains(f))
                .filter(r -> !chkAlertas.isSelected() || r.necesitaMantenimiento())
                .toList());
    }

    private Robot leerFormulario() {
        String tipo = key(cbxTipoRobot);
        Robot.RobotBuilder<?, ?> b = switch (TipoRobot.valueOf(tipo)) {
            case INDUSTRIAL -> RobotIndustrial.builder()
                    .capacidadCarga(parseDouble(txtCarga.getText()))
                    .numEjes(parseInt(txtEjes.getText()));
            case MOVIL -> RobotMovil.builder()
                    .locomocion(key(cbxLocomocion) == null ? null : TipoLocomocion.valueOf(key(cbxLocomocion)))
                    .autonomia(parseDouble(txtAutonomia.getText()));
            case EDUCATIVO -> RobotEducativo.builder()
                    .plataforma(txtPlataforma.getText())
                    .nivel(key(cbxNivel) == null ? null : NivelEducativo.valueOf(key(cbxNivel)));
        };
        String idMarca = key(cbxMarca);
        String dniruc = key(cbxCliente);
        return b.codigo(txtCodigo.getText().trim().toUpperCase())
                .nombre(txtNombre.getText())
                .modelo(txtModelo.getText())
                .fechaAdq(dpFechaAdq.getValue())
                .fechaUltMant(seleccionado == null ? null : seleccionado.getFechaUltMant())
                .estado(key(cbxEstado) == null ? null : EstadoRobot.valueOf(key(cbxEstado)))
                .pu(parseDouble(txtPu.getText()))
                .utilidad(parseDouble(txtUtilidad.getText()))
                .idMarca(idMarca == null ? null : ms.findById(Long.parseLong(idMarca)))
                .dniruc(dniruc == null || dniruc.isEmpty() ? null : cs.findById(dniruc))
                .build();
    }

    @FXML
    public void validarFormulario() {
        limpiarError();
        if (key(cbxTipoRobot) == null) {
            ttc.marcarError(cbxTipoRobot, "Elija el tipo de robot");
            mensaje("Elija el tipo de robot", false);
            return;
        }
        Robot formulario = leerFormulario();
        List<ConstraintViolation<Robot>> violaciones = validator.validate(formulario).stream()
                .sorted(Comparator.comparing(v -> v.getPropertyPath().toString())).toList();
        if (violaciones.isEmpty()) {
            procesarFormulario(formulario);
        } else {
            mostrarErroresValidacion(violaciones);
        }
    }

    private void procesarFormulario(Robot formulario) {
        Stage stage = (Stage) miContenedor.getScene().getWindow();
        double w = stage.getWidth() / 1.5, h = stage.getHeight() / 2;
        try {
            if (seleccionado != null) {
                formulario.setIdRobot(seleccionado.getIdRobot());
                rs.update(seleccionado.getIdRobot(), formulario);
                Toast.showToast(stage, "Actualizado correctamente", 2000, w, h);
            } else {
                rs.save(formulario);
                Toast.showToast(stage, "Guardado correctamente", 2000, w, h);
            }
            clearForm();
            listar();
        } catch (RuntimeException ex) {
            mensaje(ex.getMessage(), false);
        }
    }

    private void eliminar(Robot robot) {
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION,
                "¿Eliminar el robot " + robot.getCodigo() + " y sus componentes?", ButtonType.YES, ButtonType.NO);
        if (alert.showAndWait().orElse(ButtonType.NO) != ButtonType.YES) return;
        try {
            rs.delete(robot.getIdRobot());
            Stage stage = (Stage) miContenedor.getScene().getWindow();
            Toast.showToast(stage, "Eliminado correctamente", 2000, stage.getWidth() / 1.5, stage.getHeight() / 2);
            clearForm();
            listar();
        } catch (RuntimeException ex) {
            mensaje(ex.getMessage(), false);
        }
    }

    public void editForm(Robot r) {
        clearForm();
        seleccionado = r;
        seleccionar(cbxTipoRobot, r.getTipoRobot().name());
        cbxTipoRobot.setDisable(true);
        txtCodigo.setText(r.getCodigo());
        txtNombre.setText(r.getNombre());
        txtModelo.setText(r.getModelo());
        dpFechaAdq.setValue(r.getFechaAdq());
        seleccionar(cbxEstado, r.getEstado().name());
        txtPu.setText(String.valueOf(r.getPu()));
        txtUtilidad.setText(String.valueOf(r.getUtilidad()));
        seleccionar(cbxMarca, String.valueOf(r.getIdMarca().getIdMarca()));
        seleccionar(cbxCliente, r.getDniruc() == null ? "" : r.getDniruc().getDniruc());
        if (r instanceof RobotIndustrial ri) {
            txtCarga.setText(String.valueOf(ri.getCapacidadCarga()));
            txtEjes.setText(String.valueOf(ri.getNumEjes()));
        } else if (r instanceof RobotMovil rm) {
            seleccionar(cbxLocomocion, rm.getLocomocion().name());
            txtAutonomia.setText(String.valueOf(rm.getAutonomia()));
        } else if (r instanceof RobotEducativo re) {
            txtPlataforma.setText(re.getPlataforma());
            seleccionar(cbxNivel, re.getNivel().name());
        }
        mensaje("Editando " + r.getCodigo(), true);
    }

    @FXML
    public void clearForm() {
        seleccionado = null;
        cbxTipoRobot.setDisable(false);
        List.of(txtCodigo, txtNombre, txtModelo, txtPu, txtUtilidad, txtCarga, txtEjes, txtAutonomia, txtPlataforma)
                .forEach(TextInputControl::clear);
        List.of(cbxTipoRobot, cbxMarca, cbxLocomocion, cbxNivel).forEach(c -> c.getSelectionModel().clearSelection());
        seleccionar(cbxEstado, EstadoRobot.EN_STOCK.name());
        seleccionar(cbxCliente, "");
        dpFechaAdq.setValue(LocalDate.now());
        mostrarCamposTipo();
        limpiarError();
        lbnMsg.setText("");
    }

    private void mostrarErroresValidacion(List<ConstraintViolation<Robot>> violaciones) {
        Map<String, Control> campos = new LinkedHashMap<>();
        campos.put("codigo", txtCodigo);
        campos.put("nombre", txtNombre);
        campos.put("modelo", txtModelo);
        campos.put("fechaAdq", dpFechaAdq);
        campos.put("estado", cbxEstado);
        campos.put("pu", txtPu);
        campos.put("utilidad", txtUtilidad);
        campos.put("idMarca", cbxMarca);
        campos.put("capacidadCarga", txtCarga);
        campos.put("numEjes", txtEjes);
        campos.put("locomocion", cbxLocomocion);
        campos.put("autonomia", txtAutonomia);
        campos.put("plataforma", txtPlataforma);
        campos.put("nivel", cbxNivel);

        Control primero = null;
        String primerMensaje = null;
        for (Map.Entry<String, Control> campo : campos.entrySet()) {
            Optional<ConstraintViolation<Robot>> v = violaciones.stream()
                    .filter(x -> x.getPropertyPath().toString().equals(campo.getKey())).findFirst();
            if (v.isPresent()) {
                ttc.marcarError(campo.getValue(), v.get().getMessage());
                if (primero == null) {
                    primero = campo.getValue();
                    primerMensaje = v.get().getMessage();
                }
            }
        }
        mensaje(primerMensaje, false);
        if (primero != null) Platform.runLater(primero::requestFocus);
    }

    private void mensaje(String texto, boolean ok) {
        if (miContenedor.getScene() == null) {
            lbnMsg.setText(texto);
            return;
        }
        lbnMsg.setText("");
        Toast.Tipo tipo = !ok ? Toast.Tipo.ERROR
                : texto != null && texto.startsWith("Editando") ? Toast.Tipo.INFO : Toast.Tipo.OK;
        Toast.mostrar(miContenedor, texto, tipo);
    }

    public void limpiarError() {
        List.of(txtCodigo, txtNombre, txtModelo, dpFechaAdq, cbxEstado, txtPu, txtUtilidad, cbxMarca, cbxTipoRobot,
                txtCarga, txtEjes, cbxLocomocion, txtAutonomia, txtPlataforma, cbxNivel).forEach(ttc::limpiarCampo);
    }
}
