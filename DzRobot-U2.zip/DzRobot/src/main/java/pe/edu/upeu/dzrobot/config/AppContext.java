package pe.edu.upeu.dzrobot.config;

import pe.edu.upeu.dzrobot.controller.*;
import pe.edu.upeu.dzrobot.repository.*;
import pe.edu.upeu.dzrobot.service.*;
import pe.edu.upeu.dzrobot.service.impl.*;
import pe.edu.upeu.dzrobot.utils.ConsultaDNI;

import java.util.HashMap;
import java.util.Map;

public class AppContext {
    private static AppContext instance;

    public static synchronized AppContext getInstance() {
        if (instance == null) instance = new AppContext();
        return instance;
    }

    private final Map<Class<?>, Object> contenedor = new HashMap<>();

    private AppContext() {
        registrarRepositorios();
        registrarServicios();
        registrarControladores();
    }

    private void registrarRepositorios() {
        registrar(UsuarioRepository.class,    new UsuarioRepository());
        registrar(MarcaRepository.class,      new MarcaRepository());
        registrar(ClienteRepository.class,    new ClienteRepository());
        registrar(RepuestoRepository.class,   new RepuestoRepository());
        registrar(ComponenteRepository.class, new ComponenteRepository());
        registrar(RobotRepository.class,      new RobotRepository(getBean(ComponenteRepository.class)));
        registrar(VentCarritoRepository.class, new VentCarritoRepository());
        registrar(VentaRepository.class,      new VentaRepository());
        registrar(EmisorRepository.class,     new EmisorRepository());
    }

    private void registrarServicios() {
        registrar(IUsuarioService.class,  new UsuarioServiceImp(getBean(UsuarioRepository.class)));
        registrar(IMarcaService.class,    new MarcaServiceImp(getBean(MarcaRepository.class)));
        registrar(IClienteService.class,  new ClienteServiceImp(getBean(ClienteRepository.class)));
        registrar(IRepuestoService.class, new RepuestoServiceImp(getBean(RepuestoRepository.class)));
        registrar(IRobotService.class,    new RobotServiceImp(getBean(RobotRepository.class)));
        registrar(IMenuMenuItemDao.class, new MenuMenuItemDaoImp());
        registrar(IVentCarritoService.class, new VentCarritoServiceImp(getBean(VentCarritoRepository.class),
                getBean(IRobotService.class), getBean(IRepuestoService.class), getBean(IClienteService.class)));
        registrar(IVentaService.class, new VentaServiceImp(getBean(VentaRepository.class), getBean(EmisorRepository.class),
                getBean(IVentCarritoService.class), getBean(IClienteService.class), getBean(IUsuarioService.class),
                getBean(IRobotService.class), getBean(IRepuestoService.class)));
        registrar(ConsultaDNI.class, new ConsultaDNI());
    }

    private void registrarControladores() {
        registrar(LoginController.class, new LoginController(getBean(IUsuarioService.class)));
        registrar(MainGuiController.class, new MainGuiController(
                getBean(IMenuMenuItemDao.class), getBean(IRobotService.class), getBean(IRepuestoService.class)));
        registrar(RobotController.class, new RobotController(
                getBean(IRobotService.class), getBean(IMarcaService.class), getBean(IClienteService.class)));
        registrar(RepuestoController.class, new RepuestoController(
                getBean(IRepuestoService.class), getBean(IMarcaService.class)));
        registrar(ClienteController.class, new ClienteController(getBean(IClienteService.class)));
        registrar(VentaController.class, new VentaController(getBean(IVentaService.class),
                getBean(IVentCarritoService.class), getBean(IClienteService.class), getBean(ConsultaDNI.class)));
    }

    private void registrar(Class<?> tipo, Object bean) {
        contenedor.put(tipo, bean);
    }

    @SuppressWarnings("unchecked")
    public <T> T getBean(Class<T> tipo) {
        Object bean = contenedor.get(tipo);
        if (bean == null) {
            bean = contenedor.values().stream()
                    .filter(b -> tipo.isAssignableFrom(b.getClass()))
                    .findFirst()
                    .orElseThrow(() -> new RuntimeException(
                            "Bean no encontrado: " + tipo.getName() + "\n→ ¿Lo registraste en AppContext?"));
        }
        return (T) bean;
    }
}
