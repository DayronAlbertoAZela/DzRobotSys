package pe.edu.upeu.dzrobot.controller;

import jakarta.validation.ConstraintViolation;
import jakarta.validation.Validation;
import jakarta.validation.Validator;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import lombok.RequiredArgsConstructor;
import pe.edu.upeu.dzrobot.components.ColumnInfo;
import pe.edu.upeu.dzrobot.components.TableViewHelper;
import pe.edu.upeu.dzrobot.components.Toast;
import pe.edu.upeu.dzrobot.components.ToltipCustom;
import pe.edu.upeu.dzrobot.dto.ComboBoxOption;
import pe.edu.upeu.dzrobot.enums.TipoRepuesto;
import pe.edu.upeu.dzrobot.model.Repuesto;
import pe.edu.upeu.dzrobot.service.IMarcaService;
import pe.edu.upeu.dzrobot.service.IRepuestoService;

import java.util.*;

import static pe.edu.upeu.dzrobot.components.FormHelper.*;

@RequiredArgsConstructor
public class RepuestoController {
    private final IRepuestoService rs;
    private final IMarcaService ms;

    @FXML TextField txtCodigo, txtModelo, txtNombre, txtPu, txtUtilidad, txtStock, txtVidaUtil, txtFiltroDato;
    @FXML ComboBox<ComboBoxOption> cbxTipoRepuesto, cbxMarca;
    @FXML TableView<Repuesto> tableView;
    @FXML Label lbnMsg;
    @FXML AnchorPane miContenedor;

    private Validator validator;
    private final ToltipCustom ttc = new ToltipCustom();
    private List<Repuesto> repuestos = new ArrayList<>();
    private Long idRepuestoCE = 0L;

    @FXML
    public void initialize() {
        validator = Validation.buildDefaultValidatorFactory().getValidator();
        cbxTipoRepuesto.getItems().setAll(rs.listarTipoRepuesto());
        cbxMarca.getItems().setAll(ms.listarCombobox());

        LinkedHashMap<String, ColumnInfo> columns = new LinkedHashMap<>();
                columns.put("Código", new ColumnInfo("codigo", 80.0));
        columns.put("Nombre", new ColumnInfo("nombre", 150.0));
        columns.put("Modelo", new ColumnInfo("modelo", 80.0));
        columns.put("Tipo", new ColumnInfo("tipoRepuesto", 100.0));
        columns.put("P. Unit.", new ColumnInfo("pu", 80.0));
        columns.put("Utilidad", new ColumnInfo("utilidad", 65.0));
        columns.put("P. Venta", new ColumnInfo("precioVenta", 80.0));
        columns.put("Stock", new ColumnInfo("stock", 60.0));
        columns.put("Vida útil (h)", new ColumnInfo("vidaUtil", 90.0));
        columns.put("Marca", new ColumnInfo("idMarca.nombre", 90.0));
        new TableViewHelper<Repuesto>().addColumnsInOrderWithSize(tableView, columns, this::editForm, this::eliminar);
        TableViewHelper.pildoras(tableView, "Tipo", v -> "celeste");

        TableViewHelper.pildoras(tableView, "Stock",
                v -> Double.parseDouble(v) <= pe.edu.upeu.dzrobot.service.impl.RepuestoServiceImp.STOCK_MINIMO ? "naranja" : "verde");

        txtFiltroDato.textProperty().addListener((obs, o, n) -> filtrar());
        listar();
    }

    public void listar() {
        try {
            repuestos = rs.findAll();
            filtrar();
        } catch (RuntimeException e) {
            mensaje(e.getMessage(), false);
        }
    }

    private void filtrar() {
        String f = txtFiltroDato.getText() == null ? "" : txtFiltroDato.getText().toLowerCase();
        tableView.getItems().setAll(repuestos.stream().filter(r -> (r.getCodigo() + " " + r.getNombre()).toLowerCase().contains(f)).toList());
    }

    @FXML
    public void validarFormulario() {
        limpiarError();
        String marca = key(cbxMarca);
        Repuesto formulario = Repuesto.builder()
                .codigo(txtCodigo.getText() == null ? null : txtCodigo.getText().trim().toUpperCase())
                .nombre(txtNombre.getText())
                .modelo(txtModelo.getText())
                .tipoRepuesto(key(cbxTipoRepuesto) == null ? null : TipoRepuesto.valueOf(key(cbxTipoRepuesto)))
                .pu(parseDouble(txtPu.getText()))
                .utilidad(parseDouble(txtUtilidad.getText()))
                .stock(parseDouble(txtStock.getText()))
                .vidaUtil(parseDouble(txtVidaUtil.getText()))
                .idMarca(marca == null ? null : ms.findById(Long.parseLong(marca)))
                .build();

        List<ConstraintViolation<Repuesto>> violaciones = validator.validate(formulario).stream()
                .sorted(Comparator.comparing(v -> v.getPropertyPath().toString())).toList();
        if (!violaciones.isEmpty()) {
            mostrarErroresValidacion(violaciones);
            return;
        }
        Stage stage = (Stage) miContenedor.getScene().getWindow();
        double w = stage.getWidth() / 1.5, h = stage.getHeight() / 2;
        try {
            if (idRepuestoCE > 0L) {
                formulario.setIdRepuesto(idRepuestoCE);
                rs.update(idRepuestoCE, formulario);
                Toast.showToast(stage, "Actualizado correctamente", 2000, w, h);
            } else {
                rs.save(formulario);
                Toast.showToast(stage, "Guardado correctamente", 2000, w, h);
            }
            clearForm();
            listar();
        } catch (RuntimeException ex) {
            mensaje(ex.getMessage(), false);
        }
    }

    private void eliminar(Repuesto r) {
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION, "¿Eliminar " + r.getNombre() + "?", ButtonType.YES, ButtonType.NO);
        if (alert.showAndWait().orElse(ButtonType.NO) != ButtonType.YES) return;
        try {
            rs.delete(r.getIdRepuesto());
            listar();
            mensaje("Se eliminó " + r.getNombre(), true);
        } catch (RuntimeException ex) {
            mensaje("No se puede eliminar: está en uso en componentes, ventas o importaciones", false);
        }
    }

    public void editForm(Repuesto r) {
        clearForm();
        txtCodigo.setText(r.getCodigo());
        txtNombre.setText(r.getNombre());
        txtModelo.setText(r.getModelo());
        seleccionar(cbxTipoRepuesto, r.getTipoRepuesto().name());
        txtPu.setText(String.valueOf(r.getPu()));
        txtUtilidad.setText(String.valueOf(r.getUtilidad()));
        txtStock.setText(String.valueOf(r.getStock()));
        txtVidaUtil.setText(String.valueOf(r.getVidaUtil()));
        seleccionar(cbxMarca, String.valueOf(r.getIdMarca().getIdMarca()));
        idRepuestoCE = r.getIdRepuesto();
        mensaje("Editando " + r.getNombre(), true);
    }

    @FXML
    public void clearForm() {
        List.of(txtCodigo, txtNombre, txtModelo, txtPu, txtUtilidad, txtStock, txtVidaUtil).forEach(TextInputControl::clear);
        cbxTipoRepuesto.getSelectionModel().clearSelection();
        cbxMarca.getSelectionModel().clearSelection();
        idRepuestoCE = 0L;
        limpiarError();
        lbnMsg.setText("");
    }

    private void mostrarErroresValidacion(List<ConstraintViolation<Repuesto>> violaciones) {
        Map<String, Control> campos = new LinkedHashMap<>();
        campos.put("codigo", txtCodigo);
        campos.put("nombre", txtNombre);
        campos.put("modelo", txtModelo);
        campos.put("tipoRepuesto", cbxTipoRepuesto);
        campos.put("pu", txtPu);
        campos.put("utilidad", txtUtilidad);
        campos.put("stock", txtStock);
        campos.put("vidaUtil", txtVidaUtil);
        campos.put("idMarca", cbxMarca);
        String primero = null;
        for (Map.Entry<String, Control> c : campos.entrySet()) {
            for (ConstraintViolation<Repuesto> v : violaciones) {
                if (v.getPropertyPath().toString().equals(c.getKey())) {
                    ttc.marcarError(c.getValue(), v.getMessage());
                    if (primero == null) primero = v.getMessage();
                }
            }
        }
        mensaje(primero, false);
    }

    private void mensaje(String texto, boolean ok) {
        if (miContenedor.getScene() == null) {
            lbnMsg.setText(texto);
            return;
        }
        lbnMsg.setText("");
        Toast.Tipo tipo = !ok ? Toast.Tipo.ERROR
                : texto != null && texto.startsWith("Editando") ? Toast.Tipo.INFO : Toast.Tipo.OK;
        Toast.mostrar(miContenedor, texto, tipo);
    }

    private void limpiarError() {
        List.of(txtNombre, cbxTipoRepuesto, txtPu, txtUtilidad, txtStock, txtVidaUtil, cbxMarca).forEach(ttc::limpiarCampo);
    }
}
