package pe.edu.upeu.dzrobot.components.comprob;

import com.lowagie.text.Chunk;
import com.lowagie.text.Document;
import com.lowagie.text.Element;
import com.lowagie.text.Font;
import com.lowagie.text.FontFactory;
import com.lowagie.text.Image;
import com.lowagie.text.PageSize;
import com.lowagie.text.Paragraph;
import com.lowagie.text.Phrase;
import com.lowagie.text.Rectangle;
import com.lowagie.text.pdf.PdfPCell;
import com.lowagie.text.pdf.PdfPTable;
import com.lowagie.text.pdf.PdfWriter;
import pe.edu.upeu.dzrobot.DzRobot;
import pe.edu.upeu.dzrobot.dto.comprobante.Comprobante;
import pe.edu.upeu.dzrobot.dto.comprobante.ItemComprobante;
import pe.edu.upeu.dzrobot.utils.NumeroLetras;

import java.awt.Color;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;

public class ComprobantePdfService {
    private static final Color PRIMARIO = new Color(0x1f, 0x29, 0x37);
    private static final Color ACENTO = new Color(0xea, 0x58, 0x0c);
    private static final Color CLARO = new Color(0xf3, 0xf4, 0xf6);

    private static final Font F_NORMAL = FontFactory.getFont(FontFactory.HELVETICA, 10, PRIMARIO);
    private static final Font F_BOLD = FontFactory.getFont(FontFactory.HELVETICA_BOLD, 10, PRIMARIO);
    private static final Font F_TITULO = FontFactory.getFont(FontFactory.HELVETICA_BOLD, 13, PRIMARIO);
    private static final Font F_ACENTO = FontFactory.getFont(FontFactory.HELVETICA_BOLD, 12, ACENTO);
    private static final Font F_BLANCO = FontFactory.getFont(FontFactory.HELVETICA_BOLD, 10, Color.WHITE);

    public void exportar(Comprobante b, Path destino) throws Exception {
        try (OutputStream os = Files.newOutputStream(destino)) {
            exportar(b, os);
        }
    }

    public void exportar(Comprobante b, OutputStream os) throws Exception {
        Document doc = new Document(PageSize.A4, 36, 36, 36, 36);
        PdfWriter.getInstance(doc, os);
        doc.open();
        doc.add(cabecera(b));
        doc.add(new Paragraph(" "));
        doc.add(cliente(b));
        doc.add(Chunk.NEWLINE);
        doc.add(items(b));
        doc.add(Chunk.NEWLINE);
        doc.add(totales(b));
        doc.add(Chunk.NEWLINE);
        Paragraph pie = new Paragraph("Representación impresa de la " + b.getTipoDocumento()
                + "\nGracias por confiar en DzRobot", F_NORMAL);
        pie.setAlignment(Element.ALIGN_CENTER);
        doc.add(pie);
        doc.close();
    }

    private PdfPTable cabecera(Comprobante b) throws Exception {
        PdfPTable t = new PdfPTable(new float[]{12, 50, 38});
        t.setWidthPercentage(100);
        PdfPCell logo = new PdfPCell();
        logo.setBorder(Rectangle.NO_BORDER);
        try (InputStream in = DzRobot.class.getResourceAsStream("/img/dzrobot-logo.png")) {
            if (in != null) {
                Image img = Image.getInstance(in.readAllBytes());
                img.scaleToFit(54, 54);
                logo.addElement(img);
            }
        }
        PdfPCell emisor = new PdfPCell();
        emisor.setBorder(Rectangle.NO_BORDER);
        emisor.addElement(new Paragraph(b.getRazonSocial(), F_TITULO));
        emisor.addElement(new Paragraph("RUC: " + b.getRucEmisor(), F_BOLD));
        emisor.addElement(new Paragraph(b.getDireccion(), F_NORMAL));
        emisor.addElement(new Paragraph(b.getUbigeo(), F_NORMAL));
        PdfPCell docu = new PdfPCell();
        docu.setBorderColor(ACENTO);
        docu.setBorderWidth(2);
        docu.setPadding(10);
        centrado(docu, b.getTipoDocumento(), F_ACENTO);
        centrado(docu, "R.U.C. " + b.getRucEmisor(), F_BOLD);
        centrado(docu, b.getSerie() + " - " + b.getNumero(), F_ACENTO);
        t.addCell(logo);
        t.addCell(emisor);
        t.addCell(docu);
        return t;
    }

    private PdfPTable cliente(Comprobante b) {
        PdfPTable t = new PdfPTable(new float[]{25, 75});
        t.setWidthPercentage(100);
        t.addCell(banda("DATOS DEL CLIENTE", 2));
        fila(t, b.getTipoDocCliente(), b.getNroDocCliente());
        fila(t, "Cliente", b.getNombreCliente());
        fila(t, "Dirección", b.getDireccionCliente());
        fila(t, "Fecha / Moneda", b.getFechaEmision() + "  |  " + b.getMoneda() + "  |  Vendedor: " + b.getVendedor());
        return t;
    }

    private PdfPTable items(Comprobante b) {
        PdfPTable t = new PdfPTable(new float[]{9, 45, 16, 13, 17});
        t.setWidthPercentage(100);
        t.addCell(banda("DETALLE", 5));
        t.addCell(encabezado("CANT.", Element.ALIGN_CENTER));
        t.addCell(encabezado("DESCRIPCIÓN", Element.ALIGN_LEFT));
        t.addCell(encabezado("P. UNIT", Element.ALIGN_RIGHT));
        t.addCell(encabezado("DSCTO.", Element.ALIGN_RIGHT));
        t.addCell(encabezado("SUBTOTAL", Element.ALIGN_RIGHT));
        for (int i = 0; i < b.getItems().size(); i++) {
            ItemComprobante it = b.getItems().get(i);
            Color bg = i % 2 == 0 ? Color.WHITE : CLARO;
            t.addCell(dato(it.getCantidadTexto(), Element.ALIGN_CENTER, bg));
            t.addCell(dato(it.getDescripcion(), Element.ALIGN_LEFT, bg));
            t.addCell(dato("S/ " + it.getPrecioUnitario(), Element.ALIGN_RIGHT, bg));
            t.addCell(dato("S/ " + it.getDescuento(), Element.ALIGN_RIGHT, bg));
            t.addCell(dato("S/ " + it.getSubtotal(), Element.ALIGN_RIGHT, bg));
        }
        return t;
    }

    private PdfPTable totales(Comprobante b) {
        PdfPTable t = new PdfPTable(new float[]{55, 45});
        t.setWidthPercentage(100);
        PdfPCell izq = new PdfPCell();
        izq.setBorder(Rectangle.NO_BORDER);
        izq.setPaddingRight(10);
        izq.addElement(new Paragraph("SON:", F_BOLD));
        izq.addElement(new Paragraph(NumeroLetras.soles(b.getTotal()), F_NORMAL));
        PdfPCell der = new PdfPCell();
        der.setBorder(Rectangle.NO_BORDER);
        PdfPTable montos = new PdfPTable(new float[]{60, 40});
        montos.setWidthPercentage(100);
        monto(montos, "Op. Gravadas", "S/ " + b.getOpGravadas(), false);
        monto(montos, "IGV (18%)", "S/ " + b.getIgv(), false);
        monto(montos, "TOTAL", "S/ " + b.getTotal(), true);
        der.addElement(montos);
        t.addCell(izq);
        t.addCell(der);
        return t;
    }

    private void centrado(PdfPCell celda, String texto, Font f) {
        Paragraph p = new Paragraph(texto, f);
        p.setAlignment(Element.ALIGN_CENTER);
        celda.addElement(p);
    }

    private PdfPCell banda(String texto, int colspan) {
        PdfPCell c = new PdfPCell(new Phrase(texto, F_BLANCO));
        c.setColspan(colspan);
        c.setBackgroundColor(PRIMARIO);
        c.setPadding(4);
        c.setBorder(Rectangle.NO_BORDER);
        return c;
    }

    private PdfPCell encabezado(String texto, int align) {
        PdfPCell c = new PdfPCell(new Phrase(texto, F_BLANCO));
        c.setBackgroundColor(PRIMARIO);
        c.setPadding(5);
        c.setHorizontalAlignment(align);
        c.setBorderColor(CLARO);
        return c;
    }

    private PdfPCell dato(String texto, int align, Color bg) {
        PdfPCell c = new PdfPCell(new Phrase(texto, F_NORMAL));
        c.setBackgroundColor(bg);
        c.setPadding(4);
        c.setHorizontalAlignment(align);
        c.setBorderColor(CLARO);
        return c;
    }

    private void fila(PdfPTable t, String etiqueta, String valor) {
        t.addCell(dato(etiqueta, Element.ALIGN_LEFT, CLARO));
        t.addCell(dato(valor, Element.ALIGN_LEFT, Color.WHITE));
    }

    private void monto(PdfPTable t, String etiqueta, String valor, boolean total) {
        Font f = total ? F_BLANCO : F_BOLD;
        Color bg = total ? ACENTO : CLARO;
        PdfPCell e = new PdfPCell(new Phrase(etiqueta, f));
        e.setBackgroundColor(bg);
        e.setPadding(4);
        e.setBorderColor(CLARO);
        PdfPCell v = new PdfPCell(new Phrase(valor, f));
        v.setBackgroundColor(bg);
        v.setPadding(4);
        v.setBorderColor(CLARO);
        v.setHorizontalAlignment(Element.ALIGN_RIGHT);
        t.addCell(e);
        t.addCell(v);
    }
}
