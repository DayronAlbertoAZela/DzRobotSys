package pe.edu.upeu.dzrobot.repository;

import pe.edu.upeu.dzrobot.enums.TipoRepuesto;
import pe.edu.upeu.dzrobot.model.Componente;
import pe.edu.upeu.dzrobot.model.Repuesto;

import java.sql.Connection;
import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

public class ComponenteRepository extends AbstractJpaRepository<Componente, Long> {

    private static final String SELECT_JOIN =
            "SELECT c.*, r.nombre AS rep_nombre, r.tipo AS tipo_repuesto, r.vida_util FROM componente c " +
                    "JOIN producto r ON c.id_repuesto = r.id_producto ";

    @Override
    protected String getTableName() {return "componente";}

    @Override
    protected String getPkColumn() {return "id_componente";}

    @Override
    public List<Componente> findAll() {return executeQuery(SELECT_JOIN);}

    public List<Componente> listarPorRobot(Long idRobot) {
        return executeQuery(SELECT_JOIN + "WHERE c.id_producto = ? AND c.estado = 'ACTIVO'", idRobot);
    }

    @Override
    protected Componente mapRow(ResultSet rs) throws SQLException {
        return Componente.builder()
                .idComponente(rs.getLong("id_componente"))
                .numSerie(rs.getString("num_serie"))
                .horasUso(rs.getDouble("horas_uso"))
                .fechaInst(rs.getDate("fecha_inst").toLocalDate())
                .estado(rs.getString("estado"))
                .idRobot(rs.getLong("id_producto"))
                .idRepuesto(Repuesto.builder()
                        .idRepuesto(rs.getLong("id_repuesto"))
                        .nombre(rs.getString("rep_nombre"))
                        .tipoRepuesto(TipoRepuesto.valueOf(rs.getString("tipo_repuesto")))
                        .vidaUtil(rs.getDouble("vida_util")).build())
                .build();
    }

    @Override
    protected Componente insert(Connection conn, Componente e) throws SQLException {
        long id = executeInsertGetKey(conn,
                "INSERT INTO componente(num_serie,horas_uso,fecha_inst,estado,id_producto,id_repuesto) VALUES(?,?,?,?,?,?)",
                e.getNumSerie(), e.getHorasUso(), Date.valueOf(e.getFechaInst()), e.getEstado(),
                e.getIdRobot(), e.getIdRepuesto().getIdRepuesto());
        e.setIdComponente(id);
        return e;
    }

    @Override
    protected Componente updateRow(Connection conn, Componente e) throws SQLException {
        executeUpdate(conn,
                "UPDATE componente SET num_serie=?,horas_uso=?,fecha_inst=?,estado=?,id_producto=?,id_repuesto=? WHERE id_componente=?",
                e.getNumSerie(), e.getHorasUso(), Date.valueOf(e.getFechaInst()), e.getEstado(),
                e.getIdRobot(), e.getIdRepuesto().getIdRepuesto(), e.getIdComponente());
        return e;
    }
}
