package pe.edu.upeu.dzrobot.service.impl;

import lombok.RequiredArgsConstructor;
import pe.edu.upeu.dzrobot.model.Usuario;
import pe.edu.upeu.dzrobot.repository.ICrudGenericoRepository;
import pe.edu.upeu.dzrobot.repository.UsuarioRepository;
import pe.edu.upeu.dzrobot.service.IUsuarioService;
import pe.edu.upeu.dzrobot.util.PasswordUtil;

import java.util.Optional;

@RequiredArgsConstructor
public class UsuarioServiceImp extends CrudGenericoServiceImp<Usuario, Long> implements IUsuarioService {
    private final UsuarioRepository repo;

    @Override
    protected ICrudGenericoRepository<Usuario, Long> getRepo() {
        return repo;
    }

    @Override
    public Optional<Usuario> loginUsuario(String usuario, String clave) {
        return repo.buscarUsuario(usuario.trim().toLowerCase())
                .filter(u -> "ACTIVO".equals(u.getEstado()))
                .filter(u -> PasswordUtil.verificar(clave, u.getClave()));
    }

    @Override
    public Usuario save(Usuario u) {
        u.setClave(PasswordUtil.hashear(u.getClave()));
        return super.save(u);
    }
}
