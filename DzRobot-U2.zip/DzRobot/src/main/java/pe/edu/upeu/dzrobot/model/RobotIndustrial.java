package pe.edu.upeu.dzrobot.model;

import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;
import pe.edu.upeu.dzrobot.enums.TipoRobot;

import java.time.LocalDate;

@Data
@EqualsAndHashCode(callSuper = true)
@NoArgsConstructor
@SuperBuilder
public class RobotIndustrial extends Robot {
    @NotNull(message = "La capacidad de carga es obligatoria")
    @Positive(message = "La capacidad de carga debe ser positiva")
    private Double capacidadCarga;
    @NotNull(message = "El número de ejes es obligatorio")
    @Min(value = 1, message = "Mínimo 1 eje")
    @Max(value = 12, message = "Máximo 12 ejes")
    private Integer numEjes;

    @Override
    public LocalDate calcularProximoMantenimiento() {
        return getFechaBase().plusDays(capacidadCarga > 500 ? 60 : 90);
    }

    @Override
    public TipoRobot getTipoRobot() {
        return TipoRobot.INDUSTRIAL;
    }

    @Override
    public String getDetalleTecnico() {
        return capacidadCarga + " kg, " + numEjes + " ejes";
    }
}
