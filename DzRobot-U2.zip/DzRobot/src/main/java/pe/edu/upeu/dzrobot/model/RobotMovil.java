package pe.edu.upeu.dzrobot.model;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;
import pe.edu.upeu.dzrobot.enums.TipoLocomocion;
import pe.edu.upeu.dzrobot.enums.TipoRobot;

import java.time.LocalDate;

@Data
@EqualsAndHashCode(callSuper = true)
@NoArgsConstructor
@SuperBuilder
public class RobotMovil extends Robot {
    @NotNull(message = "La locomoción es obligatoria")
    private TipoLocomocion locomocion;
    @NotNull(message = "La autonomía es obligatoria")
    @Positive(message = "La autonomía debe ser positiva")
    private Double autonomia;

    @Override
    public LocalDate calcularProximoMantenimiento() {
        return getFechaBase().plusDays(locomocion == TipoLocomocion.AEREO ? 45 : 120);
    }

    @Override
    public TipoRobot getTipoRobot() {
        return TipoRobot.MOVIL;
    }

    @Override
    public String getDetalleTecnico() {
        return locomocion + ", " + autonomia + " h de batería";
    }
}
