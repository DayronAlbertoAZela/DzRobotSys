package pe.edu.upeu.dzrobot.modulos;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.TableCell;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.layout.Priority;
import javafx.scene.layout.VBox;
import pe.edu.upeu.dzrobot.components.Toast;
import pe.edu.upeu.dzrobot.operaciones.OperacionRepository;
import pe.edu.upeu.dzrobot.repository.ConsultaRepository;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;

import static pe.edu.upeu.dzrobot.modulos.Columna.pildora;
import static pe.edu.upeu.dzrobot.modulos.Columna.texto;

public class ReporteFallas {

    private static final String SQL = "SELECT f.id_falla, f.fecha_reporte, CONCAT(r.codigo, ' ', r.nombre) AS robot, "
            + "f.descripcion, f.gravedad, f.estado, "
            + "CASE WHEN f.id_mantenimiento IS NULL THEN '-' ELSE CONCAT('N° ', f.id_mantenimiento) END AS mantenimiento "
            + "FROM falla f JOIN producto r ON r.id_producto = f.id_producto ";

    private final ConsultaRepository consultas;
    private final OperacionRepository operaciones = new OperacionRepository();

    private final ComboBox<Opcion> cbRobot = new ComboBox<>();
    private final ComboBox<String> cbGravedad = new ComboBox<>();
    private final DatePicker dpFecha = new DatePicker(LocalDate.now());
    private final TextField txtDescripcion = new TextField();
    private final ComboBox<String> cbVer = new ComboBox<>();
    private final Label lblResumen = new Label();
    private TableView<Map<String, Object>> tabla;

    public ReporteFallas(ConsultaRepository consultas) {
        this.consultas = consultas;
    }

    public Node crear() {
        Label titulo = new Label("Reportar fallas");
        titulo.getStyleClass().add("titulo-modulo");

        cbRobot.setPrefWidth(280);
        cbGravedad.getItems().addAll("BAJA", "MEDIA", "ALTA");
        cbGravedad.setValue("MEDIA");
        txtDescripcion.setPromptText("Qué le pasa al robot");
        txtDescripcion.setPrefWidth(420);
        Button btnReportar = new Button("Reportar falla");
        btnReportar.getStyleClass().add("btn-primario");
        btnReportar.setOnAction(e -> reportar());

        GridPane form = new GridPane();
        form.setHgap(10);
        form.setVgap(8);
        form.addRow(0, new Label("Robot"), cbRobot, new Label("Gravedad"), cbGravedad, new Label("Fecha"), dpFecha);
        form.add(new Label("Descripción"), 0, 1);
        form.add(txtDescripcion, 1, 1, 3, 1);
        form.add(btnReportar, 5, 1);
        form.getStyleClass().add("panel");

        cbVer.getItems().addAll("Pendientes", "Todas");
        cbVer.setValue("Pendientes");
        cbVer.valueProperty().addListener((o, a, b) -> listar());
        Pane espacio = new Pane();
        HBox.setHgrow(espacio, Priority.ALWAYS);
        HBox barra = new HBox(10, lblResumen, espacio, new Label("Ver"), cbVer);
        barra.setAlignment(Pos.CENTER_LEFT);
        lblResumen.getStyleClass().add("dash-subtitulo");

        tabla = TablaMapa.crear(List.of(
                texto("Fecha", "fecha_reporte", 95), texto("Robot", "robot", 190), texto("Descripción", "descripcion", 300),
                pildora("Gravedad", "gravedad", 95, v -> "ALTA".equals(v) ? "rojo" : "MEDIA".equals(v) ? "naranja" : "gris"),
                pildora("Estado", "estado", 120, v -> "RESUELTA".equals(v) ? "verde" : "EN_ATENCION".equals(v) ? "celeste" : "naranja"),
                texto("Mantenimiento", "mantenimiento", 110)));
        agregarAccion();
        VBox.setVgrow(tabla, Priority.ALWAYS);

        VBox raiz = new VBox(10, titulo, form, barra, tabla);
        raiz.setPadding(new Insets(10));
        cargarRobots();
        listar();
        return raiz;
    }

    private void cargarRobots() {
        cbRobot.getItems().clear();
        for (Map<String, Object> f : consultas.filas(
                "SELECT id_producto, codigo, nombre FROM producto WHERE tipo IN ('INDUSTRIAL', 'MOVIL', 'EDUCATIVO') AND estado <> 'DE_BAJA' ORDER BY codigo")) {
            cbRobot.getItems().add(new Opcion(f.get("id_producto"), f.get("codigo") + " " + f.get("nombre"), 0, null));
        }
    }

    private void listar() {
        try {
            boolean pendientes = "Pendientes".equals(cbVer.getValue());
            List<Map<String, Object>> filas = consultas.filas(SQL + (pendientes ? "WHERE f.estado <> 'RESUELTA' " : "")
                    + "ORDER BY f.fecha_reporte DESC, f.id_falla DESC");
            tabla.getItems().setAll(filas);
            long altas = filas.stream().filter(f -> "ALTA".equals(f.get("gravedad")) && !"RESUELTA".equals(f.get("estado"))).count();
            String palabra = filas.size() == 1 ? " falla" : " fallas";
            lblResumen.setText(filas.size() + palabra + (pendientes ? (filas.size() == 1 ? " pendiente" : " pendientes")
                    : (filas.size() == 1 ? " registrada" : " registradas"))
                    + (altas > 0 ? "  ·  " + altas + " de gravedad alta" : ""));
        } catch (RuntimeException e) {
            Toast.mostrar(tabla, e.getMessage(), Toast.Tipo.ERROR);
        }
    }

    private void reportar() {
        String descripcion = txtDescripcion.getText().trim();
        if (cbRobot.getValue() == null) {
            Toast.mostrar(tabla, "Elija el robot", Toast.Tipo.ERROR);
            return;
        }
        if (descripcion.length() < 5 || descripcion.length() > 100) {
            Toast.mostrar(tabla, "La descripción debe tener de 5 a 100 caracteres", Toast.Tipo.ERROR);
            return;
        }
        if (dpFecha.getValue() == null || dpFecha.getValue().isAfter(LocalDate.now())) {
            Toast.mostrar(tabla, "La fecha no puede ser futura", Toast.Tipo.ERROR);
            return;
        }
        try {
            long id = operaciones.reportarFalla(cbRobot.getValue().id(), descripcion, cbGravedad.getValue(), dpFecha.getValue());
            Toast.mostrar(tabla, "Falla N° " + id + " reportada", Toast.Tipo.OK);
            txtDescripcion.clear();
            cbRobot.setValue(null);
            cbGravedad.setValue("MEDIA");
            dpFecha.setValue(LocalDate.now());
            listar();
        } catch (RuntimeException e) {
            Toast.mostrar(tabla, e.getMessage(), Toast.Tipo.ERROR);
        }
    }

    private void agregarAccion() {
        TableColumn<Map<String, Object>, Void> col = new TableColumn<>("Acción");
        col.setPrefWidth(140);
        col.setCellFactory(x -> new TableCell<>() {
            private final Button boton = new Button("Marcar resuelta");

            {
                boton.setOnAction(e -> {
                    Map<String, Object> fila = getTableView().getItems().get(getIndex());
                    try {
                        operaciones.resolverFalla(fila.get("id_falla"));
                        Toast.mostrar(tabla, "Falla N° " + fila.get("id_falla") + " resuelta", Toast.Tipo.OK);
                        listar();
                    } catch (RuntimeException ex) {
                        Toast.mostrar(tabla, ex.getMessage(), Toast.Tipo.ERROR);
                    }
                });
            }

            @Override
            protected void updateItem(Void item, boolean empty) {
                super.updateItem(item, empty);
                boolean mostrar = !empty && getIndex() < getTableView().getItems().size()
                        && !"RESUELTA".equals(getTableView().getItems().get(getIndex()).get("estado"));
                setGraphic(mostrar ? boton : null);
            }
        });
        tabla.getColumns().add(col);
    }
}
