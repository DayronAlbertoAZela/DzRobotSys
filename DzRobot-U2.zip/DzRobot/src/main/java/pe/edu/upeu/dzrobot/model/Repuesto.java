package pe.edu.upeu.dzrobot.model;

import jakarta.validation.constraints.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import pe.edu.upeu.dzrobot.enums.TipoRepuesto;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Repuesto {
    private Long idRepuesto;
    @NotBlank(message = "El código es obligatorio")
    @Pattern(regexp = "[A-Z0-9-]{3,20}", message = "Código: mayúsculas, números y guiones (3 a 20)")
    private String codigo;
    @NotBlank(message = "El nombre es obligatorio")
    private String nombre;
    @NotNull(message = "El tipo de repuesto es obligatorio")
    private TipoRepuesto tipoRepuesto;
    @NotBlank(message = "El modelo es obligatorio")
    private String modelo;
    @NotNull(message = "El precio es obligatorio")
    @Positive(message = "El precio debe ser positivo")
    private Double pu;
    @NotNull(message = "La utilidad es obligatoria")
    @PositiveOrZero(message = "La utilidad no puede ser negativa")
    private Double utilidad;
    @NotNull(message = "El stock es obligatorio")
    @PositiveOrZero(message = "El stock no puede ser negativo")
    private Double stock;
    @NotNull(message = "La vida útil es obligatoria")
    @Positive(message = "La vida útil debe ser positiva")
    private Double vidaUtil;
    @NotNull(message = "La marca es obligatoria")
    private Marca idMarca;

    public double getPrecioVenta() {
        return Math.round((pu + pu * utilidad) * 100.0) / 100.0;
    }
}
