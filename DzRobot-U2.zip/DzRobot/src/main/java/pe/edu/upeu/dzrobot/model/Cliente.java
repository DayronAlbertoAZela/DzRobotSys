package pe.edu.upeu.dzrobot.model;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import pe.edu.upeu.dzrobot.enums.TipoDocumento;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Cliente {
    @NotBlank(message = "El DNI/RUC es obligatorio")
    @Pattern(regexp = "\\d{8}|\\d{11}", message = "DNI de 8 dígitos o RUC de 11 dígitos")
    private String dniruc;
    @NotBlank(message = "El nombre o razón social es obligatorio")
    private String nombres;
    @NotBlank(message = "El representante legal es obligatorio (use - si es persona natural)")
    private String repLegal;
    @NotBlank(message = "La dirección es obligatoria")
    private String direccion;
    @NotNull(message = "El tipo de documento es obligatorio")
    private TipoDocumento tipoDocumento;
    @NotBlank(message = "El celular es obligatorio")
    @Pattern(regexp = "\\d{6,12}", message = "El celular debe tener de 6 a 12 dígitos")
    private String celular;

    @Override
    public String toString() {
        return nombres;
    }
}
