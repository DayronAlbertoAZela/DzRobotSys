package pe.edu.upeu.dzrobot.service.impl;

import lombok.RequiredArgsConstructor;
import pe.edu.upeu.dzrobot.enums.EstadoRobot;
import pe.edu.upeu.dzrobot.enums.TipoProducto;
import pe.edu.upeu.dzrobot.model.Repuesto;
import pe.edu.upeu.dzrobot.model.Robot;
import pe.edu.upeu.dzrobot.model.VentCarrito;
import pe.edu.upeu.dzrobot.repository.ICrudGenericoRepository;
import pe.edu.upeu.dzrobot.repository.VentCarritoRepository;
import pe.edu.upeu.dzrobot.service.IClienteService;
import pe.edu.upeu.dzrobot.service.IRepuestoService;
import pe.edu.upeu.dzrobot.service.IRobotService;
import pe.edu.upeu.dzrobot.service.IVentCarritoService;

import java.util.List;

@RequiredArgsConstructor
public class VentCarritoServiceImp extends CrudGenericoServiceImp<VentCarrito, Long> implements IVentCarritoService {
    private final VentCarritoRepository carritoRepository;
    private final IRobotService robotService;
    private final IRepuestoService repuestoService;
    private final IClienteService clienteService;

    @Override
    protected ICrudGenericoRepository<VentCarrito, Long> getRepo() {
        return carritoRepository;
    }

    @Override
    public VentCarrito agregar(String dniruc, TipoProducto tipo, Long idProducto, double cantidad, Long idUsuario) {
        if (dniruc == null || dniruc.isBlank() || !clienteService.existe(dniruc)) {
            throw new IllegalArgumentException("Elija o registre primero al cliente");
        }
        if (cantidad <= 0) {
            throw new IllegalArgumentException("La cantidad debe ser mayor a 0");
        }
        List<VentCarrito> actual = carritoRepository.listarPorCliente(dniruc);
        VentCarrito.VentCarritoBuilder item = VentCarrito.builder()
                .dniruc(dniruc).tipoProducto(tipo).cantidad(cantidad).estado(1).idUsuario(idUsuario);
        if (tipo == TipoProducto.ROBOT) {
            Robot r = robotService.findById(idProducto);
            if (r.getEstado() != EstadoRobot.EN_STOCK) {
                throw new IllegalArgumentException("El robot " + r.getCodigo() + " no está en stock");
            }
            if (cantidad != 1) {
                throw new IllegalArgumentException("Cada robot es único: la cantidad debe ser 1");
            }
            if (actual.stream().anyMatch(c -> idProducto.equals(c.getIdRobot()))) {
                throw new IllegalArgumentException("Ese robot ya está en el carrito");
            }
            item.idRobot(idProducto).nombreProducto(r.getCodigo() + " " + r.getNombre()).punitario(r.getPrecioVenta());
        } else {
            Repuesto p = repuestoService.findById(idProducto);
            double enCarrito = actual.stream().filter(c -> idProducto.equals(c.getIdRepuesto()))
                    .mapToDouble(VentCarrito::getCantidad).sum();
            if (cantidad % 1 != 0) {
                throw new IllegalArgumentException("La cantidad de repuestos debe ser un número entero");
            }
            if (cantidad + enCarrito > p.getStock()) {
                throw new IllegalArgumentException("Stock insuficiente: quedan " + (int) (p.getStock() - enCarrito)
                        + " de " + p.getNombre());
            }
            item.idRepuesto(idProducto).nombreProducto(p.getNombre()).punitario(p.getPrecioVenta());
        }
        VentCarrito c = item.build();
        c.setPtotal(Math.round(c.getPunitario() * c.getCantidad() * 100.0) / 100.0);
        return carritoRepository.save(c);
    }

    @Override
    public List<VentCarrito> listarPorCliente(String dniruc) {
        return carritoRepository.listarPorCliente(dniruc);
    }

    @Override
    public double total(String dniruc) {
        return Math.round(listarPorCliente(dniruc).stream().mapToDouble(VentCarrito::getPtotal).sum() * 100.0) / 100.0;
    }

    @Override
    public void vaciar(String dniruc) {
        carritoRepository.vaciar(dniruc);
    }
}
