package pe.edu.upeu.dzrobot.repository;

import pe.edu.upeu.dzrobot.model.Marca;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;

public class MarcaRepository extends AbstractJpaRepository<Marca, Long> {

    @Override
    protected String getTableName() {return "marca";}

    @Override
    protected String getPkColumn() {return "id_marca";}

    @Override
    protected Marca insert(Connection conn, Marca e) throws SQLException {
        long id = executeInsertGetKey(conn,
                "INSERT INTO marca(nombre,pais_origen) VALUES(?,?)", e.getNombre(), e.getPaisOrigen());
        e.setIdMarca(id);
        return e;
    }

    @Override
    protected Marca updateRow(Connection conn, Marca e) throws SQLException {
        executeUpdate(conn, "UPDATE marca SET nombre=?, pais_origen=? WHERE id_marca=?",
                e.getNombre(), e.getPaisOrigen(), e.getIdMarca());
        return e;
    }

    @Override
    protected Marca mapRow(ResultSet rs) throws SQLException {
        return Marca.builder()
                .idMarca(rs.getLong("id_marca"))
                .nombre(rs.getString("nombre"))
                .paisOrigen(rs.getString("pais_origen"))
                .build();
    }
}
