package pe.edu.upeu.dzrobot.modulos;

public record Opcion(Object id, String texto, double stock, String extra) {
    @Override
    public String toString() {
        return texto;
    }
}
