package pe.edu.upeu.dzrobot.service;

import pe.edu.upeu.dzrobot.dto.MenuMenuItenTO;

import java.util.List;

public interface IMenuMenuItemDao {
    List<MenuMenuItenTO> listaAccesos(String perfil);
}
