package pe.edu.upeu.dzrobot.repository;

import pe.edu.upeu.dzrobot.model.Cliente;
import pe.edu.upeu.dzrobot.model.Usuario;
import pe.edu.upeu.dzrobot.model.Venta;
import pe.edu.upeu.dzrobot.model.VentaDetalle;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class VentaRepository extends AbstractJpaRepository<Venta, Long> {
    @Override
    protected String getTableName() {return "venta";}

    @Override
    protected String getPkColumn() {return "id_venta";}

    @Override
    public List<Venta> findAll() {
        return executeQuery("SELECT * FROM venta ORDER BY fecha_gener DESC, id_venta DESC");
    }

    public String siguienteNumero(String serie) {
        try (Connection conn = openConnection()) {
            return siguienteNumero(conn, serie);
        } catch (SQLException e) {
            throw new RuntimeException("No se pudo obtener el número: " + e.getMessage(), e);
        }
    }

    private String siguienteNumero(Connection conn, String serie) throws SQLException {
        try (PreparedStatement ps = conn.prepareStatement("SELECT MAX(num_doc) FROM venta WHERE serie = ?")) {
            ps.setString(1, serie);
            try (ResultSet rs = ps.executeQuery()) {
                int ultimo = rs.next() && rs.getString(1) != null ? Integer.parseInt(rs.getString(1)) : 0;
                return String.format("%08d", ultimo + 1);
            }
        }
    }

    public Optional<Venta> findConDetalle(Long id) {
        Optional<Venta> venta = findById(id);
        venta.ifPresent(v -> v.setDetalleVenta(detalles(id)));
        return venta;
    }

    private List<VentaDetalle> detalles(Long idVenta) {
        String sql = "SELECT d.*, CONCAT(p.codigo, ' ', p.nombre) AS producto "
                + "FROM venta_detalle d JOIN producto p ON p.id_producto = d.id_producto "
                + "WHERE d.id_venta = ? ORDER BY d.id_venta_detalle";
        List<VentaDetalle> lista = new ArrayList<>();
        try (Connection conn = openConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setLong(1, idVenta);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    lista.add(VentaDetalle.builder()
                            .idVentaDetalle(rs.getLong("id_venta_detalle"))
                            .pu(rs.getDouble("pu"))
                            .cantidad(rs.getDouble("cantidad"))
                            .descuento(rs.getDouble("descuento"))
                            .descripcion(rs.getString("producto"))
                            .build());
                }
            }
        } catch (SQLException e) {
            throw new RuntimeException("No se pudo leer el detalle: " + e.getMessage(), e);
        }
        return lista;
    }

    @Override
    protected Venta insert(Connection conn, Venta v) throws SQLException {
        v.setNumDoc(siguienteNumero(conn, v.getSerie()));
        long id = executeInsertGetKey(conn,
                "INSERT INTO venta(precio_base,igv,precio_total,serie,num_doc,tipo_doc,fecha_gener,dniruc,id_usuario) "
                        + "VALUES(?,?,?,?,?,?,?,?,?)",
                v.getPrecioBase(), v.getIgv(), v.getPrecioTotal(), v.getSerie(), v.getNumDoc(), v.getTipoDoc(),
                Date.valueOf(v.getFechaGener()), v.getDniruc().getDniruc(), v.getIdUsuario().getIdUsuario());
        v.setId(id);
        for (VentaDetalle d : v.getDetalleVenta()) {
            Long idRobot = d.getIdRobot() == null ? null : d.getIdRobot().getIdRobot();
            Long idRepuesto = d.getIdRepuesto() == null ? null : d.getIdRepuesto().getIdRepuesto();
            executeUpdate(conn,
                    "INSERT INTO venta_detalle(pu,cantidad,descuento,subtotal,id_venta,id_producto) VALUES(?,?,?,?,?,?)",
                    d.getPu(), d.getCantidad(), d.getDescuento(), d.getSubtotal(), id, idRobot != null ? idRobot : idRepuesto);
            if (idRobot != null) {
                int filas = executeUpdate(conn,
                        "UPDATE producto SET estado = 'VENDIDO', stock = 0, dniruc = ? WHERE id_producto = ? AND estado = 'EN_STOCK'",
                        v.getDniruc().getDniruc(), idRobot);
                if (filas == 0) {
                    throw new IllegalStateException("El robot " + d.getDescripcion() + " ya no está en stock");
                }
            } else {
                int filas = executeUpdate(conn,
                        "UPDATE producto SET stock = stock - ? WHERE id_producto = ? AND stock >= ?",
                        d.getCantidad(), idRepuesto, d.getCantidad());
                if (filas == 0) {
                    throw new IllegalStateException("No hay stock suficiente de " + d.getDescripcion());
                }
            }
        }
        return v;
    }

    @Override
    protected Venta updateRow(Connection conn, Venta v) throws SQLException {
        throw new UnsupportedOperationException("Una venta registrada no se modifica");
    }

    @Override
    protected Venta mapRow(ResultSet rs) throws SQLException {
        Venta v = new Venta();
        v.setId(rs.getLong("id_venta"));
        v.setPrecioBase(rs.getDouble("precio_base"));
        v.setIgv(rs.getDouble("igv"));
        v.setPrecioTotal(rs.getDouble("precio_total"));
        v.setSerie(rs.getString("serie"));
        v.setNumDoc(rs.getString("num_doc"));
        v.setTipoDoc(rs.getString("tipo_doc"));
        v.setFechaGener(rs.getDate("fecha_gener").toLocalDate());
        v.setDniruc(Cliente.builder().dniruc(rs.getString("dniruc")).build());
        v.setIdUsuario(Usuario.builder().idUsuario(rs.getLong("id_usuario")).build());
        return v;
    }
}
