package pe.edu.upeu.dzrobot.operaciones;

import pe.edu.upeu.dzrobot.config.DatabaseConfig;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.List;

public class OperacionRepository {

    public long registrarMantenimiento(Object idRobot, Object idTecnico, String tipo, LocalDate fecha, String descripcion,
                                       double manoObra, String estado, Long idUsuario, boolean robotDeCliente,
                                       List<LineaMantenimiento> lineas) {
        double total = manoObra + lineas.stream().mapToDouble(LineaMantenimiento::costo).sum();
        try (Connection conn = DatabaseConfig.getConnection()) {
            conn.setAutoCommit(false);
            try {
                long id;
                try (PreparedStatement ps = conn.prepareStatement(
                        "INSERT INTO mantenimiento(tipo_mant, fecha_mant, descripcion, mano_obra, costo_total, estado, id_producto, id_tecnico, id_usuario) "
                                + "VALUES(?,?,?,?,?,?,?,?,?)", Statement.RETURN_GENERATED_KEYS)) {
                    ps.setString(1, tipo);
                    ps.setDate(2, Date.valueOf(fecha));
                    ps.setString(3, descripcion);
                    ps.setDouble(4, manoObra);
                    ps.setDouble(5, Math.round(total * 100.0) / 100.0);
                    ps.setString(6, estado);
                    ps.setObject(7, idRobot);
                    ps.setObject(8, idTecnico);
                    ps.setLong(9, idUsuario);
                    ps.executeUpdate();
                    try (ResultSet keys = ps.getGeneratedKeys()) {
                        keys.next();
                        id = keys.getLong(1);
                    }
                }
                for (LineaMantenimiento l : lineas) {
                    actualizar(conn, "INSERT INTO mantenimiento_detalle(accion, observacion, costo, id_mantenimiento, id_componente) "
                            + "VALUES(?,?,?,?,?)", l.accion(), l.observacion(), l.costo(), id, l.idComponente());
                    if ("REEMPLAZADO".equals(l.accion())) {
                        int filas = actualizar(conn, "UPDATE producto SET stock = stock - 1 WHERE id_producto = ? AND stock >= 1",
                                l.idRepuesto());
                        if (filas == 0) {
                            throw new IllegalStateException("No hay stock del repuesto para reemplazar " + l.componente());
                        }
                        actualizar(conn, "UPDATE componente SET horas_uso = 0, fecha_inst = ?, estado = 'ACTIVO' WHERE id_componente = ?",
                                Date.valueOf(fecha), l.idComponente());
                    }
                }
                actualizar(conn, "UPDATE falla SET id_mantenimiento = ?, estado = ? WHERE id_producto = ? AND estado <> 'RESUELTA'",
                        id, "FINALIZADO".equals(estado) ? "RESUELTA" : "EN_ATENCION", idRobot);
                if ("FINALIZADO".equals(estado)) {
                    actualizar(conn, "UPDATE producto SET fecha_ult_mant = ?, estado = ? WHERE id_producto = ?",
                            Date.valueOf(fecha), robotDeCliente ? "OPERATIVO" : "EN_STOCK", idRobot);
                } else {
                    actualizar(conn, "UPDATE producto SET estado = 'EN_REPARACION' WHERE id_producto = ?", idRobot);
                }
                conn.commit();
                return id;
            } catch (SQLException | RuntimeException e) {
                conn.rollback();
                throw e;
            }
        } catch (SQLException e) {
            throw new RuntimeException("No se pudo registrar el mantenimiento: " + e.getMessage(), e);
        }
    }

    public long reportarFalla(Object idRobot, String descripcion, String gravedad, LocalDate fecha) {
        try (Connection conn = DatabaseConfig.getConnection();
             PreparedStatement ps = conn.prepareStatement(
                     "INSERT INTO falla(descripcion, fecha_reporte, gravedad, estado, id_producto) VALUES(?,?,?,'ABIERTA',?)",
                     Statement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, descripcion);
            ps.setDate(2, Date.valueOf(fecha));
            ps.setString(3, gravedad);
            ps.setObject(4, idRobot);
            ps.executeUpdate();
            try (ResultSet keys = ps.getGeneratedKeys()) {
                keys.next();
                return keys.getLong(1);
            }
        } catch (SQLException e) {
            throw new RuntimeException("No se pudo reportar la falla: " + e.getMessage(), e);
        }
    }

    public void resolverFalla(Object idFalla) {
        try (Connection conn = DatabaseConfig.getConnection()) {
            actualizar(conn, "UPDATE falla SET estado = 'RESUELTA' WHERE id_falla = ?", idFalla);
        } catch (SQLException e) {
            throw new RuntimeException("No se pudo actualizar la falla: " + e.getMessage(), e);
        }
    }

    private int actualizar(Connection conn, String sql, Object... params) throws SQLException {
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            for (int i = 0; i < params.length; i++) {
                ps.setObject(i + 1, params[i]);
            }
            return ps.executeUpdate();
        }
    }
}
