package pe.edu.upeu.dzrobot.service.impl;

import lombok.RequiredArgsConstructor;
import pe.edu.upeu.dzrobot.dto.ComboBoxOption;
import pe.edu.upeu.dzrobot.enums.EstadoRobot;
import pe.edu.upeu.dzrobot.enums.TipoRobot;
import pe.edu.upeu.dzrobot.model.Robot;
import pe.edu.upeu.dzrobot.repository.ICrudGenericoRepository;
import pe.edu.upeu.dzrobot.repository.RobotRepository;
import pe.edu.upeu.dzrobot.service.IRobotService;

import java.util.Arrays;
import java.util.List;

@RequiredArgsConstructor
public class RobotServiceImp extends CrudGenericoServiceImp<Robot, Long> implements IRobotService {
    private final RobotRepository robotRepository;

    @Override
    protected ICrudGenericoRepository<Robot, Long> getRepo() {
        return robotRepository;
    }

    @Override
    public Robot save(Robot r) {
        validar(r);
        return super.save(r);
    }

    @Override
    public Robot update(Long id, Robot r) {
        validar(r);
        return super.update(id, r);
    }

    private void validar(Robot r) {
        if (r.getEstado() == EstadoRobot.VENDIDO && r.getDniruc() == null) {
            throw new IllegalArgumentException("Un robot VENDIDO debe tener un cliente como dueño");
        }
    }

    @Override
    public List<ComboBoxOption> listarTipoRobot() {
        return Arrays.stream(TipoRobot.values())
                .map(t -> new ComboBoxOption(t.name(), t.getDescripcion()))
                .toList();
    }

    @Override
    public List<ComboBoxOption> listarEstados() {
        return Arrays.stream(EstadoRobot.values())
                .map(e -> new ComboBoxOption(e.name(), e.name()))
                .toList();
    }

    @Override
    public List<Robot> listarQueNecesitanMantenimiento() {
        return robotRepository.findAll().stream()
                .filter(Robot::necesitaMantenimiento)
                .toList();
    }
}
