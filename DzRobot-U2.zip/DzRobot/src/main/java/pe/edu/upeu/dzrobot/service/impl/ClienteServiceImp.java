package pe.edu.upeu.dzrobot.service.impl;

import lombok.RequiredArgsConstructor;
import pe.edu.upeu.dzrobot.dto.ComboBoxOption;
import pe.edu.upeu.dzrobot.enums.TipoDocumento;
import pe.edu.upeu.dzrobot.model.Cliente;
import pe.edu.upeu.dzrobot.repository.ClienteRepository;
import pe.edu.upeu.dzrobot.repository.ICrudGenericoRepository;
import pe.edu.upeu.dzrobot.service.IClienteService;

import java.util.List;

@RequiredArgsConstructor
public class ClienteServiceImp extends CrudGenericoServiceImp<Cliente, String> implements IClienteService {
    private final ClienteRepository clienteRepository;

    @Override
    protected ICrudGenericoRepository<Cliente, String> getRepo() {
        return clienteRepository;
    }

    @Override
    public Cliente save(Cliente c) {
        validarDocumento(c);
        if (clienteRepository.existsById(c.getDniruc())) {
            throw new IllegalArgumentException("Ya existe un cliente con el documento " + c.getDniruc());
        }
        return super.save(c);
    }

    @Override
    public Cliente update(String id, Cliente c) {
        validarDocumento(c);
        return super.update(id, c);
    }

    private void validarDocumento(Cliente c) {
        boolean esRuc = c.getDniruc().length() == 11;
        if (esRuc != (c.getTipoDocumento() == TipoDocumento.RUC)) {
            throw new IllegalArgumentException("Un DNI tiene 8 dígitos y un RUC 11: revise el tipo de documento");
        }
    }

    @Override
    public boolean existe(String dniruc) {
        return clienteRepository.existsById(dniruc);
    }

    @Override
    public List<ComboBoxOption> listarCombobox() {
        return clienteRepository.findAll().stream()
                .map(c -> new ComboBoxOption(c.getDniruc(), c.getNombres() + " (" + c.getDniruc() + ")"))
                .toList();
    }
}
