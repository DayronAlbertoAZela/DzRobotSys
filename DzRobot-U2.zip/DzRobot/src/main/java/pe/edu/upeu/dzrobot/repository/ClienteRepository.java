package pe.edu.upeu.dzrobot.repository;

import pe.edu.upeu.dzrobot.enums.TipoDocumento;
import pe.edu.upeu.dzrobot.model.Cliente;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

public class ClienteRepository extends AbstractJpaRepository<Cliente, String> {
    @Override
    protected String getTableName() {return "cliente";}

    @Override
    protected String getPkColumn() {return "dniruc";}

    @Override
    public List<Cliente> findAll() {
        return executeQuery("SELECT * FROM cliente ORDER BY nombres");
    }

    @Override
    protected Cliente insert(Connection conn, Cliente e) throws SQLException {
        executeUpdate(conn,
                "INSERT INTO cliente(dniruc,nombres,rep_legal,direccion,tipo_documento,celular) VALUES(?,?,?,?,?,?)",
                e.getDniruc(), e.getNombres(), e.getRepLegal(), e.getDireccion(),
                e.getTipoDocumento().name(), e.getCelular());
        return e;
    }

    @Override
    protected Cliente updateRow(Connection conn, Cliente e) throws SQLException {
        executeUpdate(conn,
                "UPDATE cliente SET nombres=?,rep_legal=?,direccion=?,tipo_documento=?,celular=? WHERE dniruc=?",
                e.getNombres(), e.getRepLegal(), e.getDireccion(),
                e.getTipoDocumento().name(), e.getCelular(), e.getDniruc());
        return e;
    }

    @Override
    protected Cliente mapRow(ResultSet rs) throws SQLException {
        return Cliente.builder()
                .dniruc(rs.getString("dniruc"))
                .nombres(rs.getString("nombres"))
                .repLegal(rs.getString("rep_legal"))
                .direccion(rs.getString("direccion"))
                .tipoDocumento(TipoDocumento.valueOf(rs.getString("tipo_documento")))
                .celular(rs.getString("celular"))
                .build();
    }
}
