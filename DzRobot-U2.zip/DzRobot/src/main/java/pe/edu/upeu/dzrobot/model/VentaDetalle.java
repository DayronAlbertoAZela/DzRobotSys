package pe.edu.upeu.dzrobot.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class VentaDetalle {
    private Long idVentaDetalle;
    private double pu;
    private double cantidad;
    private double descuento;
    private Robot idRobot;
    private Repuesto idRepuesto;
    private String descripcion;

    public double getSubtotal() {
        return pu * cantidad - descuento;
    }
}
