package pe.edu.upeu.dzrobot.model;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

@Data
@EqualsAndHashCode(callSuper = true)
@NoArgsConstructor
public class Importacion extends DocumentoComercial {
    private double flete;
    private double aranceles;
    private LocalDate fechaImp;
    private Long idProveedor;
    private Usuario idUsuario;
    private List<ImportacionDetalle> detalle = new ArrayList<>();

    @Override
    public double calcularTotal() {
        setPrecioBase(redondear(detalle.stream().mapToDouble(ImportacionDetalle::getSubtotal).sum()));
        setIgv(redondear((getPrecioBase() + flete + aranceles) * TASA_IGV));
        setPrecioTotal(redondear(getPrecioBase() + flete + aranceles + getIgv()));
        return getPrecioTotal();
    }
}
