package pe.edu.upeu.dzrobot.operaciones;

public record LineaMantenimiento(Object idComponente, Object idRepuesto, String componente,
                                 String accion, String observacion, double costo) {

    public String getComponente() {
        return componente;
    }

    public String getAccion() {
        return accion;
    }

    public String getObservacion() {
        return observacion;
    }

    public double getCosto() {
        return costo;
    }
}
