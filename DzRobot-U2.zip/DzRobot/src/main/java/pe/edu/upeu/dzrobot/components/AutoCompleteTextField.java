package pe.edu.upeu.dzrobot.components;

import javafx.geometry.Side;
import javafx.scene.control.ContextMenu;
import javafx.scene.control.MenuItem;
import javafx.scene.control.TextField;

import java.text.Normalizer;
import java.util.Collection;
import java.util.List;
import java.util.function.Consumer;

public class AutoCompleteTextField<T> {
    private static final int MAXIMO = 12;

    private final TextField campo;
    private final Collection<T> entradas;
    private final ContextMenu menu = new ContextMenu();
    private T seleccionado;
    private Consumer<T> alElegir = t -> { };

    public AutoCompleteTextField(Collection<T> entradas, TextField campo) {
        this.entradas = entradas;
        this.campo = campo;
        campo.textProperty().addListener((o, a, b) -> {
            if (seleccionado != null && !seleccionado.toString().equals(b)) {
                seleccionado = null;
            }
            if (campo.isFocused()) {
                mostrarSugerencias();
            }
        });
        campo.focusedProperty().addListener((o, a, foco) -> {
            if (!foco) {
                menu.hide();
            }
        });
    }

    public void setAlElegir(Consumer<T> alElegir) {
        this.alElegir = alElegir;
    }

    private void mostrarSugerencias() {
        String texto = normalizar(campo.getText());
        if (texto.isBlank()) {
            menu.hide();
            return;
        }
        List<MenuItem> items = entradas.stream()
                .filter(e -> normalizar(e.toString()).contains(texto))
                .limit(MAXIMO)
                .map(e -> {
                    MenuItem item = new MenuItem(e.toString());
                    item.setOnAction(ev -> elegir(e));
                    return item;
                })
                .toList();
        menu.getItems().setAll(items);
        if (items.isEmpty()) {
            menu.hide();
        } else if (!menu.isShowing()) {
            menu.show(campo, Side.BOTTOM, 0, 0);
        }
    }

    private void elegir(T e) {
        seleccionado = e;
        campo.setText(e.toString());
        campo.positionCaret(campo.getText().length());
        menu.hide();
        alElegir.accept(e);
    }

    public T getLastSelectedObject() {
        return seleccionado;
    }

    public void limpiar() {
        seleccionado = null;
        campo.clear();
        menu.hide();
    }

    private static String normalizar(String texto) {
        if (texto == null) {
            return "";
        }
        return Normalizer.normalize(texto, Normalizer.Form.NFD).replaceAll("\\p{M}", "").toLowerCase();
    }
}
