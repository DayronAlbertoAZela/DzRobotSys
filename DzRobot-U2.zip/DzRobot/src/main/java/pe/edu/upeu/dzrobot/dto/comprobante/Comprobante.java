package pe.edu.upeu.dzrobot.dto.comprobante;

import lombok.Data;

import java.math.BigDecimal;
import java.util.List;

@Data
public class Comprobante {
    private String rucEmisor;
    private String razonSocial;
    private String direccion;
    private String ubigeo;

    private String tipoDocumento;
    private String serie;
    private String numero;
    private String fechaEmision;
    private String moneda = "PEN";
    private String vendedor;

    private String tipoDocCliente;
    private String nroDocCliente;
    private String nombreCliente;
    private String direccionCliente;

    private List<ItemComprobante> items;

    private BigDecimal opGravadas;
    private BigDecimal igv;
    private BigDecimal total;
}
