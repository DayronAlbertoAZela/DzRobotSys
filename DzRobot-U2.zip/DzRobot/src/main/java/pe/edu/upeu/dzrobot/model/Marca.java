package pe.edu.upeu.dzrobot.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Marca {
    private Long idMarca;
    private String nombre;
    private String paisOrigen;
}
