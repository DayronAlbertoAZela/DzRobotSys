package pe.edu.upeu.dzrobot.repository;

import pe.edu.upeu.dzrobot.model.Emisor;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Optional;

public class EmisorRepository extends AbstractJpaRepository<Emisor, Long> {
    @Override
    protected String getTableName() {return "emisor";}

    @Override
    protected String getPkColumn() {return "id_emisor";}

    public Optional<Emisor> principal() {
        return executeQuery("SELECT * FROM emisor ORDER BY id_emisor").stream().findFirst();
    }

    @Override
    protected Emisor insert(Connection conn, Emisor e) throws SQLException {
        long id = executeInsertGetKey(conn,
                "INSERT INTO emisor(ruc,nombre_comercial,ubigeo,domicilio_fiscal,urbanizacion,departamento,provincia,distrito) "
                        + "VALUES(?,?,?,?,?,?,?,?)",
                e.getRuc(), e.getNombreComercial(), e.getUbigeo(), e.getDomicilioFiscal(), e.getUrbanizacion(),
                e.getDepartamento(), e.getProvincia(), e.getDistrito());
        e.setIdEmisor(id);
        return e;
    }

    @Override
    protected Emisor updateRow(Connection conn, Emisor e) throws SQLException {
        executeUpdate(conn,
                "UPDATE emisor SET ruc=?,nombre_comercial=?,ubigeo=?,domicilio_fiscal=?,urbanizacion=?,departamento=?,"
                        + "provincia=?,distrito=? WHERE id_emisor=?",
                e.getRuc(), e.getNombreComercial(), e.getUbigeo(), e.getDomicilioFiscal(), e.getUrbanizacion(),
                e.getDepartamento(), e.getProvincia(), e.getDistrito(), e.getIdEmisor());
        return e;
    }

    @Override
    protected Emisor mapRow(ResultSet rs) throws SQLException {
        return Emisor.builder()
                .idEmisor(rs.getLong("id_emisor"))
                .ruc(rs.getString("ruc"))
                .nombreComercial(rs.getString("nombre_comercial"))
                .ubigeo(rs.getString("ubigeo"))
                .domicilioFiscal(rs.getString("domicilio_fiscal"))
                .urbanizacion(rs.getString("urbanizacion"))
                .departamento(rs.getString("departamento"))
                .provincia(rs.getString("provincia"))
                .distrito(rs.getString("distrito"))
                .build();
    }
}
