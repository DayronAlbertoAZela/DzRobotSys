package pe.edu.upeu.dzrobot.service.impl;

import lombok.RequiredArgsConstructor;
import pe.edu.upeu.dzrobot.dto.ComboBoxOption;
import pe.edu.upeu.dzrobot.model.Marca;
import pe.edu.upeu.dzrobot.repository.ICrudGenericoRepository;
import pe.edu.upeu.dzrobot.repository.MarcaRepository;
import pe.edu.upeu.dzrobot.service.IMarcaService;

import java.util.List;

@RequiredArgsConstructor
public class MarcaServiceImp extends CrudGenericoServiceImp<Marca, Long> implements IMarcaService {

    private final MarcaRepository marcaRepository;

    @Override
    protected ICrudGenericoRepository<Marca, Long> getRepo() {
        return marcaRepository;
    }

    @Override
    public List<ComboBoxOption> listarCombobox() {
        return marcaRepository.findAll().stream()
                .map(m -> new ComboBoxOption(String.valueOf(m.getIdMarca()), m.getNombre()))
                .toList();
    }
}
