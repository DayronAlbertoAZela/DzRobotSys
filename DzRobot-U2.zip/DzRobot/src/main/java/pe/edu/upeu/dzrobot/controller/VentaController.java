package pe.edu.upeu.dzrobot.controller;

import javafx.application.Platform;
import javafx.concurrent.Task;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.TableCell;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.util.converter.LocalDateStringConverter;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.stage.Window;
import lombok.RequiredArgsConstructor;
import pe.edu.upeu.dzrobot.componentes.Tema;
import pe.edu.upeu.dzrobot.components.AutoCompleteTextField;
import pe.edu.upeu.dzrobot.components.ColumnInfo;
import pe.edu.upeu.dzrobot.components.TableViewHelper;
import pe.edu.upeu.dzrobot.components.Toast;
import pe.edu.upeu.dzrobot.dto.ModeloDataAutocomplet;
import pe.edu.upeu.dzrobot.dto.PersonaDto;
import pe.edu.upeu.dzrobot.dto.SessionManager;
import pe.edu.upeu.dzrobot.dto.comprobante.Comprobante;
import pe.edu.upeu.dzrobot.enums.TipoDocumento;
import pe.edu.upeu.dzrobot.enums.TipoProducto;
import pe.edu.upeu.dzrobot.model.Cliente;
import pe.edu.upeu.dzrobot.model.VentCarrito;
import pe.edu.upeu.dzrobot.model.Venta;
import pe.edu.upeu.dzrobot.service.IClienteService;
import pe.edu.upeu.dzrobot.service.IVentCarritoService;
import pe.edu.upeu.dzrobot.service.IVentaService;
import pe.edu.upeu.dzrobot.utils.ConsultaDNI;

import java.io.IOException;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Optional;

@RequiredArgsConstructor
public class VentaController {
    private static final DecimalFormat SOLES = new DecimalFormat("S/ #,##0.00", DecimalFormatSymbols.getInstance(Locale.US));

    private final IVentaService ventaService;
    private final IVentCarritoService carritoService;
    private final IClienteService clienteService;
    private final ConsultaDNI consultaDNI;

    @FXML AnchorPane miContenedor;
    @FXML TextField autocompCliente, dniRuc, razonSocial, txtDireccion, txtCelular;
    @FXML TextField autocompProducto, nombreProducto, codigoPro, stockPro, cantidadPro, punitPro, preTPro;
    @FXML Button btnBuscarCliente, btnRegCliente, btnRegCarrito, btnRegVenta;
    @FXML ComboBox<String> cbxTipoDoc;
    @FXML TextField txtNumero;
    @FXML DatePicker dpFecha;
    @FXML TableView<VentCarrito> tableView;
    @FXML Label lblBase, lblIgv, lblTotal, lblClienteEstado;

    private final List<ModeloDataAutocomplet> clientes = new ArrayList<>();
    private final List<ModeloDataAutocomplet> productos = new ArrayList<>();
    private AutoCompleteTextField<ModeloDataAutocomplet> actfCliente;
    private AutoCompleteTextField<ModeloDataAutocomplet> actfProducto;
    private ModeloDataAutocomplet productoElegido;

    @FXML
    public void initialize() {
        cbxTipoDoc.getItems().setAll("BOLETA", "FACTURA");
        cbxTipoDoc.setValue("BOLETA");
        cbxTipoDoc.valueProperty().addListener((o, a, b) -> actualizarNumero());
        DateTimeFormatter dmy = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        dpFecha.setConverter(new LocalDateStringConverter(dmy, dmy));
        dpFecha.setValue(LocalDate.now());

        actfCliente = new AutoCompleteTextField<>(clientes, autocompCliente);
        actfCliente.setAlElegir(c -> elegirCliente(c.getIdx()));
        actfProducto = new AutoCompleteTextField<>(productos, autocompProducto);
        actfProducto.setAlElegir(this::elegirProducto);

        cantidadPro.textProperty().addListener((o, a, b) -> calcularPT());

        LinkedHashMap<String, ColumnInfo> columnas = new LinkedHashMap<>();
        columnas.put("Tipo", new ColumnInfo("tipoProducto", 100.0));
        columnas.put("Producto", new ColumnInfo("nombreProducto", 320.0));
        columnas.put("Cantidad", new ColumnInfo("cantidad", 90.0));
        columnas.put("P. Unitario", new ColumnInfo("punitario", 120.0));
        columnas.put("P. Total", new ColumnInfo("ptotal", 120.0));
        new TableViewHelper<VentCarrito>().addColumnsInOrderWithSize(tableView, columnas, null, this::quitar);
        formatearColumna(2, "%.0f");
        formatearColumna(3, "%,.2f");
        formatearColumna(4, "%,.2f");
        TableViewHelper.pildoras(tableView, "Tipo", v -> "ROBOT".equals(v) ? "naranja" : "celeste");
        tableView.setPlaceholder(new Label("Busque un cliente y agregue robots o repuestos"));

        btnRegCliente.setDisable(true);
        btnRegCarrito.setDisable(true);
        cargarClientes();
        cargarProductos();
        actualizarNumero();
        listar();
    }

    private void cargarClientes() {
        clientes.clear();
        for (Cliente c : clienteService.findAll()) {
            clientes.add(new ModeloDataAutocomplet(c.getDniruc(), c.getNombres(), c.getTipoDocumento().name()));
        }
    }

    private void cargarProductos() {
        productos.clear();
        productos.addAll(ventaService.listAutoCompletProducto());
    }

    private void actualizarNumero() {
        String tipo = cbxTipoDoc.getValue();
        txtNumero.setText(("FACTURA".equals(tipo) ? "F001" : "B001") + "-" + ventaService.siguienteNumero(tipo));
    }

    private void elegirCliente(String documento) {
        Cliente c = clienteService.findById(documento);
        dniRuc.setText(c.getDniruc());
        razonSocial.setText(c.getNombres());
        txtDireccion.setText(c.getDireccion());
        txtCelular.setText(c.getCelular());
        cbxTipoDoc.setValue(c.getTipoDocumento() == TipoDocumento.RUC ? "FACTURA" : "BOLETA");
        btnRegCliente.setDisable(true);
        lblClienteEstado.setText("Cliente registrado");
        listar();
    }

    @FXML
    public void buscarCliente() {
        String texto = autocompCliente.getText() == null ? "" : autocompCliente.getText().trim();
        String documento = texto.contains(" - ") ? texto.substring(0, texto.indexOf(" - ")) : texto;
        if (!documento.matches("\\d{8}|\\d{11}")) {
            Toast.mostrar(autocompCliente, "Escriba un DNI de 8 dígitos o un RUC de 11", Toast.Tipo.ERROR);
            return;
        }
        if (clienteService.existe(documento)) {
            elegirCliente(documento);
            Toast.mostrar(autocompCliente, "El cliente ya está registrado", Toast.Tipo.INFO);
            return;
        }
        limpiarCliente();
        dniRuc.setText(documento);
        btnRegCliente.setDisable(false);
        if (documento.length() == 11) {
            lblClienteEstado.setText("RUC nuevo: complete los datos y regístrelo");
            razonSocial.requestFocus();
            return;
        }
        lblClienteEstado.setText("Consultando RENIEC...");
        btnBuscarCliente.setDisable(true);
        Task<Optional<PersonaDto>> consulta = new Task<>() {
            @Override
            protected Optional<PersonaDto> call() {
                return consultaDNI.consultarDNI(documento);
            }
        };
        consulta.setOnSucceeded(e -> {
            btnBuscarCliente.setDisable(false);
            Optional<PersonaDto> persona = consulta.getValue();
            if (persona.isPresent()) {
                razonSocial.setText(persona.get().getNombreCompleto());
                lblClienteEstado.setText("Encontrado en RENIEC: complete dirección y celular");
                txtDireccion.requestFocus();
            } else {
                lblClienteEstado.setText("DNI nuevo: escriba los datos del cliente");
                razonSocial.requestFocus();
            }
        });
        consulta.setOnFailed(e -> {
            btnBuscarCliente.setDisable(false);
            lblClienteEstado.setText("Sin conexión a RENIEC: escriba los datos del cliente");
        });
        Thread hilo = new Thread(consulta);
        hilo.setDaemon(true);
        hilo.start();
    }

    @FXML
    public void guardarCliente() {
        String doc = dniRuc.getText();
        Cliente c = Cliente.builder()
                .dniruc(doc)
                .nombres(razonSocial.getText().trim())
                .repLegal(doc.length() == 11 ? razonSocial.getText().trim() : "-")
                .direccion(txtDireccion.getText().trim())
                .celular(txtCelular.getText().trim())
                .tipoDocumento(doc.length() == 11 ? TipoDocumento.RUC : TipoDocumento.DNI)
                .build();
        if (c.getNombres().length() < 3 || c.getDireccion().length() < 3 || !c.getCelular().matches("\\d{6,12}")) {
            Toast.mostrar(autocompCliente, "Complete nombre, dirección y un celular de 6 a 12 dígitos", Toast.Tipo.ERROR);
            return;
        }
        try {
            clienteService.save(c);
            cargarClientes();
            elegirCliente(doc);
            Toast.mostrar(autocompCliente, "Cliente " + c.getNombres() + " registrado", Toast.Tipo.OK);
        } catch (RuntimeException e) {
            Toast.mostrar(autocompCliente, e.getMessage(), Toast.Tipo.ERROR);
        }
    }

    private void limpiarCliente() {
        dniRuc.clear();
        razonSocial.clear();
        txtDireccion.clear();
        txtCelular.clear();
        lblClienteEstado.setText("");
    }

    private void elegirProducto(ModeloDataAutocomplet p) {
        productoElegido = p;
        String[] dato = p.getOtherData().split(":");
        nombreProducto.setText(p.getNameDysplay());
        codigoPro.setText(p.getIdx());
        punitPro.setText(dato[0]);
        stockPro.setText(dato[1]);
        cantidadPro.setText("1");
        cantidadPro.setDisable(TipoProducto.ROBOT.name().equals(dato[2]));
        calcularPT();
        if (!cantidadPro.isDisabled()) {
            cantidadPro.requestFocus();
            cantidadPro.selectAll();
        }
    }

    private void calcularPT() {
        try {
            double cantidad = Double.parseDouble(cantidadPro.getText());
            double total = Double.parseDouble(punitPro.getText()) * cantidad;
            preTPro.setText(String.format(Locale.US, "%.2f", total));
            btnRegCarrito.setDisable(productoElegido == null || cantidad <= 0);
        } catch (NumberFormatException | NullPointerException e) {
            preTPro.clear();
            btnRegCarrito.setDisable(true);
        }
    }

    @FXML
    public void registrarPCarrito() {
        if (dniRuc.getText().isBlank() || !clienteService.existe(dniRuc.getText())) {
            Toast.mostrar(tableView, "Elija o registre primero al cliente", Toast.Tipo.ERROR);
            return;
        }
        try {
            String[] dato = productoElegido.getOtherData().split(":");
            TipoProducto tipo = TipoProducto.valueOf(dato[2]);
            Long id = Long.parseLong(productoElegido.getIdx().substring(1));
            carritoService.agregar(dniRuc.getText(), tipo, id, Double.parseDouble(cantidadPro.getText()),
                    SessionManager.getInstance().getUserId());
            Toast.mostrar(tableView, nombreProducto.getText() + " agregado al carrito", Toast.Tipo.OK);
            limpiarProducto();
            listar();
        } catch (RuntimeException e) {
            Toast.mostrar(tableView, e.getMessage(), Toast.Tipo.ERROR);
        }
    }

    private void limpiarProducto() {
        productoElegido = null;
        actfProducto.limpiar();
        nombreProducto.clear();
        codigoPro.clear();
        stockPro.clear();
        cantidadPro.clear();
        punitPro.clear();
        preTPro.clear();
        btnRegCarrito.setDisable(true);
    }

    private void quitar(VentCarrito item) {
        carritoService.delete(item.getIdCarrito());
        Toast.mostrar(tableView, item.getNombreProducto() + " quitado del carrito", Toast.Tipo.INFO);
        listar();
    }

    public void listar() {
        String doc = dniRuc.getText();
        List<VentCarrito> items = doc == null || doc.isBlank() ? List.of() : carritoService.listarPorCliente(doc);
        tableView.getItems().setAll(items);
        double total = items.stream().mapToDouble(VentCarrito::getPtotal).sum();
        double base = Math.round(total / 1.18 * 100.0) / 100.0;
        lblBase.setText(SOLES.format(base));
        lblIgv.setText(SOLES.format(total - base));
        lblTotal.setText(SOLES.format(total));
        btnRegVenta.setDisable(items.isEmpty());
    }

    @FXML
    public void cancelarVenta() {
        if (!dniRuc.getText().isBlank()) {
            carritoService.vaciar(dniRuc.getText());
        }
        actfCliente.limpiar();
        limpiarCliente();
        limpiarProducto();
        listar();
    }

    @FXML
    public void registrarVenta() {
        try {
            Venta venta = ventaService.registrarVenta(dniRuc.getText(), cbxTipoDoc.getValue(), dpFecha.getValue(),
                    SessionManager.getInstance().getUserId());
            Toast.mostrar(tableView, "Venta " + venta.getSerie() + "-" + venta.getNumDoc() + " registrada", Toast.Tipo.OK);
            Comprobante comprobante = ventaService.generarComprobante(venta.getId());
            cargarProductos();
            actualizarNumero();
            listar();
            mostrarComprobante(comprobante);
        } catch (RuntimeException e) {
            Toast.mostrar(tableView, e.getMessage(), Toast.Tipo.ERROR);
        }
    }

    public static void mostrarComprobante(Comprobante comprobante) {
        try {
            FXMLLoader loader = new FXMLLoader(VentaController.class.getResource("/view/main_comprobante.fxml"));
            loader.setController(new MainComprobanteController(comprobante));
            Parent raiz = loader.load();
            Stage stage = new Stage();
            stage.initModality(Modality.APPLICATION_MODAL);
            Window.getWindows().stream().filter(w -> w instanceof Stage && w.isShowing()).findFirst()
                    .ifPresent(stage::initOwner);
            stage.setTitle("Comprobante " + comprobante.getSerie() + "-" + comprobante.getNumero());
            Scene scene = new Scene(raiz, 820, 640);
            Tema.aplicar(scene);
            stage.setScene(scene);
            Platform.runLater(stage::show);
        } catch (IOException e) {
            throw new RuntimeException("No se pudo abrir el comprobante: " + e.getMessage(), e);
        }
    }

    @SuppressWarnings("unchecked")
    private void formatearColumna(int indice, String formato) {
        TableColumn<VentCarrito, Object> col = (TableColumn<VentCarrito, Object>) tableView.getColumns().get(indice);
        col.setCellFactory(c -> new TableCell<>() {
            @Override
            protected void updateItem(Object valor, boolean vacio) {
                super.updateItem(valor, vacio);
                setText(vacio || valor == null ? null : String.format(formato, ((Number) valor).doubleValue()));
            }
        });
    }
}
