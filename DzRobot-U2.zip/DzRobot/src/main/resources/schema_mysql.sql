CREATE TABLE IF NOT EXISTS perfil (
    id_perfil INT NOT NULL,
    nombre VARCHAR(30) NOT NULL UNIQUE,
    CONSTRAINT pk_perfil PRIMARY KEY (id_perfil)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS usuario (
    id_usuario INT NOT NULL AUTO_INCREMENT,
    usuario VARCHAR(20) NOT NULL UNIQUE,
    clave VARCHAR(120) NOT NULL,
    estado VARCHAR(10) NOT NULL,
    id_perfil INT NOT NULL,
    CONSTRAINT pk_usuario PRIMARY KEY (id_usuario),
    CONSTRAINT fk_usuario_id_perfil FOREIGN KEY (id_perfil) REFERENCES perfil (id_perfil)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS emisor (
    id_emisor INT NOT NULL AUTO_INCREMENT,
    ruc VARCHAR(20) NOT NULL,
    nombre_comercial VARCHAR(60) NOT NULL,
    ubigeo VARCHAR(10) NOT NULL,
    domicilio_fiscal VARCHAR(60) NOT NULL,
    urbanizacion VARCHAR(40) NOT NULL,
    departamento VARCHAR(30) NOT NULL,
    provincia VARCHAR(30) NOT NULL,
    distrito VARCHAR(30) NOT NULL,
    CONSTRAINT pk_emisor PRIMARY KEY (id_emisor)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS cliente (
    dniruc VARCHAR(12) NOT NULL,
    nombres VARCHAR(60) NOT NULL,
    rep_legal VARCHAR(60) NOT NULL,
    direccion VARCHAR(80) NOT NULL,
    tipo_documento VARCHAR(12) NOT NULL,
    celular VARCHAR(12) NOT NULL,
    CONSTRAINT pk_cliente PRIMARY KEY (dniruc)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS proveedor (
    id_proveedor INT NOT NULL AUTO_INCREMENT,
    num_doc VARCHAR(20) NOT NULL,
    nombre_razon VARCHAR(60) NOT NULL,
    pais VARCHAR(30) NOT NULL,
    celular VARCHAR(20) NOT NULL,
    email VARCHAR(40) NOT NULL,
    direccion VARCHAR(80) NOT NULL,
    CONSTRAINT pk_proveedor PRIMARY KEY (id_proveedor)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS tecnico (
    id_tecnico INT NOT NULL AUTO_INCREMENT,
    dni VARCHAR(12) NOT NULL UNIQUE,
    nombres VARCHAR(60) NOT NULL,
    especialidad VARCHAR(40) NOT NULL,
    celular VARCHAR(12) NOT NULL,
    CONSTRAINT pk_tecnico PRIMARY KEY (id_tecnico)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS marca (
    id_marca INT NOT NULL AUTO_INCREMENT,
    nombre VARCHAR(30) NOT NULL,
    pais_origen VARCHAR(30) NOT NULL,
    CONSTRAINT pk_marca PRIMARY KEY (id_marca)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS producto (
    id_producto INT NOT NULL AUTO_INCREMENT,
    codigo VARCHAR(20) NOT NULL UNIQUE,
    nombre VARCHAR(40) NOT NULL,
    modelo VARCHAR(30) NOT NULL,
    tipo VARCHAR(20) NOT NULL,
    fecha_adq DATE NOT NULL,
    fecha_ult_mant DATE NOT NULL,
    estado VARCHAR(20) NOT NULL,
    pu DOUBLE PRECISION NOT NULL,
    utilidad DOUBLE PRECISION NOT NULL,
    id_marca INT NOT NULL,
    dniruc VARCHAR(12),
    vida_util DOUBLE PRECISION NOT NULL,
    stock DOUBLE PRECISION NOT NULL,
    CONSTRAINT pk_producto PRIMARY KEY (id_producto),
    CONSTRAINT fk_producto_id_marca FOREIGN KEY (id_marca) REFERENCES marca (id_marca),
    CONSTRAINT fk_producto_dniruc FOREIGN KEY (dniruc) REFERENCES cliente (dniruc)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS robot_industrial (
    id_producto INT NOT NULL,
    capacidad_carga DOUBLE PRECISION NOT NULL,
    num_ejes INT NOT NULL,
    CONSTRAINT pk_robot_industrial PRIMARY KEY (id_producto),
    CONSTRAINT fk_robot_industrial_id_producto FOREIGN KEY (id_producto) REFERENCES producto (id_producto)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS robot_movil (
    id_producto INT NOT NULL,
    locomocion VARCHAR(20) NOT NULL,
    autonomia DOUBLE PRECISION NOT NULL,
    CONSTRAINT pk_robot_movil PRIMARY KEY (id_producto),
    CONSTRAINT fk_robot_movil_id_producto FOREIGN KEY (id_producto) REFERENCES producto (id_producto)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS robot_educativo (
    id_producto INT NOT NULL,
    plataforma VARCHAR(20) NOT NULL,
    nivel VARCHAR(20) NOT NULL,
    CONSTRAINT pk_robot_educativo PRIMARY KEY (id_producto),
    CONSTRAINT fk_robot_educativo_id_producto FOREIGN KEY (id_producto) REFERENCES producto (id_producto)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS componente (
    id_componente INT NOT NULL AUTO_INCREMENT,
    num_serie VARCHAR(30) NOT NULL UNIQUE,
    horas_uso DOUBLE PRECISION NOT NULL,
    fecha_inst DATE NOT NULL,
    estado VARCHAR(20) NOT NULL,
    id_producto INT NOT NULL,
    id_repuesto INT NOT NULL,
    CONSTRAINT pk_componente PRIMARY KEY (id_componente),
    CONSTRAINT fk_componente_id_producto FOREIGN KEY (id_producto) REFERENCES producto (id_producto),
    CONSTRAINT fk_componente_id_repuesto FOREIGN KEY (id_repuesto) REFERENCES producto (id_producto)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS mantenimiento (
    id_mantenimiento INT NOT NULL AUTO_INCREMENT,
    tipo_mant VARCHAR(20) NOT NULL,
    fecha_mant DATE NOT NULL,
    descripcion VARCHAR(100) NOT NULL,
    mano_obra DOUBLE PRECISION NOT NULL,
    costo_total DOUBLE PRECISION NOT NULL,
    estado VARCHAR(20) NOT NULL,
    id_producto INT NOT NULL,
    id_tecnico INT NOT NULL,
    id_usuario INT NOT NULL,
    CONSTRAINT pk_mantenimiento PRIMARY KEY (id_mantenimiento),
    CONSTRAINT fk_mantenimiento_id_producto FOREIGN KEY (id_producto) REFERENCES producto (id_producto),
    CONSTRAINT fk_mantenimiento_id_tecnico FOREIGN KEY (id_tecnico) REFERENCES tecnico (id_tecnico),
    CONSTRAINT fk_mantenimiento_id_usuario FOREIGN KEY (id_usuario) REFERENCES usuario (id_usuario)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS mantenimiento_detalle (
    id_mant_detalle INT NOT NULL AUTO_INCREMENT,
    accion VARCHAR(20) NOT NULL,
    observacion VARCHAR(100) NOT NULL,
    costo DOUBLE PRECISION NOT NULL,
    id_mantenimiento INT NOT NULL,
    id_componente INT NOT NULL,
    CONSTRAINT pk_mantenimiento_detalle PRIMARY KEY (id_mant_detalle),
    CONSTRAINT fk_mantenimiento_detalle_id_mantenimiento FOREIGN KEY (id_mantenimiento) REFERENCES mantenimiento (id_mantenimiento),
    CONSTRAINT fk_mantenimiento_detalle_id_componente FOREIGN KEY (id_componente) REFERENCES componente (id_componente)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS falla (
    id_falla INT NOT NULL AUTO_INCREMENT,
    descripcion VARCHAR(100) NOT NULL,
    fecha_reporte DATE NOT NULL,
    gravedad VARCHAR(10) NOT NULL,
    estado VARCHAR(20) NOT NULL,
    id_producto INT NOT NULL,
    id_mantenimiento INT,
    CONSTRAINT pk_falla PRIMARY KEY (id_falla),
    CONSTRAINT fk_falla_id_producto FOREIGN KEY (id_producto) REFERENCES producto (id_producto),
    CONSTRAINT fk_falla_id_mantenimiento FOREIGN KEY (id_mantenimiento) REFERENCES mantenimiento (id_mantenimiento)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS venta (
    id_venta INT NOT NULL AUTO_INCREMENT,
    precio_base DOUBLE PRECISION NOT NULL,
    igv DOUBLE PRECISION NOT NULL,
    precio_total DOUBLE PRECISION NOT NULL,
    serie VARCHAR(10) NOT NULL,
    num_doc VARCHAR(12) NOT NULL,
    tipo_doc VARCHAR(20) NOT NULL,
    fecha_gener DATE NOT NULL,
    dniruc VARCHAR(12) NOT NULL,
    id_usuario INT NOT NULL,
    CONSTRAINT pk_venta PRIMARY KEY (id_venta),
    CONSTRAINT fk_venta_dniruc FOREIGN KEY (dniruc) REFERENCES cliente (dniruc),
    CONSTRAINT fk_venta_id_usuario FOREIGN KEY (id_usuario) REFERENCES usuario (id_usuario)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS venta_detalle (
    id_venta_detalle INT NOT NULL AUTO_INCREMENT,
    pu DOUBLE PRECISION NOT NULL,
    cantidad DOUBLE PRECISION NOT NULL,
    descuento DOUBLE PRECISION NOT NULL,
    subtotal DOUBLE PRECISION NOT NULL,
    id_venta INT NOT NULL,
    id_producto INT NOT NULL,
    CONSTRAINT pk_venta_detalle PRIMARY KEY (id_venta_detalle),
    CONSTRAINT fk_venta_detalle_id_venta FOREIGN KEY (id_venta) REFERENCES venta (id_venta),
    CONSTRAINT fk_venta_detalle_id_producto FOREIGN KEY (id_producto) REFERENCES producto (id_producto)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS importacion (
    id_importacion INT NOT NULL AUTO_INCREMENT,
    precio_base DOUBLE PRECISION NOT NULL,
    flete DOUBLE PRECISION NOT NULL,
    aranceles DOUBLE PRECISION NOT NULL,
    igv DOUBLE PRECISION NOT NULL,
    precio_total DOUBLE PRECISION NOT NULL,
    serie VARCHAR(10) NOT NULL,
    num_doc VARCHAR(12) NOT NULL,
    tipo_doc VARCHAR(20) NOT NULL,
    fecha_imp DATE NOT NULL,
    id_proveedor INT NOT NULL,
    id_usuario INT NOT NULL,
    CONSTRAINT pk_importacion PRIMARY KEY (id_importacion),
    CONSTRAINT fk_importacion_id_proveedor FOREIGN KEY (id_proveedor) REFERENCES proveedor (id_proveedor),
    CONSTRAINT fk_importacion_id_usuario FOREIGN KEY (id_usuario) REFERENCES usuario (id_usuario)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS importacion_detalle (
    id_importacion_detalle INT NOT NULL AUTO_INCREMENT,
    pu DOUBLE PRECISION NOT NULL,
    cantidad DOUBLE PRECISION NOT NULL,
    subtotal DOUBLE PRECISION NOT NULL,
    id_importacion INT NOT NULL,
    id_producto INT NOT NULL,
    CONSTRAINT pk_importacion_detalle PRIMARY KEY (id_importacion_detalle),
    CONSTRAINT fk_importacion_detalle_id_importacion FOREIGN KEY (id_importacion) REFERENCES importacion (id_importacion),
    CONSTRAINT fk_importacion_detalle_id_producto FOREIGN KEY (id_producto) REFERENCES producto (id_producto)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS vent_carrito (
    id_carrito INT NOT NULL AUTO_INCREMENT,
    dniruc VARCHAR(12) NOT NULL,
    tipo_producto VARCHAR(10) NOT NULL,
    id_producto INT NOT NULL,
    nombre_producto VARCHAR(60) NOT NULL,
    cantidad DOUBLE PRECISION NOT NULL,
    punitario DOUBLE PRECISION NOT NULL,
    ptotal DOUBLE PRECISION NOT NULL,
    estado INT NOT NULL,
    id_usuario INT NOT NULL,
    CONSTRAINT pk_vent_carrito PRIMARY KEY (id_carrito),
    CONSTRAINT fk_vent_carrito_dniruc FOREIGN KEY (dniruc) REFERENCES cliente (dniruc),
    CONSTRAINT fk_vent_carrito_id_producto FOREIGN KEY (id_producto) REFERENCES producto (id_producto),
    CONSTRAINT fk_vent_carrito_id_usuario FOREIGN KEY (id_usuario) REFERENCES usuario (id_usuario)
) ENGINE=InnoDB;
