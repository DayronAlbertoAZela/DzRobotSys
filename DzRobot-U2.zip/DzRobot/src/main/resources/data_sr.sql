INSERT INTO perfil (id_perfil, nombre) VALUES
    (1, 'ADMIN'),
    (2, 'GESTOR_REPARACIONES'),
    (3, 'GERENTE_IMPORTACIONES'),
    (4, 'VENDEDOR');

INSERT INTO usuario (usuario, clave, estado, id_perfil) VALUES
    ('admin', '65536:2J5j5t3uGF56IaOAdQrBdw==:SOuYjukf1JwBJYyujv9YDD0TfqIFq+fhxb4ULtx0VeU=', 'ACTIVO', 1),
    ('gestor', '65536:Ji/D8Ppe4k/u/JycVa8YDw==:fSPkdmk+AZgjkeR8KO+sk4gwGErGBnyjhoEVD3KCnBM=', 'ACTIVO', 2),
    ('gerente', '65536:wCoGjOxK9u2DiOACHPF1sQ==:SdoEA5+WSMlkTqBLRz2k864pJhaCpw+V3FOaleRQ0Wg=', 'ACTIVO', 3),
    ('vendedor', '65536:iQDc3FNT14IC2zvwFxICxg==:QOc+a9fdgHBnYCLron+ZnE4JJaZefuP85/lgwXYrVG4=', 'ACTIVO', 4);

INSERT INTO emisor (ruc, nombre_comercial, ubigeo, domicilio_fiscal, urbanizacion, departamento, provincia, distrito) VALUES
    ('20601234567', 'ROBOTEC IMPORT S.A.C.', '150115', 'Av. Javier Prado Este 1234', 'Santa Catalina', 'LIMA', 'LIMA', 'LA VICTORIA');

INSERT INTO cliente (dniruc, nombres, rep_legal, direccion, tipo_documento, celular) VALUES
    ('20123456789', 'Fábrica Andina S.A.C.', 'Juan Pérez Soto', 'Av. Argentina 2450, Lima', 'RUC', '014567890'),
    ('45678912', 'Lucía Ramos Vega', '-', 'Jr. Huancavelica 320, Lima', 'DNI', '987654321');

INSERT INTO proveedor (num_doc, nombre_razon, pais, celular, email, direccion) VALUES
    ('91440300MA5F', 'Shenzhen Robotics Ltd.', 'China', '+8675588881234', 'sales@szrobotics.cn', 'Nanshan District, Shenzhen'),
    ('DE811190455', 'KUKA Deutschland GmbH', 'Alemania', '+498217970', 'export@kuka.de', 'Zugspitzstr. 140, Augsburg');

INSERT INTO tecnico (dni, nombres, especialidad, celular) VALUES
    ('41234567', 'Carlos Mendoza Ríos', 'Mecánica industrial', '912345678'),
    ('42345678', 'Rosa Quispe Huamán', 'Electrónica', '923456789');

INSERT INTO marca (nombre, pais_origen) VALUES
    ('KUKA', 'Alemania'),
    ('DJI', 'China'),
    ('LEGO', 'Dinamarca');

INSERT INTO producto (codigo, nombre, modelo, tipo, fecha_adq, fecha_ult_mant, estado, pu, utilidad, id_marca, dniruc, vida_util, stock) VALUES
    ('IND-001', 'Brazo soldador', 'KR-16', 'INDUSTRIAL', DATE '2026-03-10', DATE '2026-10-05', 'EN_STOCK', 60000, 0.25, 1, NULL, 0, 1),
    ('MOV-001', 'Dron inspector', 'Matrice 30', 'MOVIL', DATE '2026-05-02', DATE '2026-05-02', 'EN_STOCK', 15000, 0.3, 2, NULL, 0, 1),
    ('EDU-001', 'Kit de aula', 'Mindstorms', 'EDUCATIVO', DATE '2026-07-20', DATE '2026-07-20', 'VENDIDO', 1200, 0.35, 3, '20123456789', 0, 0),
    ('REP-001', 'Servomotor de eje', 'SM-1500', 'MOTOR', DATE '2026-03-10', DATE '2026-03-10', 'EN_STOCK', 2500, 0.28, 1, NULL, 10000, 4),
    ('REP-002', 'Batería LiPo 6S', 'TB65', 'BATERIA', DATE '2026-05-02', DATE '2026-05-02', 'EN_STOCK', 300, 0.5, 2, NULL, 500, 10),
    ('REP-003', 'Sensor ultrasónico', 'EV3-US', 'SENSOR', DATE '2026-07-20', DATE '2026-07-20', 'EN_STOCK', 40, 0.47, 3, NULL, 20000, 25);

INSERT INTO robot_industrial (id_producto, capacidad_carga, num_ejes) VALUES
    (1, 16, 6);

INSERT INTO robot_movil (id_producto, locomocion, autonomia) VALUES
    (2, 'AEREO', 0.7);

INSERT INTO robot_educativo (id_producto, plataforma, nivel) VALUES
    (3, 'LEGO', 'BASICO');

INSERT INTO componente (num_serie, horas_uso, fecha_inst, estado, id_producto, id_repuesto) VALUES
    ('SM-0001', 8500, DATE '2026-03-10', 'ACTIVO', 1, 4),
    ('BT-0001', 120, DATE '2026-05-02', 'ACTIVO', 2, 5);

INSERT INTO mantenimiento (tipo_mant, fecha_mant, descripcion, mano_obra, costo_total, estado, id_producto, id_tecnico, id_usuario) VALUES
    ('CORRECTIVO', DATE '2026-10-05', 'Ajuste del servomotor del eje 1', 230, 350, 'FINALIZADO', 1, 1, 2);

INSERT INTO mantenimiento_detalle (accion, observacion, costo, id_mantenimiento, id_componente) VALUES
    ('REPARADO', 'Cambio de rodamiento', 120, 1, 1);

INSERT INTO falla (descripcion, fecha_reporte, gravedad, estado, id_producto, id_mantenimiento) VALUES
    ('Vibración anormal en el eje 1', DATE '2026-10-01', 'MEDIA', 'RESUELTA', 1, 1);

INSERT INTO venta (precio_base, igv, precio_total, serie, num_doc, tipo_doc, fecha_gener, dniruc, id_usuario) VALUES
    (100, 18, 118, 'B001', '00000001', 'BOLETA', DATE '2026-10-10', '45678912', 4),
    (2118.64, 381.36, 2500, 'F001', '00000001', 'FACTURA', DATE '2026-10-12', '20123456789', 4);

INSERT INTO venta_detalle (pu, cantidad, descuento, subtotal, id_venta, id_producto) VALUES
    (59, 2, 0, 118, 1, 6),
    (1620, 1, 0, 1620, 2, 3),
    (450, 2, 20, 880, 2, 5);

INSERT INTO importacion (precio_base, flete, aranceles, igv, precio_total, serie, num_doc, tipo_doc, fecha_imp, id_proveedor, id_usuario) VALUES
    (18000, 2000, 4500, 4410, 28910, 'INV', '2026-0452', 'INVOICE', DATE '2026-05-02', 1, 3);

INSERT INTO importacion_detalle (pu, cantidad, subtotal, id_importacion, id_producto) VALUES
    (15000, 1, 15000, 1, 2),
    (300, 10, 3000, 1, 5);
