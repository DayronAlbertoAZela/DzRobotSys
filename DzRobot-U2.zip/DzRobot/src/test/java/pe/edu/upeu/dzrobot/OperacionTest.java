package pe.edu.upeu.dzrobot;

import org.junit.jupiter.api.Test;
import pe.edu.upeu.dzrobot.config.AppContext;
import pe.edu.upeu.dzrobot.operaciones.LineaMantenimiento;
import pe.edu.upeu.dzrobot.operaciones.OperacionRepository;
import pe.edu.upeu.dzrobot.repository.ConsultaRepository;

import java.time.LocalDate;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class OperacionTest {
    private final ConsultaRepository consultas;
    private final OperacionRepository operaciones = new OperacionRepository();

    OperacionTest() {
        AppContext.getInstance();
        consultas = new ConsultaRepository();
    }

    @Test
    void elMantenimientoFinalizadoResuelveLasFallasYReemplazaElComponente() {
        long falla = operaciones.reportarFalla(2, "Batería pierde carga", "ALTA", LocalDate.now());
        double stockAntes = consultas.numero("SELECT stock FROM producto WHERE id_producto = 5");

        long id = operaciones.registrarMantenimiento(2, 2, "CORRECTIVO", LocalDate.now(), "Cambio de batería",
                150, "FINALIZADO", 1L, false,
                List.of(new LineaMantenimiento(2, 5, "BT-0001", "REEMPLAZADO", "Nueva", 450)));

        assertEquals(600, consultas.numero("SELECT costo_total FROM mantenimiento WHERE id_mantenimiento = ?", id));
        assertEquals(stockAntes - 1, consultas.numero("SELECT stock FROM producto WHERE id_producto = 5"));
        assertEquals(0, consultas.numero("SELECT horas_uso FROM componente WHERE id_componente = 2"));
        assertEquals(1, consultas.numero("SELECT COUNT(*) FROM falla WHERE id_falla = ? AND estado = 'RESUELTA' "
                + "AND id_mantenimiento = ?", falla, id));
    }

    @Test
    void sinStockNoSeReemplazaYNoSeGuardaNada() {
        double antes = consultas.numero("SELECT COUNT(*) FROM mantenimiento");
        consultas.ejecutar("UPDATE producto SET stock = 0 WHERE id_producto = 6");
        assertThrows(IllegalStateException.class, () -> operaciones.registrarMantenimiento(1, 1, "PREVENTIVO",
                LocalDate.now(), "Revisión general", 50, "EN_PROCESO", 1L, false,
                List.of(new LineaMantenimiento(1, 6, "SM-0001", "REEMPLAZADO", "-", 10))));
        assertEquals(antes, consultas.numero("SELECT COUNT(*) FROM mantenimiento"));
        consultas.ejecutar("UPDATE producto SET stock = 25 WHERE id_producto = 6");
    }
}
