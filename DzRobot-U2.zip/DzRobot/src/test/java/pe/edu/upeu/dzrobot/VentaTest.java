package pe.edu.upeu.dzrobot;

import org.junit.jupiter.api.Test;
import pe.edu.upeu.dzrobot.components.comprob.ComprobantePdfService;
import pe.edu.upeu.dzrobot.config.AppContext;
import pe.edu.upeu.dzrobot.dto.comprobante.Comprobante;
import pe.edu.upeu.dzrobot.enums.TipoProducto;
import pe.edu.upeu.dzrobot.model.Venta;
import pe.edu.upeu.dzrobot.repository.ConsultaRepository;
import pe.edu.upeu.dzrobot.service.IVentCarritoService;
import pe.edu.upeu.dzrobot.service.IVentaService;
import pe.edu.upeu.dzrobot.utils.NumeroLetras;

import java.math.BigDecimal;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.LocalDate;

import static org.junit.jupiter.api.Assertions.*;

class VentaTest {
    private final AppContext ctx = AppContext.getInstance();
    private final IVentCarritoService carrito = ctx.getBean(IVentCarritoService.class);
    private final IVentaService ventas = ctx.getBean(IVentaService.class);
    private final ConsultaRepository consultas = new ConsultaRepository();

    @Test
    void laVentaDescuentaStockVaciaElCarritoYGeneraComprobantePdf() throws Exception {
        double stockAntes = consultas.numero("SELECT stock FROM producto WHERE id_producto = 6");
        carrito.agregar("45678912", TipoProducto.REPUESTO, 6L, 2, 1L);
        assertEquals(1, carrito.listarPorCliente("45678912").size());

        Venta venta = ventas.registrarVenta("45678912", "BOLETA", LocalDate.now(), 1L);

        assertEquals("B001", venta.getSerie());
        assertEquals(stockAntes - 2, consultas.numero("SELECT stock FROM producto WHERE id_producto = 6"));
        assertTrue(carrito.listarPorCliente("45678912").isEmpty());

        Comprobante comprobante = ventas.generarComprobante(venta.getId());
        assertEquals(1, comprobante.getItems().size());
        assertEquals(0, comprobante.getTotal().compareTo(BigDecimal.valueOf(venta.getPrecioTotal())));

        Path pdf = Files.createTempFile("comprobante", ".pdf");
        new ComprobantePdfService().exportar(comprobante, pdf);
        assertTrue(Files.size(pdf) > 1000);
        assertEquals("%PDF", new String(Files.readAllBytes(pdf), 0, 4));
    }

    @Test
    void noSeAgregaUnRobotVendidoNiMasStockDelDisponible() {
        assertThrows(RuntimeException.class, () -> carrito.agregar("45678912", TipoProducto.ROBOT, 3L, 1, 1L));
        assertThrows(RuntimeException.class, () -> carrito.agregar("45678912", TipoProducto.REPUESTO, 4L, 99, 1L));
        assertTrue(carrito.listarPorCliente("45678912").isEmpty());
    }

    @Test
    void laFacturaExigeClienteConRuc() {
        carrito.agregar("45678912", TipoProducto.REPUESTO, 5L, 1, 1L);
        assertThrows(RuntimeException.class, () -> ventas.registrarVenta("45678912", "FACTURA", LocalDate.now(), 1L));
        carrito.vaciar("45678912");
    }

    @Test
    void elTotalSeEscribeEnLetras() {
        assertEquals("CIENTO VEINTITRES CON 45/100 SOLES", NumeroLetras.soles(new BigDecimal("123.45")));
    }
}
