package pe.edu.upeu.dzrobot;

import org.junit.jupiter.api.Test;
import pe.edu.upeu.dzrobot.enums.NivelEducativo;
import pe.edu.upeu.dzrobot.enums.TipoLocomocion;
import pe.edu.upeu.dzrobot.model.*;
import pe.edu.upeu.dzrobot.util.PasswordUtil;

import java.time.LocalDate;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class ModeloTest {
    private final LocalDate base = LocalDate.of(2026, 1, 1);

    @Test
    void cadaTipoDeRobotCalculaSuPropioMantenimiento() {
        Robot industrial = RobotIndustrial.builder().fechaAdq(base).capacidadCarga(800.0).numEjes(6).build();
        Robot dron = RobotMovil.builder().fechaAdq(base).locomocion(TipoLocomocion.AEREO).autonomia(0.7).build();
        Robot kit = RobotEducativo.builder().fechaAdq(base).plataforma("LEGO").nivel(NivelEducativo.BASICO).build();
        assertEquals(base.plusDays(60), industrial.calcularProximoMantenimiento());
        assertEquals(base.plusDays(45), dron.calcularProximoMantenimiento());
        assertEquals(base.plusYears(1), kit.calcularProximoMantenimiento());
    }

    @Test
    void unComponenteDesgastadoActivaLaAlerta() {
        Robot kit = RobotEducativo.builder().fechaAdq(LocalDate.now()).plataforma("LEGO").nivel(NivelEducativo.BASICO).build();
        assertFalse(kit.necesitaMantenimiento());
        Repuesto bateria = Repuesto.builder().vidaUtil(500.0).build();
        kit.setComponentes(List.of(Componente.builder().horasUso(450.0).idRepuesto(bateria).build()));
        assertTrue(kit.necesitaMantenimiento());
    }

    @Test
    void ventaEImportacionCalculanSusTotalesDeFormaDistinta() {
        Venta venta = new Venta();
        venta.getDetalleVenta().add(VentaDetalle.builder().pu(59).cantidad(2).build());
        assertEquals(118.0, venta.calcularTotal(), 0.001);
        assertEquals(100.0, venta.getPrecioBase(), 0.001);
        assertEquals(18.0, venta.getIgv(), 0.001);

        Importacion imp = new Importacion();
        imp.getDetalle().add(ImportacionDetalle.builder().pu(15000).cantidad(1).build());
        imp.getDetalle().add(ImportacionDetalle.builder().pu(300).cantidad(10).build());
        imp.setFlete(2000);
        imp.setAranceles(4500);
        assertEquals(28910.0, imp.calcularTotal(), 0.001);
    }

    @Test
    void laClaveSeGuardaComoHash() {
        String hash = PasswordUtil.hashear("admin123");
        assertFalse(hash.contains("admin123"));
        assertTrue(PasswordUtil.verificar("admin123", hash));
        assertFalse(PasswordUtil.verificar("otra", hash));
    }
}
