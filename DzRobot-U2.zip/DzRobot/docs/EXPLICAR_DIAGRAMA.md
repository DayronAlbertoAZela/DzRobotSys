# Cómo explicar el diagrama de la base de datos

Explica el diagrama por zonas, de arriba hacia abajo, siguiendo los colores. Toma unos 3 minutos.

## 0. Apertura (15 segundos)

> "Este es el modelo relacional de DzRobot, hecho en SQL Power Architect. Tiene 20 tablas y 26 relaciones, y está ordenado por módulos con colores: seguridad, ventas, catálogo, reparaciones e importaciones. A partir de este modelo generé el script SQL con Forward Engineer."

## 1. Seguridad (morado): `perfil`, `usuario`, `emisor`

- **perfil → usuario (1 a muchos):** un perfil (ADMIN, VENDEDOR, GESTOR, GERENTE) lo tienen varios usuarios, y cada usuario tiene un solo perfil. Según el perfil, el sistema muestra un menú distinto.
- **usuario.clave** no guarda la contraseña: guarda un hash PBKDF2 con sal.
- **emisor** guarda los datos de la empresa (RUC, dirección) que salen impresos en la boleta o factura. No se relaciona con otras tablas porque es un solo registro de configuración.

## 2. Ventas (naranja): `cliente`, `venta`, `venta_detalle`, `vent_carrito`

- **cliente** usa como llave primaria `dniruc`: 8 dígitos si es DNI, 11 si es RUC. Es una llave natural, porque el documento ya es único.
- **cliente → venta (1 a muchos)** y **usuario → venta (1 a muchos):** cada venta registra quién compró y qué vendedor la hizo.
- **venta → venta_detalle (1 a muchos):** la cabecera guarda la serie, el número, el IGV y el total; el detalle guarda cada producto con su cantidad, precio y descuento. Esto es la **normalización**: no repito los datos de la venta en cada producto.
- **venta_detalle** apunta a `producto` con `id_producto`: cada fila puede ser un robot o un repuesto, porque los dos son productos.
- **vent_carrito** guarda los productos temporalmente mientras se arma la venta. Al registrar la venta, pasan a `venta_detalle` y el carrito se vacía.

## 3. Catálogo (azul): `marca`, `producto`, los tres subtipos de robot y `componente`

- **producto** está al centro porque es la tabla más relacionada. Guarda **robots y repuestos en una sola tabla**; la columna `tipo` dice qué es: INDUSTRIAL, MOVIL o EDUCATIVO para robots, y MOTOR, BATERIA, SENSOR o CONTROLADOR para repuestos.
- Así una venta, una importación o un carrito apuntan siempre a `producto`, sin tener dos columnas (una para robot y otra para repuesto). Esta mejora la propuso el profesor.
- `stock` y `vida_util` sirven sobre todo a los repuestos. En un robot, el stock es 1 mientras está EN_STOCK y 0 cuando se vende.
- **marca → producto (1 a muchos).**
- **Herencia en la base de datos:**
  - `robot_industrial`, `robot_movil` y `robot_educativo` tienen como llave primaria el mismo `id_producto`, que a la vez es llave foránea hacia `producto`. Son relaciones **1 a 1 identificadoras**.
  - Así represento en tablas la herencia de Java: `Robot` es la clase abstracta y las otras tres heredan de ella. Los datos comunes van en `producto` y los propios de cada tipo de robot en su tabla.
- **producto.dniruc → cliente:** acepta vacío. Se llena cuando el robot se vende, para saber de quién es.
- **componente** une un producto con otro producto (**muchos a muchos**): `id_producto` es el robot e `id_repuesto` es la pieza instalada, y las dos columnas apuntan a `producto`. Un robot tiene varias piezas, y un mismo repuesto puede estar instalado en varios robots. Guarda el número de serie y las horas de uso de cada pieza.

## 4. Reparaciones (verde, izquierda): `tecnico`, `falla`, `mantenimiento`, `mantenimiento_detalle`

- **producto → falla (1 a muchos):** se reportan las fallas de un robot.
- **mantenimiento** se relaciona con robot, técnico y usuario: qué robot se reparó, quién lo hizo y quién lo registró.
- **mantenimiento → mantenimiento_detalle ← componente:** cada línea dice qué pieza se revisó o se reemplazó.
- **falla.id_mantenimiento** acepta vacío: la falla nace sin mantenimiento y, cuando se repara, se enlaza al mantenimiento que la resolvió.

## 5. Importaciones (verde, derecha): `proveedor`, `importacion`, `importacion_detalle`

- Tiene la misma estructura cabecera–detalle que la venta: **proveedor → importacion → importacion_detalle**, y el detalle apunta a `producto`.
- **importacion** guarda además el flete, los aranceles y el IGV, para calcular el costo real.

## 6. Cierre (15 segundos)

> "En resumen: uso llaves primarias autoincrementables, salvo en cliente; llaves foráneas para mantener la integridad referencial; tablas cabecera–detalle para ventas, importaciones y mantenimientos; y relaciones 1 a 1 para representar la herencia de los robots."

## Preguntas que te pueden hacer

| Pregunta | Respuesta corta |
|---|---|
| ¿Qué significan las líneas? | Son llaves foráneas. El lado con la "pata de gallo" es el lado "muchos". |
| ¿Qué es una relación identificadora? | La llave foránea también forma parte de la llave primaria, como `id_producto` en `robot_movil`. |
| ¿Por qué hay detalle aparte? | Por la normalización (1FN/2FN): una venta tiene muchos productos, y no repito la cabecera en cada uno. |
| ¿Por qué `vent_carrito` va en la base y no en memoria? | Para no perder el carrito si se cierra la ventana, y para que cada carrito quede ligado a su cliente y su vendedor. |
| ¿Por qué `emisor` no tiene relaciones? | Es configuración de la empresa: un solo registro que se lee al imprimir el comprobante. |
| ¿Cómo generaste las tablas? | En Power Architect, con Tools → Forward Engineer, elegí PostgreSQL o MySQL y ejecuté el script. |
| ¿Qué pasa si borro un cliente con ventas? | La llave foránea no lo permite, y así se protege la integridad de los datos. |
