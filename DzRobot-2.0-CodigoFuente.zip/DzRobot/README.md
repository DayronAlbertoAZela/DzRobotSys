# DzRobot 2.0

Sistema de escritorio para **Robotec Import**, empresa que importa, vende y repara robots y repuestos.
Proyecto de Programación Orientada a Objetos (Java 21 + JavaFX 21).

## Funcionalidades por perfil

| Perfil | Usuario / clave | Módulos |
|---|---|---|
| Administrador | admin / admin123 | Todo el sistema y la gestión de usuarios |
| Vendedor | vendedor / vendedor123 | Robots, clientes, registrar venta, historial de ventas |
| Gestor de reparaciones | gestor / gestor123 | Robots, repuestos, mantenimientos, fallas, técnicos |
| Gerente de importaciones | gerente / gerente123 | Robots, repuestos, proveedores, registrar importación, historial |

## Tecnologías

- Java 21, JavaFX 21 (FXML), Maven
- Lombok, Jakarta Validation (Hibernate Validator)
- JDBC con HikariCP; base de datos H2 (también MySQL o PostgreSQL)
- OpenPDF (comprobante), jsoup (consulta de DNI en RENIEC), PBKDF2 (contraseñas)

## Ejecutar desde el código

```
mvn clean javafx:run
```

La base H2 se crea sola en `./data` con datos de ejemplo. Para cambiar a MySQL o PostgreSQL,
edite `src/main/resources/application.properties`.

## Pruebas

```
mvn test
```

## Estructura

```
src/main/java/pe/edu/upeu/dzrobot/
  model/        entidades (Robot, Repuesto, Cliente, Venta, Importacion...)
  repository/   acceso a datos con JDBC (repositorio genérico)
  service/      reglas de negocio (servicio genérico)
  controller/   controladores JavaFX
  modulos/      pantallas creadas por código (mantenimiento, fallas, importación...)
  config/       AppContext (inyección de dependencias) y DatabaseConfig
src/main/resources/
  view/         pantallas FXML
  css/          estilos
  schema_sr.sql, data_sr.sql   creación de tablas y datos de ejemplo
docs/           manual de usuario, guion, modelo de base de datos (Power Architect)
instalador/     script NSIS para generar el instalador de Windows
```

## Instalador de Windows

Ver `instalador/COMO_GENERAR_INSTALADOR.md`.
