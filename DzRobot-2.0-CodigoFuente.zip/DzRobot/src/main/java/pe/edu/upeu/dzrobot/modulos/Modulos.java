package pe.edu.upeu.dzrobot.modulos;

import javafx.scene.Node;
import pe.edu.upeu.dzrobot.config.AppContext;
import pe.edu.upeu.dzrobot.controller.VentaController;
import pe.edu.upeu.dzrobot.dto.SessionManager;
import pe.edu.upeu.dzrobot.service.IVentaService;
import pe.edu.upeu.dzrobot.repository.ConsultaRepository;

import java.util.List;

import static pe.edu.upeu.dzrobot.modulos.Columna.*;
import static pe.edu.upeu.dzrobot.modulos.ModuloConsulta.*;

public final class Modulos {
    private static final ConsultaRepository REPO = new ConsultaRepository();

    private Modulos() {
    }

    public static Node crear(String id) {
        return switch (id) {
            case "mitecnico" -> tecnicos();
            case "miproveedor" -> proveedores();
            case "mihventa" -> ventas();
            case "mifalla" -> new ReporteFallas(REPO).crear();
            case "miimport" -> importaciones();
            case "miregimport" -> new RegistroImportacion(REPO).crear();
            case "mimant" -> new RegistroMantenimiento(REPO).crear();
            case "mihmant" -> mantenimientos();
            case "miusuario" -> usuarios();
            default -> null;
        };
    }

    private static Node tecnicos() {
        return new ModuloCrud(REPO, "Gestionar Técnicos", "técnico", "tecnico", "id_tecnico",
                List.of(Campo.texto("IDENTIFICACIÓN", "DNI", "dni", "\\d{8}", "El DNI debe tener 8 dígitos"),
                        Campo.texto(null, "Nombres", "nombres", ".{3,60}", "Escriba los nombres (3 a 60 letras)"),
                        Campo.combo("TRABAJO", "Especialidad", "especialidad",
                                List.of("Mecánica industrial", "Electrónica", "Programación", "Drones", "Robótica educativa")),
                        Campo.texto("CONTACTO", "Celular", "celular", "\\d{9}", "El celular debe tener 9 dígitos")),
                List.of(numero("ID", "id_tecnico", 45), texto("DNI", "dni", 90), texto("Nombres", "nombres", 200),
                        pildora("Especialidad", "especialidad", 170, v -> v.startsWith("Mec") ? "naranja"
                                : v.startsWith("Elec") ? "celeste" : v.startsWith("Prog") ? "morado" : "verde"),
                        texto("Celular", "celular", 110))).crear();
    }

    private static Node proveedores() {
        return new ModuloCrud(REPO, "Gestionar Proveedores", "proveedor", "proveedor", "id_proveedor",
                List.of(Campo.texto("IDENTIFICACIÓN", "N° documento", "num_doc", "[A-Za-z0-9-]{5,20}", "Documento de 5 a 20 caracteres"),
                        Campo.texto(null, "Razón social", "nombre_razon", ".{3,60}", "Escriba la razón social"),
                        Campo.combo("UBICACIÓN", "País", "pais",
                                List.of("China", "Alemania", "Japón", "Estados Unidos", "Corea del Sur", "Dinamarca", "Perú")),
                        Campo.texto(null, "Dirección", "direccion", ".{3,80}", "Escriba la dirección"),
                        Campo.texto("CONTACTO", "Celular", "celular", "\\+?\\d{6,15}", "Celular de 6 a 15 dígitos (puede iniciar con +)"),
                        Campo.texto(null, "Email", "email", "[^@\\s]+@[^@\\s]+\\.[a-zA-Z]{2,}", "Escriba un email válido")),
                List.of(numero("ID", "id_proveedor", 45), texto("Documento", "num_doc", 110), texto("Razón social", "nombre_razon", 190),
                        pildora("País", "pais", 110, v -> "China".equals(v) ? "rojo" : "Alemania".equals(v) ? "naranja" : "celeste"),
                        texto("Celular", "celular", 120), texto("Email", "email", 170), texto("Dirección", "direccion", 200))).crear();
    }

    private static Node ventas() {
        return new ModuloConsulta(REPO, "Ventas registradas",
                "SELECT v.id_venta, CONCAT(v.serie, '-', v.num_doc) AS documento, v.tipo_doc, v.fecha_gener, "
                        + "c.nombres AS cliente, u.usuario AS vendedor, v.precio_base, v.igv, v.precio_total "
                        + "FROM venta v JOIN cliente c ON c.dniruc = v.dniruc JOIN usuario u ON u.id_usuario = v.id_usuario "
                        + "ORDER BY v.fecha_gener DESC",
                List.of(texto("Documento", "documento", 120),
                        pildora("Tipo", "tipo_doc", 90, v -> "FACTURA".equals(v) ? "morado" : "celeste"),
                        texto("Fecha", "fecha_gener", 95), texto("Cliente", "cliente", 200), texto("Vendedor", "vendedor", 90),
                        moneda("Base", "precio_base", 100), moneda("IGV", "igv", 90), moneda("Total", "precio_total", 110)),
                "id_venta",
                "SELECT CONCAT(p.codigo, ' ', p.nombre) AS producto, "
                        + "CASE WHEN p.tipo IN ('INDUSTRIAL', 'MOVIL', 'EDUCATIVO') THEN 'ROBOT' ELSE 'REPUESTO' END AS tipo, "
                        + "d.pu, d.cantidad, d.descuento, d.subtotal FROM venta_detalle d "
                        + "JOIN producto p ON p.id_producto = d.id_producto "
                        + "WHERE d.id_venta = ?",
                List.of(texto("Producto", "producto", 220), pildora("Tipo", "tipo", 100, v -> "ROBOT".equals(v) ? "naranja" : "celeste"),
                        moneda("P. unit.", "pu", 100), numero("Cantidad", "cantidad", 80), moneda("Descuento", "descuento", 100),
                        moneda("Subtotal", "subtotal", 110)),
                List.of(new Resumen("Ventas", cantidad()), new Resumen("Total vendido", suma("precio_total")),
                        new Resumen("Ticket promedio", promedio("precio_total")), new Resumen("IGV", suma("igv"))),
                new ModuloConsulta.Accion(fila -> "Ver comprobante", (repo, fila) -> {
                    IVentaService ventas = AppContext.getInstance().getBean(IVentaService.class);
                    VentaController.mostrarComprobante(ventas.generarComprobante(((Number) fila.get("id_venta")).longValue()));
                    return "";
                })).crear();
    }

    private static Node importaciones() {
        return new ModuloConsulta(REPO, "Importaciones",
                "SELECT i.id_importacion, CONCAT(i.serie, '-', i.num_doc) AS documento, i.fecha_imp, "
                        + "p.nombre_razon AS proveedor, p.pais, i.precio_base, i.flete, i.aranceles, i.igv, i.precio_total "
                        + "FROM importacion i JOIN proveedor p ON p.id_proveedor = i.id_proveedor ORDER BY i.fecha_imp DESC, i.id_importacion DESC",
                List.of(texto("Documento", "documento", 120), texto("Fecha", "fecha_imp", 95), texto("Proveedor", "proveedor", 190),
                        pildora("País", "pais", 100, v -> "China".equals(v) ? "rojo" : "Alemania".equals(v) ? "naranja" : "celeste"),
                        moneda("Base", "precio_base", 100), moneda("Flete", "flete", 90), moneda("Aranceles", "aranceles", 95),
                        moneda("IGV", "igv", 90), moneda("Total", "precio_total", 110)),
                "id_importacion",
                "SELECT CONCAT(p.codigo, ' ', p.nombre) AS producto, "
                        + "CASE WHEN p.tipo IN ('INDUSTRIAL', 'MOVIL', 'EDUCATIVO') THEN 'ROBOT' ELSE 'REPUESTO' END AS tipo, d.pu, d.cantidad, d.subtotal "
                        + "FROM importacion_detalle d JOIN producto p ON p.id_producto = d.id_producto "
                        + "WHERE d.id_importacion = ?",
                List.of(texto("Producto", "producto", 220), pildora("Tipo", "tipo", 100, v -> "ROBOT".equals(v) ? "naranja" : "celeste"),
                        moneda("P. unit.", "pu", 100), numero("Cantidad", "cantidad", 80), moneda("Subtotal", "subtotal", 110)),
                List.of(new Resumen("Importaciones", cantidad()), new Resumen("Total importado", suma("precio_total")),
                        new Resumen("Fletes", suma("flete")), new Resumen("Aranceles", suma("aranceles"))),
                null).crear();
    }

    private static Node mantenimientos() {
        return new ModuloConsulta(REPO, "Mantenimientos",
                "SELECT m.id_mantenimiento, m.fecha_mant, CONCAT(r.codigo, ' ', r.nombre) AS robot, m.tipo_mant, "
                        + "t.nombres AS tecnico, m.descripcion, m.mano_obra, m.costo_total, m.estado "
                        + "FROM mantenimiento m JOIN producto r ON r.id_producto = m.id_producto "
                        + "JOIN tecnico t ON t.id_tecnico = m.id_tecnico ORDER BY m.fecha_mant DESC",
                List.of(texto("Fecha", "fecha_mant", 95), texto("Robot", "robot", 170),
                        pildora("Tipo", "tipo_mant", 110, v -> "PREVENTIVO".equals(v) ? "celeste" : "naranja"),
                        texto("Técnico", "tecnico", 170), texto("Descripción", "descripcion", 230),
                        moneda("Mano de obra", "mano_obra", 110), moneda("Costo total", "costo_total", 110),
                        pildora("Estado", "estado", 110, v -> "FINALIZADO".equals(v) ? "verde" : "EN_PROCESO".equals(v) ? "naranja" : "gris")),
                "id_mantenimiento",
                "SELECT c.num_serie AS componente, p.nombre AS repuesto, d.accion, d.observacion, d.costo "
                        + "FROM mantenimiento_detalle d JOIN componente c ON c.id_componente = d.id_componente "
                        + "JOIN producto p ON p.id_producto = c.id_repuesto WHERE d.id_mantenimiento = ?",
                List.of(texto("Componente", "componente", 120), texto("Repuesto", "repuesto", 170),
                        pildora("Acción", "accion", 110, v -> "REEMPLAZADO".equals(v) ? "naranja" : "verde"),
                        texto("Observación", "observacion", 240), moneda("Costo", "costo", 100)),
                List.of(new Resumen("Mantenimientos", cantidad()), new Resumen("Finalizados", contar("estado", "FINALIZADO")),
                        new Resumen("Costo total", suma("costo_total"))),
                null).crear();
    }

    private static Node usuarios() {
        return new ModuloConsulta(REPO, "Usuarios del sistema",
                "SELECT u.id_usuario, u.usuario, p.nombre AS perfil, u.estado FROM usuario u "
                        + "JOIN perfil p ON p.id_perfil = u.id_perfil ORDER BY u.id_usuario",
                List.of(numero("ID", "id_usuario", 45), texto("Usuario", "usuario", 150),
                        pildora("Perfil", "perfil", 190, v -> "ADMIN".equals(v) ? "morado" : v.startsWith("GESTOR") ? "naranja"
                                : v.startsWith("GERENTE") ? "celeste" : "verde"),
                        pildora("Estado", "estado", 100, v -> "ACTIVO".equals(v) ? "verde" : "gris")),
                null, null, null,
                List.of(new Resumen("Usuarios", cantidad()), new Resumen("Activos", contar("estado", "ACTIVO"))),
                new ModuloConsulta.Accion(
                        fila -> "ACTIVO".equals(fila.get("estado")) ? "Desactivar" : "Activar",
                        (repo, fila) -> {
                            if (fila.get("usuario").equals(SessionManager.getInstance().getUserName())) {
                                throw new IllegalStateException("No puede desactivar su propia cuenta");
                            }
                            String nuevo = "ACTIVO".equals(fila.get("estado")) ? "INACTIVO" : "ACTIVO";
                            repo.ejecutar("UPDATE usuario SET estado = ? WHERE id_usuario = ?", nuevo, fila.get("id_usuario"));
                            return "Usuario " + fila.get("usuario") + " ahora está " + nuevo;
                        })).crear();
    }
}
