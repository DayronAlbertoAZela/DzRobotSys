package pe.edu.upeu.dzrobot.operaciones;

/** Una línea del detalle de importación: qué producto llega, a qué precio y cuántos. */
public record LineaImportacion(Object idProducto, String producto, boolean esRobot, double pu, double cantidad) {

    public String getProducto() {
        return producto;
    }

    public String getTipo() {
        return esRobot ? "ROBOT" : "REPUESTO";
    }

    public double getPu() {
        return pu;
    }

    public double getCantidad() {
        return cantidad;
    }

    public double getSubtotal() {
        return pu * cantidad;
    }
}
