package pe.edu.upeu.dzrobot.modulos;

import javafx.beans.property.SimpleObjectProperty;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.TableCell;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.layout.Priority;
import javafx.scene.layout.VBox;
import javafx.util.converter.LocalDateStringConverter;
import pe.edu.upeu.dzrobot.components.Toast;
import pe.edu.upeu.dzrobot.dto.SessionManager;
import pe.edu.upeu.dzrobot.model.Importacion;
import pe.edu.upeu.dzrobot.model.ImportacionDetalle;
import pe.edu.upeu.dzrobot.operaciones.LineaImportacion;
import pe.edu.upeu.dzrobot.operaciones.OperacionRepository;
import pe.edu.upeu.dzrobot.repository.ConsultaRepository;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Map;
import java.util.function.Function;

/**
 * Pantalla "Registrar importación": cabecera (proveedor, documento, fecha, flete, aranceles)
 * y detalle (productos que llegan). Al guardar suma el stock en una transacción.
 */
public class RegistroImportacion {

    private final ConsultaRepository consultas;
    private final OperacionRepository operaciones = new OperacionRepository();

    private final ComboBox<Opcion> cbProveedor = new ComboBox<>();
    private final ComboBox<String> cbTipoDoc = new ComboBox<>();
    private final TextField txtSerie = new TextField("INV");
    private final TextField txtNumDoc = new TextField();
    private final DatePicker dpFecha = new DatePicker(LocalDate.now());
    private final TextField txtFlete = new TextField("0");
    private final TextField txtAranceles = new TextField("0");
    private final ComboBox<Opcion> cbProducto = new ComboBox<>();
    private final TextField txtPu = new TextField();
    private final TextField txtCantidad = new TextField("1");
    private final TableView<LineaImportacion> tabla = new TableView<>();
    private final Label lblBase = new Label();
    private final Label lblIgv = new Label();
    private final Label lblTotal = new Label();

    public RegistroImportacion(ConsultaRepository consultas) {
        this.consultas = consultas;
    }

    public Node crear() {
        Label titulo = new Label("Registrar importación");
        titulo.getStyleClass().add("titulo-modulo");

        cbProveedor.setPrefWidth(280);
        DateTimeFormatter dmy = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        dpFecha.setConverter(new LocalDateStringConverter(dmy, dmy));
        cbTipoDoc.getItems().addAll("INVOICE", "FACTURA");
        cbTipoDoc.setValue("INVOICE");
        txtSerie.setPrefWidth(80);
        txtNumDoc.setPromptText("Ej. 2026-0500");
        txtFlete.setPrefWidth(100);
        txtAranceles.setPrefWidth(100);
        txtFlete.textProperty().addListener((o, a, b) -> actualizarTotales());
        txtAranceles.textProperty().addListener((o, a, b) -> actualizarTotales());

        GridPane cabecera = new GridPane();
        cabecera.setHgap(10);
        cabecera.setVgap(8);
        cabecera.addRow(0, new Label("Proveedor"), cbProveedor, new Label("Fecha"), dpFecha);
        cabecera.addRow(1, new Label("Documento"), cbTipoDoc, new Label("Serie y N°"), new HBox(6, txtSerie, txtNumDoc));
        cabecera.addRow(2, new Label("Flete (S/)"), txtFlete, new Label("Aranceles (S/)"), txtAranceles);
        cabecera.getStyleClass().add("panel");

        cbProducto.setPrefWidth(300);
        cbProducto.valueProperty().addListener((o, a, b) -> {
            if (b != null) {
                txtCantidad.setText("1");
                txtCantidad.setDisable(b.extra().equals("ROBOT"));
            } else {
                txtCantidad.setDisable(false);
            }
        });
        txtPu.setPromptText("Costo unitario");
        txtPu.setPrefWidth(110);
        txtCantidad.setPrefWidth(70);
        Button btnAgregar = new Button("Agregar");
        btnAgregar.getStyleClass().add("btn-primario");
        btnAgregar.setOnAction(e -> agregar());
        HBox linea = new HBox(8, new Label("Producto"), cbProducto, new Label("P. unit."), txtPu,
                new Label("Cantidad"), txtCantidad, btnAgregar);
        linea.setAlignment(Pos.CENTER_LEFT);
        linea.getStyleClass().add("panel");

        armarTabla();
        VBox.setVgrow(tabla, Priority.ALWAYS);

        Button btnGuardar = new Button("Registrar importación");
        btnGuardar.getStyleClass().add("btn-primario");
        btnGuardar.setOnAction(e -> guardar());
        Button btnLimpiar = new Button("Limpiar");
        btnLimpiar.setOnAction(e -> limpiar());
        lblTotal.getStyleClass().add("total-importe");
        Pane espacio = new Pane();
        HBox.setHgrow(espacio, Priority.ALWAYS);
        HBox pie = new HBox(14, new Label("Base:"), lblBase, new Label("IGV 18%:"), lblIgv,
                new Label("Total:"), lblTotal, espacio, btnLimpiar, btnGuardar);
        pie.setAlignment(Pos.CENTER_LEFT);
        pie.getStyleClass().add("panel");

        VBox raiz = new VBox(10, titulo, cabecera, linea, tabla, pie);
        raiz.setPadding(new Insets(10));

        cargarProveedores();
        cargarProductos();
        actualizarTotales();
        return raiz;
    }

    private void armarTabla() {
        tabla.getColumns().add(columna("Producto", 280, LineaImportacion::getProducto));
        tabla.getColumns().add(columna("Tipo", 100, LineaImportacion::getTipo));
        tabla.getColumns().add(columna("P. unit.", 110, l -> TablaMapa.SOLES.format(l.getPu())));
        tabla.getColumns().add(columna("Cantidad", 90, l -> String.valueOf((int) l.getCantidad())));
        tabla.getColumns().add(columna("Subtotal", 120, l -> TablaMapa.SOLES.format(l.getSubtotal())));
        TableColumn<LineaImportacion, Void> quitar = new TableColumn<>("");
        quitar.setPrefWidth(90);
        quitar.setCellFactory(x -> new TableCell<>() {
            private final Button boton = new Button("Quitar");

            {
                boton.getStyleClass().add("btn-peligro");
                boton.setOnAction(e -> {
                    tabla.getItems().remove(getIndex());
                    actualizarTotales();
                });
            }

            @Override
            protected void updateItem(Void item, boolean empty) {
                super.updateItem(item, empty);
                setGraphic(empty ? null : boton);
            }
        });
        tabla.getColumns().add(quitar);
        tabla.setPlaceholder(new Label("Agregue los productos que llegan en la importación"));
    }

    private TableColumn<LineaImportacion, String> columna(String titulo, double ancho,
                                                         Function<LineaImportacion, String> valor) {
        TableColumn<LineaImportacion, String> col = new TableColumn<>(titulo);
        col.setPrefWidth(ancho);
        col.setCellValueFactory(f -> new SimpleObjectProperty<>(valor.apply(f.getValue())));
        return col;
    }

    private void cargarProveedores() {
        cbProveedor.getItems().clear();
        for (Map<String, Object> f : consultas.filas("SELECT id_proveedor, nombre_razon, pais FROM proveedor ORDER BY nombre_razon")) {
            cbProveedor.getItems().add(new Opcion(f.get("id_proveedor"), f.get("nombre_razon") + " (" + f.get("pais") + ")", 0, null));
        }
        cbProveedor.setPromptText(cbProveedor.getItems().isEmpty() ? "Registre un proveedor primero" : "Elija");
    }

    /**
     * Repuestos: todos (se suma su stock). Robots: solo los registrados en el catálogo
     * que todavía no tienen una importación, porque cada robot llega una sola vez.
     */
    private void cargarProductos() {
        cbProducto.getItems().clear();
        for (Map<String, Object> f : consultas.filas(
                "SELECT p.id_producto, p.codigo, p.nombre, p.tipo, p.pu, p.stock FROM producto p "
                        + "WHERE p.tipo NOT IN ('INDUSTRIAL', 'MOVIL', 'EDUCATIVO') "
                        + "OR (p.estado = 'EN_STOCK' AND NOT EXISTS (SELECT 1 FROM importacion_detalle d WHERE d.id_producto = p.id_producto)) "
                        + "ORDER BY p.codigo")) {
            boolean robot = List.of("INDUSTRIAL", "MOVIL", "EDUCATIVO").contains(String.valueOf(f.get("tipo")));
            String texto = f.get("codigo") + " " + f.get("nombre")
                    + (robot ? " [robot]" : " [stock " + ((Number) f.get("stock")).intValue() + "]");
            cbProducto.getItems().add(new Opcion(f.get("id_producto"), texto,
                    ((Number) f.get("pu")).doubleValue(), robot ? "ROBOT" : "REPUESTO"));
        }
        cbProducto.setPromptText(cbProducto.getItems().isEmpty() ? "Registre el producto en Catálogo" : "Elija");
    }

    private void agregar() {
        Opcion p = cbProducto.getValue();
        if (p == null) {
            Toast.mostrar(tabla, "Elija un producto", Toast.Tipo.ERROR);
            return;
        }
        if (tabla.getItems().stream().anyMatch(l -> l.idProducto().equals(p.id()))) {
            Toast.mostrar(tabla, "Ese producto ya está en la lista", Toast.Tipo.ERROR);
            return;
        }
        double pu = numero(txtPu.getText());
        if (pu <= 0) {
            Toast.mostrar(tabla, "El precio unitario debe ser mayor a 0", Toast.Tipo.ERROR);
            return;
        }
        double cantidad = numero(txtCantidad.getText());
        if (cantidad < 1 || cantidad != Math.floor(cantidad)) {
            Toast.mostrar(tabla, "La cantidad debe ser un número entero mayor a 0", Toast.Tipo.ERROR);
            return;
        }
        boolean robot = "ROBOT".equals(p.extra());
        String nombre = p.texto().replaceAll(" \\[.*]$", "");
        tabla.getItems().add(new LineaImportacion(p.id(), nombre, robot, pu, robot ? 1 : cantidad));
        cbProducto.setValue(null);
        txtPu.clear();
        txtCantidad.setText("1");
        actualizarTotales();
    }

    private static double numero(String texto) {
        try {
            return Double.parseDouble(texto.trim());
        } catch (NumberFormatException e) {
            return -1;
        }
    }

    /** Usa el mismo cálculo del modelo (polimorfismo: Importacion.calcularTotal). */
    private void actualizarTotales() {
        Importacion vista = new Importacion();
        vista.setFlete(Math.max(numero(txtFlete.getText()), 0));
        vista.setAranceles(Math.max(numero(txtAranceles.getText()), 0));
        for (LineaImportacion l : tabla.getItems()) {
            vista.getDetalle().add(ImportacionDetalle.builder().pu(l.pu()).cantidad(l.cantidad()).build());
        }
        vista.calcularTotal();
        lblBase.setText(TablaMapa.SOLES.format(vista.getPrecioBase()));
        lblIgv.setText(TablaMapa.SOLES.format(vista.getIgv()));
        lblTotal.setText(TablaMapa.SOLES.format(vista.getPrecioTotal()));
    }

    private void guardar() {
        if (cbProveedor.getValue() == null) {
            Toast.mostrar(tabla, "Elija el proveedor", Toast.Tipo.ERROR);
            return;
        }
        String serie = txtSerie.getText().trim().toUpperCase();
        String numDoc = txtNumDoc.getText().trim().toUpperCase();
        if (!serie.matches("[A-Z0-9]{1,10}")) {
            Toast.mostrar(tabla, "La serie admite de 1 a 10 letras o números", Toast.Tipo.ERROR);
            return;
        }
        if (!numDoc.matches("[A-Z0-9-]{1,12}")) {
            Toast.mostrar(tabla, "El número de documento admite de 1 a 12 letras, números o guiones", Toast.Tipo.ERROR);
            return;
        }
        double flete = numero(txtFlete.getText());
        double aranceles = numero(txtAranceles.getText());
        if (flete < 0 || aranceles < 0) {
            Toast.mostrar(tabla, "El flete y los aranceles deben ser números positivos o 0", Toast.Tipo.ERROR);
            return;
        }
        try {
            Importacion imp = operaciones.registrarImportacion(cbProveedor.getValue().id(), cbTipoDoc.getValue(),
                    serie, numDoc, dpFecha.getValue(), flete, aranceles,
                    SessionManager.getInstance().getUserId(), List.copyOf(tabla.getItems()));
            Toast.mostrar(tabla, "Importación " + serie + "-" + numDoc + " registrada por "
                    + TablaMapa.SOLES.format(imp.getPrecioTotal()) + ". Stock actualizado.", Toast.Tipo.OK);
            limpiar();
        } catch (RuntimeException e) {
            Toast.mostrar(tabla, e.getMessage(), Toast.Tipo.ERROR);
        }
    }

    private void limpiar() {
        tabla.getItems().clear();
        txtNumDoc.clear();
        txtFlete.setText("0");
        txtAranceles.setText("0");
        dpFecha.setValue(LocalDate.now());
        cbProveedor.setValue(null);
        cargarProductos();
        actualizarTotales();
    }
}
