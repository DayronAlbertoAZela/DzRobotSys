package pe.edu.upeu.dzrobot.service.impl;

import pe.edu.upeu.dzrobot.dto.MenuMenuItenTO;
import pe.edu.upeu.dzrobot.service.IMenuMenuItemDao;

import java.util.ArrayList;
import java.util.List;

public class MenuMenuItemDaoImp implements IMenuMenuItemDao {
    private static final MenuMenuItenTO ROBOTS = new MenuMenuItenTO("mirobot", "/view/main_robot.fxml", "Catálogo", "Robots", "Gestión de Robots", "T");
    private static final MenuMenuItenTO REPUESTOS = new MenuMenuItenTO("mirepuesto", "/view/main_repuesto.fxml", "Catálogo", "Repuestos", "Gestión de Repuestos", "T");
    private static final MenuMenuItenTO CLIENTES = new MenuMenuItenTO("micliente", "/view/main_cliente.fxml", "Ventas", "Clientes", "Gestión de Clientes", "T");
    private static final MenuMenuItenTO VENTAS = new MenuMenuItenTO("miventa", "/view/main_venta.fxml", "Ventas", "Registrar venta", "Registrar venta", "T");
    private static final MenuMenuItenTO HIST_VENTAS = new MenuMenuItenTO("mihventa", "", "Ventas", "Historial de ventas", "Historial de ventas", "T");
    private static final MenuMenuItenTO FALLAS = new MenuMenuItenTO("mifalla", "", "Reparaciones", "Reportar fallas", "Reportar fallas", "T");
    private static final MenuMenuItenTO MANTENIMIENTOS = new MenuMenuItenTO("mimant", "", "Reparaciones", "Registrar mantenimiento", "Registrar mantenimiento", "T");
    private static final MenuMenuItenTO HIST_MANT = new MenuMenuItenTO("mihmant", "", "Reparaciones", "Historial de mantenimientos", "Historial de mantenimientos", "T");
    private static final MenuMenuItenTO TECNICOS = new MenuMenuItenTO("mitecnico", "", "Reparaciones", "Técnicos", "Técnicos", "T");
    private static final MenuMenuItenTO PROVEEDORES = new MenuMenuItenTO("miproveedor", "", "Importaciones", "Proveedores", "Proveedores", "T");
    private static final MenuMenuItenTO REG_IMPORT = new MenuMenuItenTO("miregimport", "", "Importaciones", "Registrar importación", "Registrar importación", "T");
    private static final MenuMenuItenTO IMPORTACIONES = new MenuMenuItenTO("miimport", "", "Importaciones", "Historial de importaciones", "Importaciones", "T");
    private static final MenuMenuItenTO USUARIOS = new MenuMenuItenTO("miusuario", "", "Administración", "Usuarios", "Usuarios", "T");
    private static final MenuMenuItenTO SALIR = new MenuMenuItenTO("misalir", "/view/login.fxml", "Sistema", "Cerrar sesión", "Salir", "C");

    @Override
    public List<MenuMenuItenTO> listaAccesos(String perfil) {
        List<MenuMenuItenTO> accesos = new ArrayList<>();
        switch (perfil) {
            case "ADMIN" -> accesos.addAll(List.of(ROBOTS, REPUESTOS, CLIENTES, VENTAS, HIST_VENTAS, MANTENIMIENTOS,
                    HIST_MANT, FALLAS, TECNICOS, PROVEEDORES, REG_IMPORT, IMPORTACIONES, USUARIOS));
            case "GESTOR_REPARACIONES" -> accesos.addAll(List.of(ROBOTS, REPUESTOS, MANTENIMIENTOS, HIST_MANT, FALLAS, TECNICOS));
            case "GERENTE_IMPORTACIONES" -> accesos.addAll(List.of(ROBOTS, REPUESTOS, PROVEEDORES, REG_IMPORT, IMPORTACIONES));
            case "VENDEDOR" -> accesos.addAll(List.of(ROBOTS, CLIENTES, VENTAS, HIST_VENTAS));
            default -> throw new IllegalArgumentException("Perfil desconocido: " + perfil);
        }
        accesos.add(SALIR);
        return accesos;
    }
}
