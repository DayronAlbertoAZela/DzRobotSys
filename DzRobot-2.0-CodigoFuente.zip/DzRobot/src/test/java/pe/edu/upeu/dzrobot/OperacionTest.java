package pe.edu.upeu.dzrobot;

import org.junit.jupiter.api.Test;
import pe.edu.upeu.dzrobot.config.AppContext;
import pe.edu.upeu.dzrobot.model.Importacion;
import pe.edu.upeu.dzrobot.operaciones.LineaImportacion;
import pe.edu.upeu.dzrobot.operaciones.LineaMantenimiento;
import pe.edu.upeu.dzrobot.operaciones.OperacionRepository;
import pe.edu.upeu.dzrobot.repository.ConsultaRepository;

import java.time.LocalDate;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class OperacionTest {
    private final ConsultaRepository consultas;
    private final OperacionRepository operaciones = new OperacionRepository();

    OperacionTest() {
        AppContext.getInstance();
        consultas = new ConsultaRepository();
    }

    @Test
    void elMantenimientoFinalizadoResuelveLasFallasYReemplazaElComponente() {
        long falla = operaciones.reportarFalla(2, "Batería pierde carga", "ALTA", LocalDate.now());
        double stockAntes = consultas.numero("SELECT stock FROM producto WHERE id_producto = 5");

        long id = operaciones.registrarMantenimiento(2, 2, "CORRECTIVO", LocalDate.now(), "Cambio de batería",
                150, "FINALIZADO", 1L, false,
                List.of(new LineaMantenimiento(2, 5, "BT-0001", "REEMPLAZADO", "Nueva", 450)));

        assertEquals(600, consultas.numero("SELECT costo_total FROM mantenimiento WHERE id_mantenimiento = ?", id));
        assertEquals(stockAntes - 1, consultas.numero("SELECT stock FROM producto WHERE id_producto = 5"));
        assertEquals(0, consultas.numero("SELECT horas_uso FROM componente WHERE id_componente = 2"));
        assertEquals(1, consultas.numero("SELECT COUNT(*) FROM falla WHERE id_falla = ? AND estado = 'RESUELTA' "
                + "AND id_mantenimiento = ?", falla, id));
    }

    @Test
    void sinStockNoSeReemplazaYNoSeGuardaNada() {
        double antes = consultas.numero("SELECT COUNT(*) FROM mantenimiento");
        consultas.ejecutar("UPDATE producto SET stock = 0 WHERE id_producto = 6");
        assertThrows(IllegalStateException.class, () -> operaciones.registrarMantenimiento(1, 1, "PREVENTIVO",
                LocalDate.now(), "Revisión general", 50, "EN_PROCESO", 1L, false,
                List.of(new LineaMantenimiento(1, 6, "SM-0001", "REEMPLAZADO", "-", 10))));
        assertEquals(antes, consultas.numero("SELECT COUNT(*) FROM mantenimiento"));
        consultas.ejecutar("UPDATE producto SET stock = 25 WHERE id_producto = 6");
    }

    @Test
    void laImportacionGuardaCabeceraYDetalleYSumaElStock() {
        double stockAntes = consultas.numero("SELECT stock FROM producto WHERE id_producto = 6");
        Importacion imp = operaciones.registrarImportacion(1, "INVOICE", "INV", "T-0001", LocalDate.now(),
                200, 100, 3L, List.of(new LineaImportacion(6, "Sensor", false, 50, 4),
                        new LineaImportacion(1, "IND-001", true, 1000, 1)));

        // base 1200, IGV = (1200 + 200 + 100) * 0.18 = 270, total 1770
        assertEquals(1200, imp.getPrecioBase());
        assertEquals(270, imp.getIgv());
        assertEquals(1770, consultas.numero("SELECT precio_total FROM importacion WHERE id_importacion = ?", imp.getId()));
        assertEquals(2, consultas.numero("SELECT COUNT(*) FROM importacion_detalle WHERE id_importacion = ?", imp.getId()));
        assertEquals(stockAntes + 4, consultas.numero("SELECT stock FROM producto WHERE id_producto = 6"));
        consultas.ejecutar("UPDATE producto SET stock = ? WHERE id_producto = 6", stockAntes);
    }

    @Test
    void noSeRepiteElDocumentoNiSeGuardaUnaImportacionVacia() {
        operaciones.registrarImportacion(1, "INVOICE", "INV", "T-0002", LocalDate.now(), 0, 0, 3L,
                List.of(new LineaImportacion(5, "Batería", false, 100, 1)));
        double antes = consultas.numero("SELECT COUNT(*) FROM importacion");
        assertThrows(IllegalArgumentException.class, () -> operaciones.registrarImportacion(1, "INVOICE", "INV", "T-0002",
                LocalDate.now(), 0, 0, 3L, List.of(new LineaImportacion(5, "Batería", false, 100, 1))));
        assertThrows(IllegalArgumentException.class, () -> operaciones.registrarImportacion(1, "INVOICE", "INV", "T-0003",
                LocalDate.now(), 0, 0, 3L, List.of()));
        assertThrows(IllegalArgumentException.class, () -> operaciones.registrarImportacion(1, "INVOICE", "INV", "T-0004",
                LocalDate.now().plusDays(1), 0, 0, 3L, List.of(new LineaImportacion(5, "Batería", false, 100, 1))));
        assertEquals(antes, consultas.numero("SELECT COUNT(*) FROM importacion"));
    }
}
