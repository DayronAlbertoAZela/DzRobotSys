package pe.edu.upeu.dzrobot;

import org.junit.jupiter.api.Test;
import pe.edu.upeu.dzrobot.config.AppContext;
import pe.edu.upeu.dzrobot.enums.EstadoRobot;
import pe.edu.upeu.dzrobot.enums.TipoLocomocion;
import pe.edu.upeu.dzrobot.model.*;
import pe.edu.upeu.dzrobot.service.IMarcaService;
import pe.edu.upeu.dzrobot.service.IMenuMenuItemDao;
import pe.edu.upeu.dzrobot.service.IRepuestoService;
import pe.edu.upeu.dzrobot.service.IRobotService;
import pe.edu.upeu.dzrobot.enums.TipoRepuesto;
import pe.edu.upeu.dzrobot.service.IUsuarioService;

import java.time.LocalDate;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class RepositorioTest {
    private final AppContext ctx = AppContext.getInstance();

    @Test
    void loginConHash() {
        IUsuarioService us = ctx.getBean(IUsuarioService.class);
        Usuario admin = us.loginUsuario("admin", "admin123").orElseThrow();
        assertEquals("ADMIN", admin.getIdPerfil().getNombre());
        assertTrue(us.loginUsuario("admin", "mala").isEmpty());
        assertTrue(us.loginUsuario("vendedor", "vendedor123").isPresent());
    }

    @Test
    void losRobotsSeLeenComoSuSubclase() {
        List<Robot> robots = ctx.getBean(IRobotService.class).findAll();
        assertEquals(3, robots.size());

        assertInstanceOf(RobotEducativo.class, robots.get(0));
        assertInstanceOf(RobotIndustrial.class, robots.get(1));
        assertInstanceOf(RobotMovil.class, robots.get(2));
        assertEquals(1, robots.get(1).getComponentes().size());
    }

    @Test
    void guardarActualizarYEliminarUnRobotMovil() {
        IRobotService rs = ctx.getBean(IRobotService.class);
        Marca dji = ctx.getBean(IMarcaService.class).findById(2L);
        RobotMovil nuevo = RobotMovil.builder().codigo("MOV-999").nombre("Rover").modelo("R1")
                .fechaAdq(LocalDate.now()).estado(EstadoRobot.EN_STOCK).pu(1000.0).utilidad(0.2)
                .idMarca(dji).locomocion(TipoLocomocion.RUEDAS).autonomia(5.0).build();
        rs.save(nuevo);
        assertNotNull(nuevo.getIdRobot());

        nuevo.setAutonomia(8.0);
        rs.update(nuevo.getIdRobot(), nuevo);
        RobotMovil leido = (RobotMovil) rs.findById(nuevo.getIdRobot());
        assertEquals(8.0, leido.getAutonomia());
        assertEquals(1200.0, leido.getPrecioVenta(), 0.001);

        rs.delete(nuevo.getIdRobot());
        assertThrows(RuntimeException.class, () -> rs.findById(nuevo.getIdRobot()));
    }

    @Test
    void unRobotVendidoSinDuenoSeRechaza() {
        IRobotService rs = ctx.getBean(IRobotService.class);
        Robot r = rs.findById(1L);
        r.setEstado(EstadoRobot.VENDIDO);
        r.setDniruc(null);
        assertThrows(IllegalArgumentException.class, () -> rs.update(1L, r));
    }

    @Test
    void elIndustrialConComponenteDesgastadoApareceEnAlertas() {
        List<Robot> alertas = ctx.getBean(IRobotService.class).listarQueNecesitanMantenimiento();
        assertTrue(alertas.stream().anyMatch(r -> r.getCodigo().equals("IND-001")));
    }

    @Test
    void elMenuCambiaSegunElPerfil() {
        IMenuMenuItemDao dao = ctx.getBean(IMenuMenuItemDao.class);
        assertEquals(14, dao.listaAccesos("ADMIN").size());
        assertTrue(dao.listaAccesos("VENDEDOR").stream().noneMatch(m -> m.getMenunombre().equals("Importaciones")));
    }

    @Test
    void robotsYRepuestosCompartenLaTablaProductoSinMezclarse() {
        IRepuestoService repuestos = ctx.getBean(IRepuestoService.class);
        assertTrue(repuestos.findAll().stream().allMatch(r -> r.getCodigo().startsWith("REP-")));
        assertTrue(ctx.getBean(IRobotService.class).findAll().stream().noneMatch(r -> r.getCodigo().startsWith("REP-")));

        Repuesto nuevo = repuestos.save(Repuesto.builder().codigo("REP-900").nombre("Controlador PLC").modelo("S7-1200")
                .tipoRepuesto(TipoRepuesto.CONTROLADOR).pu(800.0).utilidad(0.3).stock(2.0).vidaUtil(30000.0)
                .idMarca(ctx.getBean(IMarcaService.class).findById(1L)).build());
        assertEquals("REP-900", repuestos.findById(nuevo.getIdRepuesto()).getCodigo());
        repuestos.delete(nuevo.getIdRepuesto());
    }
}
