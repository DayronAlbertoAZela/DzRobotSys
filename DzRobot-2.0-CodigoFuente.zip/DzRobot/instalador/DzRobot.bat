@echo off
REM Inicia DzRobot sin instalar (version portable)
cd /d "%~dp0"
start "" "%~dp0runtime\bin\javaw.exe" "-Ddb.url=jdbc:h2:file:~/DzRobot/data/dzrobot" -cp "%~dp0lib\*" pe.edu.upeu.dzrobot.App
