Unicode true
!include "MUI2.nsh"

!define APP "DzRobot"
!define VERSION "2.0"
!define EMPRESA "Robotec Import"
!define LANZADOR '"$INSTDIR\runtime\bin\javaw.exe"'
!define ARGS '"-Ddb.url=jdbc:h2:file:~/DzRobot/data/dzrobot" -cp "$INSTDIR\lib\*" pe.edu.upeu.dzrobot.App'
!define UNINST "Software\Microsoft\Windows\CurrentVersion\Uninstall\${APP}"

Name "${APP} ${VERSION}"
OutFile "DzRobot-2.0-Instalador-Windows.exe"
InstallDir "$PROGRAMFILES64\${APP}"
InstallDirRegKey HKLM "Software\${APP}" "InstallDir"
RequestExecutionLevel admin
SetCompressor /SOLID lzma
BrandingText "${APP} ${VERSION} - ${EMPRESA}"

!define MUI_ICON "DzRobot\DzRobot.ico"
!define MUI_UNICON "DzRobot\DzRobot.ico"
!define MUI_ABORTWARNING
!define MUI_WELCOMEPAGE_TITLE "Instalación de DzRobot 2.0"
!define MUI_WELCOMEPAGE_TEXT "Este asistente instalará DzRobot, el sistema de importación, venta y reparación de robots.$\r$\n$\r$\nNo necesita tener Java instalado: ya viene incluido.$\r$\n$\r$\nPresione Siguiente para continuar."
!define MUI_FINISHPAGE_RUN
!define MUI_FINISHPAGE_RUN_FUNCTION Iniciar
!define MUI_FINISHPAGE_RUN_TEXT "Abrir DzRobot ahora"
!define MUI_FINISHPAGE_SHOWREADME "$INSTDIR\LEEME.txt"
!define MUI_FINISHPAGE_SHOWREADME_TEXT "Ver usuarios y contraseñas de prueba"

!insertmacro MUI_PAGE_WELCOME
!insertmacro MUI_PAGE_DIRECTORY
!insertmacro MUI_PAGE_INSTFILES
!insertmacro MUI_PAGE_FINISH
!insertmacro MUI_UNPAGE_CONFIRM
!insertmacro MUI_UNPAGE_INSTFILES
!insertmacro MUI_LANGUAGE "Spanish"

Function Iniciar
  SetOutPath "$INSTDIR"
  Exec '${LANZADOR} ${ARGS}'
FunctionEnd

Section "DzRobot" SecApp
  SectionIn RO
  SetOutPath "$INSTDIR"
  File /r "DzRobot\*.*"
  WriteUninstaller "$INSTDIR\Desinstalar.exe"

  SetOutPath "$INSTDIR"
  CreateDirectory "$SMPROGRAMS\${APP}"
  CreateShortCut "$SMPROGRAMS\${APP}\${APP}.lnk" ${LANZADOR} '${ARGS}' "$INSTDIR\DzRobot.ico" 0
  CreateShortCut "$SMPROGRAMS\${APP}\Desinstalar ${APP}.lnk" "$INSTDIR\Desinstalar.exe"
  CreateShortCut "$DESKTOP\${APP}.lnk" ${LANZADOR} '${ARGS}' "$INSTDIR\DzRobot.ico" 0

  WriteRegStr HKLM "Software\${APP}" "InstallDir" "$INSTDIR"
  WriteRegStr HKLM "${UNINST}" "DisplayName" "${APP} ${VERSION}"
  WriteRegStr HKLM "${UNINST}" "DisplayVersion" "${VERSION}"
  WriteRegStr HKLM "${UNINST}" "Publisher" "${EMPRESA}"
  WriteRegStr HKLM "${UNINST}" "DisplayIcon" "$INSTDIR\DzRobot.ico"
  WriteRegStr HKLM "${UNINST}" "UninstallString" '"$INSTDIR\Desinstalar.exe"'
  WriteRegDWORD HKLM "${UNINST}" "NoModify" 1
  WriteRegDWORD HKLM "${UNINST}" "NoRepair" 1
SectionEnd

Section "Uninstall"
  Delete "$DESKTOP\${APP}.lnk"
  RMDir /r "$SMPROGRAMS\${APP}"
  RMDir /r "$INSTDIR"
  DeleteRegKey HKLM "${UNINST}"
  DeleteRegKey HKLM "Software\${APP}"
SectionEnd
