# Cómo generar el instalador de Windows

El instalador `DzRobot-2.0-Instalador-Windows.exe` se arma con **NSIS** y trae Java incluido,
así que el usuario no necesita instalar nada más.

1. Compilar el proyecto: `mvn clean package` → genera `target/DzRobot-2.0.jar`.
2. Copiar las librerías de Windows:
   `mvn dependency:copy-dependencies -DincludeScope=runtime -Djavafx.platform=win -DoutputDirectory=lib`
   (borrar `lombok-*.jar` y los `javafx-*.jar` que no terminan en `-win`).
3. Armar la carpeta `instalador/DzRobot/`:
   - `runtime/` → un JRE 21 de Windows x64 (por ejemplo Eclipse Temurin 21, versión ZIP).
   - `lib/` → `DzRobot-2.0.jar` y las librerías del paso 2.
   - `DzRobot.ico`, `DzRobot.bat` y `LEEME.txt` (están en esta carpeta).
4. Ejecutar `makensis instalador.nsi` dentro de `instalador/`.

El acceso directo ejecuta:

```
runtime\bin\javaw.exe "-Ddb.url=jdbc:h2:file:~/DzRobot/data/dzrobot" -cp "lib\*" pe.edu.upeu.dzrobot.App
```

`-Ddb.url` hace que la base de datos se guarde en `C:\Users\<usuario>\DzRobot\data`,
porque la carpeta *Archivos de programa* no permite escribir.
