# Guion de sustentación · DzRobot 2.0

**Presentación individual.** Duración sugerida: 12 a 15 minutos más preguntas.

**Orden:**
1. Base del sistema: caso, login, arquitectura, POO, BD y validaciones. Unos 5 minutos.
2. CRUD de Robots, el CRUD completo con las 4 operaciones. Unos 3 minutos.
3. CRUD de Repuestos y Clientes, solo lo que es distinto. Unos 2 minutos.
4. Registrar venta, el punto fuerte. Unos 3 minutos.
5. Cierre.

**Si tienes poco tiempo:** haz la Parte 1 resumida, el CRUD de Robots completo y la venta. Los CRUD de repuestos y clientes son iguales por dentro, así que basta con decirlo y mostrar una validación de cada uno.

**Antes de empezar:**
- Abre el proyecto en IntelliJ y ejecuta `mvn clean javafx:run`.
- Ten abierto el diagrama en Power Architect.
- Ten a mano el usuario **admin / admin123**.
- Si quieres empezar con datos limpios, borra antes la carpeta `data`.

---

# PARTE 1 · Base del sistema

## 1.1 Presentación del caso (30 s)

> "Buenos días. Mi sistema se llama **DzRobot**. Es para la empresa Robotec Import, que **importa, vende y repara robots** y repuestos. Antes llevaban todo en Excel: no sabían qué robot estaba vendido, cuántos repuestos quedaban ni cuándo le tocaba mantenimiento a cada robot. DzRobot centraliza todo eso."

**Tecnologías:**
- Java 21, JavaFX 21 con FXML y Maven.
- Lombok y Jakarta Validation.
- Base de datos H2 por defecto, que también funciona con MySQL o PostgreSQL.
- HikariCP como pool de conexiones.
- OpenPDF para el comprobante y jsoup para consultar el DNI.

## 1.2 Login y perfiles (demo, 45 s)

1. **Haz:** entra con un usuario o clave incorrectos y muestra el mensaje de error. Luego entra con admin / admin123.

> "Las contraseñas **no se guardan en texto plano**. Uso **PBKDF2 con HMAC-SHA256**, 65 536 iteraciones y una **sal aleatoria** por usuario. En la base se guarda `iteraciones:sal:hash`. Al iniciar sesión vuelvo a calcular el hash con esa misma sal y comparo. Esto está en `PasswordUtil`, y fue parte de mi **investigación**."

> "Hay 4 perfiles: **ADMIN, VENDEDOR, GESTOR_REPARACIONES y GERENTE_IMPORTACIONES**. El menú cambia según el perfil, y eso se arma en `MenuMenuItemDaoImp`."

2. **Haz:** muestra el panel de inicio (indicadores y alertas de mantenimiento).

## 1.3 Arquitectura en capas (1 min)

Muestra en IntelliJ los paquetes:

```
model       → entidades (Robot, Cliente, Venta…), con validaciones
repository  → acceso a la BD con JDBC (SQL)
service     → reglas del negocio
controller  → atiende la pantalla (eventos JavaFX)
view (FXML) → la pantalla
config      → AppContext (inyección de dependencias) y DatabaseConfig
```

> "Cada capa tiene **una sola responsabilidad**. El controlador nunca escribe SQL: le pide al servicio, el servicio valida las reglas y llama al repositorio. Si mañana cambio de base de datos, solo toco el repositorio."

**Patrones que debes nombrar:**
- **Repository genérico:** `ICrudGenericoRepository<T, ID>` y `AbstractJpaRepository<T, ID>` traen `save`, `update`, `findById`, `findAll` y `deleteById` para todas las entidades.
- **Service genérico:** `ICrudGenericoService` y `CrudGenericoServiceImp`.
- **Inyección de dependencias:** `AppContext` registra repositorios, servicios y controladores. Al cargar un FXML, JavaFX le pide el controlador a `AppContext`, y este lo entrega con sus servicios ya puestos por constructor (`@RequiredArgsConstructor`).
- **Singleton:** `AppContext`, `SessionManager` y `DatabaseConfig`.

**SOLID:**
- **S (una responsabilidad):** por ejemplo, el PDF lo genera solo `ComprobantePdfService`.
- **O (abierto a extensión):** se agrega un tipo de robot nuevo creando otra subclase, sin tocar las demás.
- **L (sustitución):** donde se espera un `Robot`, sirve cualquiera de sus subclases.
- **I (interfaces pequeñas):** cada servicio tiene su propia interfaz.
- **D (depender de abstracciones):** los controladores dependen de interfaces como `IVentaService`, no de las clases concretas.

## 1.4 POO (1 min)

| Concepto | Dónde |
|---|---|
| Clase abstracta | `Robot` y `DocumentoComercial` |
| Herencia | `RobotIndustrial`, `RobotMovil` y `RobotEducativo` heredan de `Robot`; `Venta` e `Importacion` heredan de `DocumentoComercial` |
| Polimorfismo | `calcularProximoMantenimiento()`: un industrial con más de 500 kg de carga, a los 60 días (si no, a los 90); un móvil aéreo, a los 45 (si no, a los 120); un educativo, cada año. `calcularTotal()` también cambia entre venta e importación. |
| Interfaz | `Mantenible` |
| Encapsulamiento | atributos `private` con getters y setters de Lombok |
| Enumeraciones | `EstadoRobot`, `TipoRobot`, `TipoProducto`, `TipoDocumento` |

## 1.5 Base de datos y diagrama (1 min 30 s)

Muestra el diagrama en Power Architect y explícalo por colores. El detalle está en `EXPLICAR_DIAGRAMA.md`.

> "Son **20 tablas y 26 llaves foráneas**. Siguiendo la mejora del profesor, robots y repuestos están en una sola tabla **`producto`**, y la columna `tipo` dice qué es cada uno. Lo modelé en SQL Power Architect y generé las tablas con **Forward Engineer**.
> - **Morado:** seguridad.
> - **Naranja:** ventas, con la estructura cabecera–detalle y la tabla del carrito.
> - **Azul:** el catálogo; la herencia de robots se hace con relaciones 1 a 1.
> - **Verde:** reparaciones e importaciones."

**Conexión y transacciones:**
- `DatabaseConfig` lee `application.properties`, crea un **pool HikariCP** y, si las tablas no existen, ejecuta los scripts.
- Para cambiar de base de datos, solo se cambia la URL. Para MySQL usa automáticamente su propio script.
- En `AbstractJpaRepository.save`:

  ```java
  conn.setAutoCommit(false);
  insert(...);
  conn.commit();
  // si hay error:
  conn.rollback();
  ```

  Así, una operación que toca varias tablas o se guarda completa o no se guarda.
- Las excepciones de SQL se convierten en mensajes claros para el usuario.

## 1.6 Validaciones y mensajes

- En el **modelo**, con Jakarta Validation: `@NotBlank`, `@Pattern`, `@Positive`, `@PositiveOrZero`, `@PastOrPresent`.
- En el **servicio** van las reglas del negocio, por ejemplo: no vender sin stock, o que la factura exija RUC.
- En la **pantalla**:
  - El campo con error se marca en rojo.
  - Se muestra un **Toast**: verde si salió bien, rojo si hubo un error, azul cuando estás editando.
  - Al eliminar, el sistema pide confirmación.

---

# PARTE 2 · CRUD de ROBOTS (completo)

**Archivos:**
- Modelos: `Robot`, `RobotIndustrial`, `RobotMovil`, `RobotEducativo`.
- `RobotRepository`, `IRobotService` / `RobotServiceImp`.
- `RobotController` y `main_robot.fxml`.

**Demo:**

1. **Haz:** entra a **Catálogo → Robots**.
   > "Aquí se gestionan los robots. La tabla muestra el código, el tipo, el estado, el precio de venta y si necesita mantenimiento."
2. **Haz:** elige el tipo **MOVIL**.
   > "Al cambiar el tipo, aparecen solo los campos de ese tipo: un móvil pide locomoción y autonomía; un industrial, la capacidad de carga y el número de ejes; un educativo, la plataforma y el nivel."
3. **Haz:** deja el código vacío y escribe un precio negativo. Presiona Guardar.
   > "Las validaciones están en el modelo con Jakarta: el código solo admite mayúsculas, números y guiones (3 a 20 caracteres), el precio debe ser positivo y la fecha de adquisición no puede ser futura."
4. **Haz:** llena los datos bien (por ejemplo, `MOV-002`) y guarda.
   > "**Create:** `RobotRepository` guarda en una **transacción**: primero inserta en `producto` con tipo MOVIL, obtiene el id generado y luego inserta en `robot_movil`. Si falla la segunda inserción, se revierte la primera."
5. **Haz:** escribe en el filtro para buscar el robot. *(Read)*
6. **Haz:** presiona el lápiz, cambia el precio y guarda. *(Update)*
   > "Al editar, se borra la fila de la tabla del subtipo y se vuelve a insertar, por si cambió el tipo."
7. **Haz:** pon el estado VENDIDO sin elegir cliente.
   > "Regla de negocio en `RobotServiceImp`: un robot VENDIDO debe tener un cliente como dueño."
8. **Haz:** elimina el robot y confirma. *(Delete)*
   > "Se borra en una transacción: primero los componentes y la fila del subtipo, y luego el robot."

**Explica:**
- **Herencia y polimorfismo:**
  - `Robot` es abstracta, con métodos abstractos `getTipoRobot()`, `getDetalleTecnico()` y `calcularProximoMantenimiento()`.
  - Cada subclase los implementa a su manera.
  - `necesitaMantenimiento()` usa ese cálculo y también revisa si algún componente está desgastado.
- **Precio de venta:** `pu + pu × utilidad`, redondeado a 2 decimales.
- **En la BD:** el robot se guarda en `producto` (tipo INDUSTRIAL, MOVIL o EDUCATIVO) y sus datos propios en `robot_*`, que usa el mismo `id_producto` como llave primaria y foránea a la vez (relación 1 a 1 identificadora). `RobotRepository` solo lee los productos que son robots.

**Preguntas probables:**
- *¿Por qué `Robot` es abstracta?* Porque no existe un "robot genérico": siempre es de un tipo concreto.
- *¿Cómo sabe el repositorio en qué tabla insertar?* Según el tipo del objeto (`getTipoRobot()`), elige `robot_industrial`, `robot_movil` o `robot_educativo`.
- *¿Qué pasa si falla la inserción del subtipo?* Se hace `rollback` y no queda un robot sin su tipo.

---

# PARTE 3 · CRUD de REPUESTOS y CLIENTES (lo distinto)

> "Los otros CRUD funcionan igual que el de robots por dentro, así que solo muestro lo que cambia en cada uno."

## 3.1 Repuestos

**Archivos:**
- Modelos: `Repuesto` y `Marca`. Los repuestos se guardan en la tabla `producto`, con su código (REP-001…) y su tipo (MOTOR, BATERIA…).
- `RepuestoRepository`, `MarcaRepository`, `IRepuestoService` / `RepuestoServiceImp`.
- `RepuestoController` y `main_repuesto.fxml`.

**Demo:**

1. **Haz:** entra a **Catálogo → Repuestos**.
   > "Aquí se registran los repuestos que vendemos y que usamos en las reparaciones: motores, baterías, sensores."
2. **Haz:** guarda sin datos y luego con stock negativo.
   > "Validaciones: código obligatorio con formato REP-001, modelo y nombre obligatorios, precio positivo, utilidad y stock no negativos, vida útil positiva, y tipo y marca obligatorios."
3. **Haz:** registra uno nuevo, por ejemplo "Cámara 4K" de tipo SENSOR con stock 3. *(Create)*
4. **Haz:** búscalo con el filtro. *(Read)*
   > "Con stock 3 aparece en las alertas de **stock bajo** del inicio, porque el mínimo es 5 (`STOCK_MINIMO`)."
5. **Haz:** edítalo y súbele el stock. *(Update)*
6. **Haz:** intenta eliminar "Servomotor de eje". *(Delete)*
   > "No se puede eliminar porque está en uso en componentes o en ventas. La **llave foránea** lo impide, y el sistema muestra un mensaje claro en lugar de un error técnico."
7. **Haz:** elimina el repuesto que acabas de crear: ese sí se elimina.

**Aquí explica el CRUD genérico:**

```java
public class RepuestoServiceImp extends CrudGenericoServiceImp<Repuesto, Long>
```

> "No repito el CRUD en cada entidad. `AbstractJpaRepository<T, ID>` tiene `save`, `update`, `findAll`, `findById` y `deleteById`; cada repositorio solo implementa `insert`, `updateRow` y `mapRow`, que son el SQL propio de su tabla. Esto es **reutilización con genéricos y herencia**."

- **Stock:** se descuenta al vender o al reemplazar una pieza en un mantenimiento, siempre dentro de una transacción. Si no alcanza, se lanza una excepción y no se guarda nada.
- **Marca:** se carga en un ComboBox con `ComboBoxOption` (el id y el texto que se muestra).

**Preguntas probables:**
- *¿Qué es `mapRow`?* El método que convierte una fila del `ResultSet` en un objeto `Repuesto`.
- *¿Por qué usas `PreparedStatement`?* Para evitar inyección SQL y no armar el SQL concatenando texto.
- *¿Qué pasa si vendo más de lo que hay?* El servicio del carrito lo valida antes, y el repositorio lo vuelve a validar dentro de la transacción.

---

## 3.2 Clientes

**Archivos de clientes:** `Cliente`, `ClienteRepository`, `IClienteService` / `ClienteServiceImp`, `ClienteController`, `main_cliente.fxml`.

**Demo del CRUD de clientes (1 min):**

1. **Haz:** entra a **Ventas → Clientes**.
2. **Haz:** escribe un DNI de 7 dígitos y guarda.
   > "El DNI debe tener 8 dígitos y el RUC 11 (`@Pattern`). Además, en el servicio valido que coincida con el tipo de documento elegido. El celular debe tener de 6 a 12 dígitos."
3. **Haz:** registra un cliente nuevo. *(Create)*
4. **Haz:** intenta registrar el mismo DNI otra vez.
   > "No se permiten duplicados: el `dniruc` es la llave primaria."
5. **Haz:** búscalo con el filtro *(Read)* y edítalo *(Update)*.
   > "Al editar, el DNI queda bloqueado porque es la llave primaria."
6. **Haz:** intenta eliminar a "Lucía Ramos". *(Delete)*
   > "No se puede: tiene ventas registradas. La llave foránea protege el historial."

# PARTE 4 · REGISTRAR VENTA (el punto fuerte, 3 min)

**Archivos:** `VentCarrito`, `VentaRepository`, `VentaServiceImp`, `VentCarritoServiceImp`, `VentaController`, `main_venta.fxml`, `ConsultaDNI`, `ComprobantePdfService`, `MainComprobanteController`.

1. **Haz:** entra a **Ventas → Registrar venta**. Escribe "Luc" en el buscador de clientes.
   > "**Autocompletado**, igual que en el SysVentas de clase: busca por DNI o por nombre, incluso sin tildes."
2. **Haz:** escribe un DNI que no exista y presiona Buscar.
   > "Si el DNI no está registrado, lo consulto en **RENIEC** con **jsoup**: primero leo un token de la página y luego envío el DNI. Lo hago en un `Task` en segundo plano para no congelar la pantalla. Si no hay internet, el sistema deja escribir los datos a mano." *(Esto es investigación.)*
3. **Haz:** elige a Lucía. Busca "MOV" y agrega el robot; luego busca "Sensor", pon cantidad 3 y agrégalo.
   > "El carrito se guarda en la tabla **`vent_carrito`**. Validaciones: un robot va solo una vez y debe estar EN_STOCK; un repuesto no puede pasar del stock disponible; la cantidad debe ser mayor que 0."
4. Muestra los totales.
   > "El precio ya incluye IGV: base = total / 1.18 e IGV = total − base."
5. **Haz:** cambia a **FACTURA** con Lucía (que tiene DNI) y presiona Registrar.
   > "La factura exige un cliente con RUC." Vuelve a BOLETA y registra.
6. Se abre el comprobante.
   > "`registrarVenta` hace todo en **una transacción**: calcula el número correlativo (por ejemplo, B001-00000002), inserta la venta y sus detalles, marca el robot como VENDIDO y descuenta el stock del repuesto. Si otro vendedor vendió ese robot un segundo antes, el `UPDATE` no encuentra filas, se lanza una excepción y se hace **rollback**."
7. **Haz:** presiona **Exportar PDF** y abre el archivo.
   > "El PDF se genera con **OpenPDF**, con el mismo diseño que se ve en pantalla. El total va **en letras** gracias a la clase `NumeroLetras`. También se puede imprimir con `PrinterJob`."
8. **Haz:** entra a **Ventas → Historial** y presiona **Ver comprobante**.

**Preguntas probables:**
- *¿Por qué el carrito va en la BD?* Para no perderlo si se cierra la ventana, y para que quede ligado al cliente y al vendedor.
- *¿Cómo se genera el número?* `MAX(num_doc) + 1` por serie, rellenado con ceros hasta 8 dígitos.
- *¿Qué es un `Task`?* Una tarea de JavaFX que corre en otro hilo; al terminar, actualiza la pantalla en el hilo de JavaFX.

---

# PARTE 5 · REGISTRAR IMPORTACIÓN (opcional, 1 min)

Muéstralo si te sobra tiempo o si el profesor pregunta cómo entran los productos al almacén.

**Archivos:**
- `RegistroImportacion` (la pantalla) y `LineaImportacion` (cada línea del detalle).
- `OperacionRepository.registrarImportacion(...)` (la transacción).
- Modelos `Importacion` e `ImportacionDetalle`, que heredan el cálculo de `DocumentoComercial`.

**Demo:**

1. **Haz:** entra con **gerente / gerente123** y abre **Importaciones → Registrar importación**.
   > "Esta pantalla la usa el gerente de importaciones. Registra la factura del proveedor y lo que llegó."
2. **Haz:** elige el proveedor, escribe el número del documento (por ejemplo, `2026-0500`), un flete de 300 y aranceles de 450.
3. **Haz:** agrega el repuesto "Servomotor de eje" con costo 120 y cantidad 10. Luego agrega el robot IND-001 con costo 15 000.
   > "Un robot solo se puede agregar una vez, porque cada robot es único. Aparecen los robots registrados en el catálogo que todavía no tienen importación."
4. Muestra los totales.
   > "Aquí el IGV se calcula distinto que en la venta: (base + flete + aranceles) × 18 %. Es el mismo método `calcularTotal()` heredado de `DocumentoComercial`, pero `Importacion` lo sobrescribe: eso es **polimorfismo**."
5. **Haz:** presiona **Registrar importación**.
   > "Se guarda en **una transacción**: la cabecera en `importacion`, cada producto en `importacion_detalle`, y se **suma el stock**. Si algo falla, se hace rollback."
6. **Haz:** abre **Importaciones → Historial de importaciones** y elige la fila para ver su detalle. Luego abre **Catálogo → Repuestos**: el servomotor pasó de 4 a 14.

**Validaciones:**
- Proveedor obligatorio, y serie y número con formato válido.
- Precio mayor que 0, y cantidad entera mayor que 0.
- Flete y aranceles no negativos, y fecha que no sea futura.
- Debe haber al menos un producto.
- No se puede registrar dos veces el mismo documento del mismo proveedor.

**Preguntas probables:**
- *¿Por qué la importación suma stock y la venta lo resta?* Porque la importación es la entrada de mercadería al almacén y la venta es la salida.
- *¿Por qué no hay número correlativo, como en la venta?* Porque el número es el de la factura del proveedor; por eso valido que no se repita.

---

# CIERRE (30 s)

> "En resumen, DzRobot aplica:
> - Arquitectura en capas con repositorio y servicio genéricos.
> - Inyección de dependencias.
> - POO: herencia, polimorfismo, interfaces y encapsulamiento.
> - Una base de datos modelada en Power Architect, con transacciones.
> - Interfaz JavaFX con validaciones y mensajes.
>
> Como investigación implementé el cifrado PBKDF2, la consulta de DNI en RENIEC, el comprobante en PDF y el número a letras. Tomé como base el SysVentas visto en clase y lo adapté al negocio de robots. Muchas gracias. Quedo atento a sus preguntas."

---

## Preguntas generales que debes poder responder

| Pregunta | Respuesta |
|---|---|
| ¿Qué es un CRUD? | Create, Read, Update, Delete: crear, listar, editar y eliminar. |
| ¿Qué hace `AppContext`? | Es el contenedor de dependencias: crea cada objeto una sola vez y los entrega ya conectados. |
| ¿Qué es FXML? | Un XML que describe la pantalla. El controlador se conecta a él con `@FXML`. |
| ¿Qué hace Lombok? | Genera getters, setters y constructores con anotaciones (`@Data`, `@RequiredArgsConstructor`). |
| ¿Qué es una transacción? | Un grupo de operaciones que se guardan todas juntas (`commit`) o ninguna (`rollback`). |
| ¿Qué es HikariCP? | Un pool que reutiliza conexiones abiertas para no abrir una nueva en cada consulta. |
| ¿Por qué `PreparedStatement`? | Evita la inyección SQL y maneja bien los tipos de datos. |
| ¿Qué es la sal en PBKDF2? | Un valor aleatorio por usuario, para que dos claves iguales den hashes distintos. |
| ¿Cómo se cambia a MySQL? | Se cambia la URL en `application.properties` y el sistema crea las tablas solo. |
| ¿Qué pruebas tiene? | 19 pruebas JUnit; se ejecutan con `mvn test`. |
| ¿Por qué robots y repuestos están en una sola tabla? | Porque los dos son **productos** que se venden e importan. Así el detalle de venta, el carrito y la importación tienen una sola llave (`id_producto`), y la columna `tipo` los distingue. |

---

# ANEXO A · Conceptos fundamentales de POO (con ejemplos de DzRobot)

Para cada concepto: qué es, en una frase, y dónde está en el sistema. Si el profesor pregunta "¿dónde aplicas X?", abre la clase indicada.

## A.1 Los 4 pilares

| Pilar | Qué es | Dónde está en DzRobot |
|---|---|---|
| **Abstracción** | Quedarse solo con lo importante de un objeto real y ocultar los detalles. | `Robot` guarda lo que le importa al negocio (código, precio, estado, marca), no todo lo que tiene un robot real. `Robot` y `DocumentoComercial` son **clases abstractas**. |
| **Encapsulamiento** | Atributos `private`; solo se accede a ellos por métodos públicos (getters y setters). | Todos los modelos: `private Double pu;` y Lombok `@Data` genera `getPu()` y `setPu()`. Las validaciones (`@Positive`) protegen el estado del objeto. |
| **Herencia** | Una clase hija reutiliza atributos y métodos de una clase padre (`extends`). | `RobotIndustrial extends Robot`, `Venta extends DocumentoComercial`, `RobotServiceImp extends CrudGenericoServiceImp<Robot, Long>`. |
| **Polimorfismo** | Un mismo método se comporta distinto según el objeto que lo ejecuta. | `calcularProximoMantenimiento()` da otra fecha en industrial, móvil y educativo; `calcularTotal()` cambia entre `Venta` e `Importacion`. |

> "Uso polimorfismo cuando recorro una `List<Robot>` y llamo a `necesitaMantenimiento()`: no me importa si es industrial o móvil, cada uno responde a su manera."

## A.2 Clase, objeto y sus partes

| Concepto | Qué es | Ejemplo |
|---|---|---|
| **Clase** | El molde que describe atributos y métodos. | `Cliente`, `Repuesto`, `Venta` |
| **Objeto (instancia)** | Un ejemplar concreto creado desde la clase. | `Cliente.builder().dniruc("45678912")...build()` crea a Lucía |
| **Atributo** | Un dato del objeto. | `codigo`, `stock`, `precioTotal` |
| **Método** | Una acción que el objeto sabe hacer. | `getPrecioVenta()`, `calcularTotal()` |
| **Constructor** | El método que crea el objeto. | Lombok genera `@NoArgsConstructor`, `@AllArgsConstructor` y `@RequiredArgsConstructor` (en los controladores recibe los servicios). |
| **Patrón Builder** | Crear objetos paso a paso, con nombres claros. | `Repuesto.builder().codigo("REP-001").nombre("Servomotor")...build()` (`@Builder`, `@SuperBuilder` en la herencia de `Robot`) |

## A.3 Clase abstracta vs. interfaz

| | Clase abstracta | Interfaz |
|---|---|---|
| Palabra clave | `abstract class` / `extends` | `interface` / `implements` |
| ¿Tiene atributos? | Sí (`codigo`, `pu`…) | No (solo constantes) |
| ¿Tiene métodos con código? | Sí, y también métodos abstractos | Solo firmas (o métodos `default`) |
| ¿Cuántas puedo heredar? | Solo una | Varias |
| En DzRobot | `Robot`, `DocumentoComercial` | `Mantenible`, `IRobotService`, `ICrudGenericoRepository<T, ID>` |

**Interfaz `Mantenible`** (es un "contrato"):

```java
public interface Mantenible {
    LocalDate calcularProximoMantenimiento();
    boolean necesitaMantenimiento();
}
```

> "La implementan clases que no son parientes: `Robot` y `Componente`. Las dos 'se pueden mantener', pero un componente no es un robot. Por eso uso una interfaz y no herencia."

**Interfaces de servicio:** `IRobotService`, `IVentaService`… El controlador depende de la interfaz, no de la clase concreta (principio **D** de SOLID). Si cambio la implementación, el controlador no se entera.

## A.4 Sobrescritura y sobrecarga

- **Sobrescritura (`@Override`):** la hija redefine un método del padre o de la interfaz. Por ejemplo, `RobotMovil` sobrescribe `calcularProximoMantenimiento()`, y `ComboBoxOption` sobrescribe `toString()` para mostrar el texto en el combo.
- **Sobrecarga:** el mismo nombre de método con distintos parámetros. Por ejemplo, `ComprobantePdfService.exportar(Comprobante, Path)` y `exportar(Comprobante, OutputStream)`.

## A.5 Relaciones entre clases

| Relación | Qué es | Ejemplo |
|---|---|---|
| **Asociación** | Una clase usa a otra como atributo. | `Robot` tiene una `Marca` (`idMarca`) y un `Cliente` dueño (`dniruc`). |
| **Composición** | El "todo" no tiene sentido sin sus partes, y estas nacen y mueren con él. | `Venta` tiene una `List<VentaDetalle>`: los detalles no existen sin la venta. |
| **Agregación** | El todo tiene partes que pueden existir solas. | `Robot` tiene una `List<Componente>`: un repuesto existe aunque se retire del robot. |
| **Dependencia** | Una clase usa a otra temporalmente. | `VentaController` usa `IVentaService` para registrar la venta. |

## A.6 Otros conceptos que te pueden preguntar

| Concepto | Ejemplo en DzRobot |
|---|---|
| **Modificadores de acceso** | `private` en atributos, `public` en métodos de servicio, `protected` en `getFechaBase()` de `Robot` (solo lo usan las hijas). |
| **`static`** | Métodos que no necesitan un objeto: `NumeroLetras.soles(...)`, `Tema.aplicar(...)`, `PasswordUtil.hashear(...)`. |
| **`final` / constantes** | `STOCK_MINIMO = 5` en `RepuestoServiceImp`; `TASA_IGV` en el documento comercial. |
| **Enumeraciones (`enum`)** | Valores fijos: `EstadoRobot` (EN_STOCK, VENDIDO…), `TipoRepuesto`, `TipoProducto`. |
| **Genéricos (`<T>`)** | `AbstractJpaRepository<T, ID>`, `CrudGenericoServiceImp<T, ID>`, `AutoCompleteTextField<T>`: una sola clase sirve para muchos tipos. |
| **Excepciones** | `IllegalStateException` cuando no hay stock; excepción propia `ModelNotFoundException extends RuntimeException`; `try / catch` en los controladores para mostrar el Toast rojo. |
| **Colecciones** | `List`, `Map` (`LinkedHashMap` de columnas), `Optional` en `findById`, y `stream()` para filtrar y sumar. |
| **Singleton** | `AppContext.getInstance()` y `SessionManager.getInstance()`: una sola instancia en toda la aplicación (el usuario que inició sesión). |

---

# ANEXO B · Conceptos de interfaz gráfica (JavaFX)

Esta parte cubre el criterio "Diseño de interfaz" de la rúbrica.

## B.1 Estructura de una ventana JavaFX

```
Stage  (la ventana)
 └── Scene  (el contenido)
      └── Nodo raíz (un contenedor, por ejemplo BorderPane)
           └── más contenedores y controles  →  "grafo de escena"
```

- **Stage:** la ventana. La principal la crea JavaFX; el comprobante abre un **Stage modal** propio (`Modality.APPLICATION_MODAL`, con `initOwner`), que bloquea la ventana de atrás hasta cerrarlo.
- **Scene:** lo que va dentro de la ventana; ahí se aplica la hoja de estilos con `Tema.aplicar(scene)`.
- **Nodo (`Node`):** cualquier elemento visual. Todo es un nodo: botones, tablas, contenedores.

## B.2 Contenedores (layouts) que uso

| Contenedor | Cómo acomoda | Dónde |
|---|---|---|
| `BorderPane` | arriba, abajo, izquierda, derecha y centro | ventana principal: menú arriba, pestañas al centro, barra de estado abajo |
| `TabPane` | pestañas | cada módulo se abre en una pestaña |
| `VBox` / `HBox` | en columna / en fila | paneles de la venta y fila de botones |
| `GridPane` | filas y columnas, como una tabla | formularios de robot, repuesto, cliente y venta |
| `AnchorPane` | pegado a los bordes | contenedor de cada pantalla FXML |
| `StackPane` | uno encima de otro | login, y para mostrar el Toast encima del contenido |
| `ScrollPane` | con barras de desplazamiento | visor del comprobante |

## B.3 Controles

| Control | Uso en DzRobot |
|---|---|
| `MenuBar` → `Menu` → `MenuItem` | Menú principal (Catálogo, Ventas, Reparaciones…), armado según el perfil. |
| `TextField` / `PasswordField` | Campos de texto y la clave en el login. |
| `ComboBox` | Tipo de robot, marca, comprobante (BOLETA o FACTURA). |
| `DatePicker` | Fecha de adquisición y fecha de la venta (formato dd/MM/yyyy). |
| `TableView` + `TableColumn` | Listados con columnas de acción (editar, eliminar) y "píldoras" de color. |
| `Button` | Guardar, Cancelar, Agregar, Registrar venta. |
| `Label` | Títulos, totales y mensajes. |
| `Alert` | Confirmación antes de eliminar ("¿Eliminar…?"). |
| `ContextMenu` | La lista de sugerencias del autocompletado. |
| Componentes propios | `AutoCompleteTextField`, `Toast`, `TableViewHelper`, `ComprobanteView`. |

## B.4 FXML y controlador (patrón MVC)

- **Vista:** el archivo `.fxml` (por ejemplo, `main_venta.fxml`) describe la pantalla en XML.
- **Controlador:** la clase Java (`VentaController`) atiende los eventos.
- **Modelo:** las clases del paquete `model` y los servicios.
- Se conectan con `fx:id="txtNombre"` en el FXML y `@FXML TextField txtNombre;` en el controlador; y con `onAction="#registrarVenta"`, que llama al método `registrarVenta()`.
- `initialize()` se ejecuta al cargar la pantalla: ahí lleno los combos y configuro la tabla.
- El controlador lo crea `AppContext`, con `fxmlLoader.setControllerFactory(...)`.

## B.5 Eventos, propiedades y listas observables

- **Evento:** algo que hace el usuario (clic, escribir). Se maneja con `setOnAction(e -> ...)` o con `onAction` en el FXML.
- **Listener:** reacciona a cambios. Por ejemplo, al escribir la cantidad se recalcula el total: `cantidadPro.textProperty().addListener(...)`. Lo mismo hace el filtro de búsqueda.
- **`ObservableList`:** la lista de la `TableView`. Si cambia la lista, la tabla se actualiza sola.

## B.6 Hilos en JavaFX

- La pantalla corre en un solo hilo, el **JavaFX Application Thread**. Si hago algo lento ahí, la ventana se congela.
- Por eso la consulta a RENIEC y la exportación del PDF usan un **`Task`** en otro hilo. Al terminar, `setOnSucceeded` actualiza la pantalla.
- `Platform.runLater(...)` pide a JavaFX que ejecute algo en su hilo cuando pueda.

## B.7 Estilos (CSS) y experiencia de usuario

- Una sola hoja de estilos, `dzrobot.css`. Los nodos usan `styleClass` (por ejemplo `panel`, `toast-ok`) y JavaFX aplica propiedades `-fx-…` (`-fx-background-color`, `-fx-text-fill`).
- **Validación visual:**
  - El campo con error se marca en rojo y muestra un tooltip con el mensaje.
  - El Toast es verde si salió bien, rojo si hubo un error y azul si estás editando.
  - Los botones se desactivan cuando la acción no es posible (por ejemplo, "Registrar venta" con el carrito vacío).
- **Navegación:**
  - El menú cambia según el perfil.
  - Las pestañas permiten tener varios módulos abiertos.
  - Las tarjetas del inicio llevan al módulo correspondiente.
- **Consistencia:** todas las pantallas CRUD tienen la misma distribución, con el formulario a la izquierda y la tabla a la derecha.

**Preguntas probables de interfaz:**
- *¿Qué diferencia hay entre Stage y Scene?* El Stage es la ventana; la Scene es el contenido que va dentro.
- *¿Para qué sirve `@FXML`?* Para enlazar un campo o método del controlador con un elemento del FXML.
- *¿Por qué usas `Task`?* Para no congelar la pantalla en operaciones lentas, como la consulta a internet o la creación del PDF.
- *¿Qué es un contenedor?* Un nodo que organiza a otros nodos (VBox, GridPane…), mientras que un control es algo con lo que el usuario interactúa (Button, TextField…).
