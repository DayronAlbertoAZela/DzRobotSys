# DzRobot 2.0 · Evaluación Unidad 2

Sistema de escritorio para una empresa que **importa, vende y repara robots**. Hecho en Java 21 con JavaFX, arquitectura por capas (Repository, Service, Controller) y base de datos relacional modelada en SQL Power Architect.

## 1. Caso de estudio

La empresa **Robotec Import S.A.C.** trae robots y repuestos del extranjero (China, Alemania), los vende a personas y empresas, y luego les da mantenimiento. Hasta ahora todo se llevaba en hojas de cálculo: no se sabía qué robot estaba vendido, cuántos repuestos quedaban ni cuándo le tocaba mantenimiento a cada equipo.

DzRobot centraliza esa información. Cada usuario entra con su perfil y solo ve lo que le corresponde:

| Perfil | Usuario de prueba | Puede usar |
|---|---|---|
| Administrador | admin / admin123 | Todo el sistema |
| Vendedor | vendedor / vendedor123 | Robots, clientes, registrar venta, historial de ventas |
| Gestor de reparaciones | gestor / gestor123 | Robots, repuestos, mantenimientos, fallas, técnicos |
| Gerente de importaciones | gerente / gerente123 | Robots, repuestos, proveedores, importaciones |

## 2. Lista de requerimientos

### Requerimientos funcionales

| Código | Requerimiento | Dónde está |
|---|---|---|
| RF01 | Iniciar sesión con usuario y clave; la clave se guarda cifrada (PBKDF2). | `LoginController`, `PasswordUtil` |
| RF02 | Mostrar un menú distinto según el perfil del usuario. | `MenuMenuItemDaoImp` |
| RF03 | Panel de inicio con indicadores: robots en stock, vendidos, ventas del mes, stock bajo y alertas de mantenimiento. | `MainGuiController` |
| RF04 | CRUD de robots (industrial, móvil, educativo) con sus datos técnicos. | `RobotController` |
| RF05 | CRUD de repuestos con stock y vida útil. | `RepuestoController` |
| RF06 | CRUD de clientes (DNI o RUC). | `ClienteController` |
| RF07 | Registrar una venta con carrito: buscar cliente, buscar producto, agregar, quitar y ver totales con IGV. | `VentaController`, `main_venta.fxml` |
| RF08 | Autocompletar clientes y productos mientras se escribe (sin importar tildes). | `AutoCompleteTextField` |
| RF09 | Consultar un DNI nuevo en RENIEC (eldni.com) y llenar el nombre automáticamente. | `ConsultaDNI` |
| RF10 | Emitir boleta (B001) o factura (F001) con numeración correlativa. La factura exige cliente con RUC. | `VentaServiceImp` |
| RF11 | Al vender: el robot pasa a VENDIDO y el stock del repuesto se descuenta, todo en una sola transacción. | `VentaRepository.insert` |
| RF12 | Ver el comprobante en pantalla, imprimirlo y exportarlo a PDF, con el total en letras. | `MainComprobanteController`, `ComprobanteView`, `ComprobantePdfService`, `NumeroLetras` |
| RF13 | Historial de ventas con detalle y botón "Ver comprobante". | `Modulos.ventas()` |
| RF14 | Registrar mantenimientos; al finalizar, se reemplazan componentes, se descuenta stock y se resuelven las fallas. | `RegistroMantenimiento`, `OperacionRepository` |
| RF15 | Reportar fallas de un robot con su gravedad. | `ReporteFallas` |
| RF16 | Historial de mantenimientos, técnicos, proveedores, importaciones y usuarios. | `Modulos` |

### Requerimientos no funcionales

| Código | Requerimiento |
|---|---|
| RNF01 | Arquitectura por capas: modelo, repositorio, servicio, controlador y vista (FXML). |
| RNF02 | Base de datos relacional: H2 embebida por defecto; MySQL o PostgreSQL cambiando `application.properties`. |
| RNF03 | Conexiones con pool HikariCP y transacciones (commit / rollback) en las operaciones de varias tablas. |
| RNF04 | Validación de campos con Jakarta Validation y mensajes al usuario (Toast verde o rojo). |
| RNF05 | Claves de usuario nunca en texto plano. |
| RNF06 | Interfaz JavaFX con tema oscuro tipo vidrio, una sola hoja de estilos (`dzrobot.css`). |
| RNF07 | Pruebas automáticas con JUnit 5 (19 pruebas). |

## 3. Cómo cumple cada punto de la rúbrica

### Funcionalidad de la app (4 pts)
- Flujo completo de venta: cliente, carrito, comprobante, PDF. Se prueba en vivo en menos de un minuto.
- Además: robots, repuestos, clientes, mantenimientos, fallas, importaciones y usuarios.

### Almacenamiento en BD y modelo en Power Architect (3 pts)
- 20 tablas con 26 llaves foráneas. Robots y repuestos van en una sola tabla `producto` (mejora propuesta por el profesor). El modelo está en `docs/modelo/DzRobot.architect`.
- Los scripts generados están en `docs/modelo/`: `dzrobot_postgresql.sql` y `dzrobot_mysql.sql`. Ambos se probaron creando las 20 tablas y las 26 FK, con los datos de prueba, en PostgreSQL 16 y en MariaDB 10.11.
- La tabla nueva `vent_carrito` guarda el carrito en la base de datos, igual que en SysVentas.

### Patrones, arquitectura y POO (3 pts)
- **Capas:** `model` → `repository` → `service` → `controller` → `view`.
- **Repository genérico:** `ICrudGenericoRepository<T, ID>` y `AbstractJpaRepository<T, ID>` dan el CRUD a todas las entidades.
- **Service genérico:** `ICrudGenericoService` y `CrudGenericoServiceImp`.
- **Inyección de dependencias:** `AppContext` crea los objetos una sola vez y los entrega a los controladores por constructor (`@RequiredArgsConstructor`).
- **Singleton:** `AppContext`, `SessionManager` y `DatabaseConfig`.
- **Herencia y polimorfismo:** `Robot` es abstracta; `RobotIndustrial`, `RobotMovil` y `RobotEducativo` calculan distinto su próximo mantenimiento. `DocumentoComercial` es abstracta; `Venta` e `Importacion` calculan distinto su total.
- **Interfaz:** `Mantenible`.
- **Encapsulamiento:** atributos privados con Lombok.
- **Enums:** `EstadoRobot`, `TipoProducto`, `TipoDocumento` y otros.
- **SOLID:**
  - Una responsabilidad por clase (por ejemplo, el PDF lo hace solo `ComprobantePdfService`).
  - Los controladores dependen de interfaces (`IVentaService`), no de implementaciones.

### Diseño de interfaz y validaciones (3 pts)
- JavaFX con FXML, MenuBar, TabPane, TableView, GridPane, DatePicker, ComboBox, ventanas modales y autocompletado.
- Validaciones con mensaje:
  - DNI de 8 dígitos o RUC de 11.
  - Cantidad mayor que 0.
  - No vender más del stock.
  - Un robot vendido no entra al carrito.
  - La factura exige RUC.
  - No se aceptan fechas futuras.
  - No se registra una venta con el carrito vacío.
- Los mensajes se muestran en un Toast verde (éxito) o rojo (error).

### Investigación implementada (2 pts)
1. **Cifrado de contraseñas con PBKDF2:** HMAC-SHA256, 65 536 iteraciones y sal aleatoria por usuario. Se guarda como `iteraciones:sal:hash`.
2. **Consulta de DNI en RENIEC con jsoup:**
   - Lee el token de la página y luego envía el DNI.
   - Corre en un hilo aparte (`Task`) para no congelar la pantalla.
   - Si no hay internet, deja escribir los datos a mano.
3. **Comprobante en PDF con OpenPDF:** el mismo diseño que se ve en pantalla, exportado sin congelar la interfaz.
4. **Impresión con `PrinterJob`** de JavaFX.
5. **Número a letras:** `NumeroLetras` convierte, por ejemplo, 19 676.40 en "DIECINUEVE MIL SEISCIENTOS SETENTA Y SEIS CON 40/100 SOLES".
6. **Pool de conexiones HikariCP.**

## 4. Preguntas probables del profesor

**¿Por qué separar en Repository, Service y Controller?**
Cada capa tiene un solo trabajo:
- El repositorio solo habla con la base de datos.
- El servicio aplica las reglas del negocio (no vender sin stock, la factura con RUC).
- El controlador solo atiende la pantalla.

Si mañana cambio H2 por MySQL, solo toco el repositorio y la configuración.

**¿Dónde usas transacciones?**
En `VentaRepository.insert`:
1. Pongo `setAutoCommit(false)`.
2. Inserto la venta y sus detalles.
3. Marco el robot como VENDIDO y descuento el stock del repuesto.

Si algo falla (por ejemplo, alguien vendió ese robot un segundo antes), hago `rollback` y no queda nada a medias. Lo mismo pasa al registrar un mantenimiento.

**¿Qué pasa si dos vendedores venden el mismo robot?**
El `UPDATE` solo cambia el robot si sigue `EN_STOCK`. Si actualiza 0 filas, lanzo una excepción y la transacción se revierte.

**¿Por qué el carrito se guarda en la base y no en una lista?**
Así no se pierde si se cierra la ventana, y cada carrito queda ligado al cliente y al vendedor (`vent_carrito`). Es el mismo enfoque del SysVentas de clase.

**¿Cómo calculas el IGV?**
El precio de venta ya incluye IGV. Entonces:
- Base = total / 1.18
- IGV = total − base

Ambos se redondean a 2 decimales.

**¿Cómo se guarda la contraseña?**
Con PBKDF2 y una sal distinta por usuario. Al iniciar sesión, vuelvo a calcular el hash con la misma sal y comparo. Nunca se guarda ni se compara la clave en texto plano.

**¿Qué es la inyección de dependencias en tu proyecto?**
`AppContext` registra todos los repositorios, servicios y controladores. Cuando JavaFX carga un FXML, le pide el controlador a `AppContext`, y este se lo entrega ya con sus servicios dentro (por constructor).

**¿Dónde está el polimorfismo?**
`robot.calcularProximoMantenimiento()` da otra fecha según el tipo: un industrial con más de 500 kg de carga vuelve a los 60 días (si no, a los 90), y un móvil aéreo a los 45 días (si no, a los 120). `documento.calcularTotal()` cambia entre venta e importación.

**¿Cómo funciona la consulta de DNI?**
Con jsoup:
1. Abro eldni.com y leo el `_token` del formulario.
2. Envío el DNI con ese token.
3. Leo la tabla de resultados.

Corre en un `Task` en segundo plano. Si falla, el sistema no se cae: avisa y deja escribir el nombre a mano.

**¿Cómo generaste las tablas desde Power Architect?**
Con *Tools → Forward Engineer*, elegí PostgreSQL o MySQL y ejecuté el script. Los archivos generados están en `docs/modelo/`.

**¿Qué validaciones tiene la venta?**
- Que exista el cliente.
- Cantidad mayor que 0.
- No pasar el stock.
- Que el robot no esté vendido ni repetido en el carrito.
- Factura solo con RUC.
- Fecha no futura.
- Carrito no vacío.

**¿Qué pruebas tienes?**
19 pruebas JUnit (`mvn test`). Por ejemplo, `VentaTest` comprueba que:
- La venta descuenta el stock y vacía el carrito.
- El PDF se genera.
- La factura sin RUC se rechaza.

## 5. Modelo en SQL Power Architect

1. Abre SQL Power Architect y ve a **File → Open Project**.
2. Elige `docs/modelo/DzRobot.architect`.
3. En el área de trabajo verás las 20 tablas con sus relaciones, con `producto` al centro. Las tablas de ventas aparecen en naranja.
4. Para generar las tablas, ve a **Tools → Forward Engineer**, elige PostgreSQL o MySQL y ejecuta.

Si tu versión de Power Architect no abre el archivo, puedes hacerlo al revés:
1. Crea la base con `dzrobot_postgresql.sql` o `dzrobot_mysql.sql`.
2. En Power Architect, ve a **Connections → Add Source Connection**.
3. Arrastra las tablas al área de trabajo.
4. Guarda el proyecto.

## 6. GitHub

1. Crea el repositorio, por ejemplo `DzRobot`, y sube la carpeta del proyecto. No subas `target/` ni `data/`.
2. Si el repositorio es privado, agrega al profesor como colaborador: **Settings → Collaborators → dmamanipar**.
3. No subas contraseñas reales en `application.properties`. Deja los valores de ejemplo `TU_USUARIO` y `TU_CLAVE`.

## 7. Cómo ejecutar

```
mvn clean javafx:run
```

Por defecto usa H2 y crea la base sola en `./data`. Para MySQL o PostgreSQL:
1. Descomenta las líneas correspondientes en `src/main/resources/application.properties`.
2. Crea la base vacía.
3. Al iniciar, el sistema crea las tablas y carga los datos de prueba.
