# 1 · ¿Qué es DzRobot?

**DzRobot** es el sistema de la empresa **Robotec Import**, que **importa, vende y repara robots** y repuestos. Con DzRobot puedes:

- Llevar el **catálogo** de robots (industriales, móviles y educativos) y de repuestos.
- **Vender** robots y repuestos, y emitir la **boleta o factura** en PDF.
- Registrar **fallas y mantenimientos** de los robots.
- Registrar las **importaciones** que llegan de los proveedores y actualizar el stock.

## 1.1 Perfiles de usuario

Cada persona entra con su usuario, y **el menú cambia según su perfil**. Así cada uno ve solo lo que necesita para su trabajo.

| Perfil | Usuario de prueba | Contraseña | ¿Qué hace? |
|---|---|---|---|
| **Administrador** | `admin` | `admin123` | Todo el sistema, y además administra los usuarios. |
| **Vendedor** | `vendedor` | `vendedor123` | Atiende a los clientes y registra las ventas. |
| **Gestor de reparaciones** | `gestor` | `gestor123` | Reporta fallas, registra mantenimientos y gestiona a los técnicos. |
| **Gerente de importaciones** | `gerente` | `gerente123` | Gestiona a los proveedores y registra las importaciones. |

## 1.2 ¿Qué ve cada perfil en el menú?

| Opción del menú | Admin | Vendedor | Gestor | Gerente |
|---|:-:|:-:|:-:|:-:|
| Catálogo → Robots | ✔ | ✔ | ✔ | ✔ |
| Catálogo → Repuestos | ✔ | | ✔ | ✔ |
| Ventas → Clientes | ✔ | ✔ | | |
| Ventas → Registrar venta | ✔ | ✔ | | |
| Ventas → Historial de ventas | ✔ | ✔ | | |
| Reparaciones → Registrar mantenimiento | ✔ | | ✔ | |
| Reparaciones → Historial de mantenimientos | ✔ | | ✔ | |
| Reparaciones → Reportar fallas | ✔ | | ✔ | |
| Reparaciones → Técnicos | ✔ | | ✔ | |
| Importaciones → Proveedores | ✔ | | | ✔ |
| Importaciones → Registrar importación | ✔ | | | ✔ |
| Importaciones → Historial de importaciones | ✔ | | | ✔ |
| Administración → Usuarios | ✔ | | | |

::: tip
**Cómo usar este manual:** lee primero las secciones 2 y 3, que sirven para todos. Luego ve directo a la sección de **tu perfil**.
:::

# 2 · Instalación en Windows

## 2.1 Requisitos

- Windows 10 u 11 de **64 bits**.
- Unos 200 MB libres en el disco.
- **No necesitas instalar Java**: ya viene incluido en el instalador.
- Internet solo para buscar DNI en RENIEC; todo lo demás funciona sin internet.

## 2.2 Pasos para instalar

1. Haz doble clic en **`DzRobot-2.0-Instalador-Windows.exe`**.
2. Si Windows pregunta *"¿Quieres permitir que esta aplicación haga cambios?"*, presiona **Sí**.
3. Si aparece **"Windows protegió tu PC"**, presiona **Más información → Ejecutar de todas formas**. Sale porque el instalador no tiene firma digital comercial; es normal en programas de estudiantes.
4. En la bienvenida, presiona **Siguiente**.
5. Elige la carpeta de instalación (por defecto `C:\Archivos de programa\DzRobot`) y presiona **Instalar**.
6. Al terminar, deja marcado **"Abrir DzRobot ahora"** y presiona **Terminar**.

El instalador crea un acceso directo **DzRobot** en el **Escritorio** y en el **menú Inicio**.

## 2.3 ¿Dónde se guardan los datos?

La base de datos se crea sola la primera vez que abres el programa, con datos de ejemplo, en:

```
C:\Users\<tu usuario>\DzRobot\data
```

Si quieres **empezar de cero**, cierra DzRobot y borra esa carpeta. La próxima vez se crea de nuevo.

## 2.4 Versión portable (sin instalar)

Dentro de la carpeta del programa está **`DzRobot.bat`**. Si copias la carpeta completa a una USB, puedes abrir DzRobot con doble clic en ese archivo, sin instalar nada.

## 2.5 Desinstalar

Ve a **Configuración → Aplicaciones → DzRobot 2.0 → Desinstalar**, o usa **Desinstalar DzRobot** en el menú Inicio. Tus datos en `C:\Users\<tu usuario>\DzRobot` no se borran; elimínalos a mano si ya no los necesitas.

# 3 · Primeros pasos (todos los perfiles)

## 3.1 Iniciar sesión

![Pantalla de inicio de sesión](img/login.png){width=38%} ![Usuario o clave incorrectos](img/login_error.png){width=38%}

1. Abre **DzRobot** desde el Escritorio.
2. Escribe tu **Usuario** y tu **Clave**.
3. Presiona **Ingresar** (o la tecla Enter).

Si te equivocas, aparece en rojo **"Usuario o clave incorrectos"**. Revisa que no tengas activadas las mayúsculas. Las contraseñas se guardan cifradas, así que nadie puede leerlas en la base de datos.

## 3.2 La pantalla principal

![Panel de inicio](img/inicio.png)

| Parte | Para qué sirve |
|---|---|
| **Menú** (arriba) | Abre los módulos. Solo muestra los de tu perfil. |
| **Pestañas** | Cada módulo se abre en su propia pestaña, y puedes tener varios abiertos a la vez. |
| **Tarjetas** | Robots en stock, robots vendidos, robots que necesitan mantenimiento, ventas del mes y repuestos con stock bajo. **Haz clic en una tarjeta** para ir a ese módulo. |
| **Gráfico** | Ventas (naranja) e importaciones (celeste) de los últimos 6 meses, en soles. |
| **Alertas de hoy** | Robots a los que les toca mantenimiento y repuestos con 5 unidades o menos. |
| **Barra inferior** | Tu usuario y tu perfil. |

Para volver a este panel, usa **Sistema → Inicio**.

## 3.3 Mensajes del sistema

DzRobot siempre te avisa qué pasó:

- **Mensaje verde:** la operación salió bien, por ejemplo "Robot guardado".
- **Mensaje rojo:** hubo un problema, y el mensaje explica por qué, por ejemplo "Stock insuficiente: quedan 3".
- **Campo en rojo:** ese dato está mal. **Pasa el mouse encima** para ver qué se espera.
- **Ventana de confirmación:** antes de eliminar algo, el sistema pregunta "¿Eliminar…?". Presiona **Aceptar** para borrar o **Cancelar** para no hacer nada.

## 3.4 Cómo funcionan las pantallas de registro

Las pantallas de **Robots, Repuestos, Clientes, Técnicos y Proveedores** funcionan igual:

| Quiero… | Qué hago |
|---|---|
| **Registrar** uno nuevo | Lleno el formulario de la izquierda y presiono **Guardar**. |
| **Buscar** | Escribo en **Filtrar**, arriba a la derecha. La tabla se filtra mientras escribo. |
| **Editar** | Presiono el **lápiz** ✏️ de la fila, cambio los datos y presiono **Guardar**. |
| **Eliminar** | Presiono el **tacho** 🗑️ de la fila y confirmo. |
| **Cancelar** una edición | Presiono **Cancelar**, y el formulario se limpia. |

::: tip
Si un registro ya se usó, por ejemplo un cliente con ventas o un repuesto vendido, **el sistema no deja eliminarlo** y muestra un mensaje. Así se protege el historial.
:::

## 3.5 Cerrar sesión

Usa **Sistema → Cerrar sesión**. Vuelves a la pantalla de ingreso y otra persona puede entrar con su usuario.

# 4 · Catálogo (todos los perfiles)

## 4.1 Robots

**Menú:** Catálogo → Robots

![Gestión de robots](img/robots.png)

**Para registrar un robot:**

1. Elige el **Tipo de robot**: INDUSTRIAL, MOVIL o EDUCATIVO. Aparecen los campos propios de ese tipo:

   | Tipo | Campos propios |
   |---|---|
   | Industrial | Carga (kg) y N° de ejes |
   | Móvil | Locomoción (ruedas, orugas, patas o aéreo) y Autonomía (h) |
   | Educativo | Plataforma (Arduino, LEGO…) y Nivel (básico, intermedio o avanzado) |

2. Escribe el **Código** (por ejemplo `IND-002`: mayúsculas, números y guiones), el **Nombre** y el **Modelo**.
3. Elige la **Fecha de adquisición** (no puede ser futura) y el **Estado**.
4. Escribe el **P. Unit. (costo)** y la **Utilidad** (`0.25` = 25 %). El **precio de venta** se calcula solo: costo + costo × utilidad.
5. Elige la **Marca** y, si el robot ya es de un cliente, su **Dueño**.
6. Presiona **Guardar**.

**Estados de un robot:**

| Estado | Significa |
|---|---|
| EN_STOCK | Está en el almacén, listo para vender. |
| VENDIDO | Ya se vendió; debe tener un cliente como dueño. |
| EN_REPARACION | Está en mantenimiento. |
| OPERATIVO | Es de un cliente y funciona bien. |
| DE_BAJA | Ya no se usa. |

::: tip
Marca **"Solo los que necesitan mantenimiento"** para ver solo los robots a los que ya les toca revisión.
:::

## 4.2 Repuestos

**Menú:** Catálogo → Repuestos *(Administrador, Gestor y Gerente)*

![Gestión de repuestos](img/repuestos.png)

1. Escribe el **Código** (por ejemplo `REP-004`) y elige el **Tipo de repuesto**: MOTOR, SENSOR, BATERIA o CONTROLADOR.
2. Escribe el **Nombre** y el **Modelo**.
3. Escribe el **costo**, la **utilidad**, el **Stock** y la **Vida útil** en horas.
4. Elige la **Marca** y presiona **Guardar**.

La columna **Stock** se pinta de color. Cuando quedan **5 unidades o menos**, el repuesto aparece en las alertas del inicio. El stock **baja solo** cuando vendes o cuando reemplazas una pieza en un mantenimiento, y **sube solo** cuando registras una importación.

# 5 · Perfil Vendedor

El vendedor atiende a los clientes, registra las ventas y emite los comprobantes. *(El Administrador también puede hacer todo esto.)*

## 5.1 Gestionar clientes

**Menú:** Ventas → Clientes

![Gestión de clientes](img/clientes.png)

1. Escribe el **DNI** (8 dígitos) o el **RUC** (11 dígitos) y elige el **Tipo documento**.
2. Escribe los **Nombres / Razón social**. Si es una empresa, escribe también el **Rep. legal**; si es persona, deja un guion `-`.
3. Escribe la **Dirección** y el **Celular** (de 6 a 12 dígitos), y presiona **Guardar**.

::: tip
No se puede registrar dos veces el mismo DNI o RUC. Al editar un cliente, su documento queda bloqueado porque es su identificador.
:::

## 5.2 Registrar una venta, paso a paso

**Menú:** Ventas → Registrar venta

**Paso 1. Elegir al cliente.** Escribe parte del nombre o del DNI en **Buscar por DNI/RUC o nombre**. Aparece una lista; haz clic en el cliente. La búsqueda funciona aunque no escribas las tildes.

![Autocompletado del cliente](img/venta_autocomp.png)

::: tip
**¿El cliente no existe?** Escribe su DNI y presiona **Buscar**. El sistema consulta **RENIEC** y llena el nombre. Completa la dirección y el celular, y presiona **Registrar cliente**. Si no hay internet, escribe los datos a mano.
:::

**Paso 2. Agregar productos.** Escribe el código o el nombre en **Buscar robot o repuesto** y elige el producto. Para un repuesto, escribe la **Cantidad**. Presiona **Agregar**. Repite para cada producto.

![Carrito de la venta](img/venta_carrito.png)

- Un **robot** se agrega solo una vez, porque cada robot es único, y debe estar EN_STOCK.
- Un **repuesto** no puede pasar del stock disponible.
- Para quitar algo del carrito, presiona el **tacho** de esa fila.
- Abajo ves la **Base imponible**, el **IGV (18 %)** y el **Total**. Los precios ya incluyen el IGV.

**Paso 3. Elegir el comprobante.** Arriba a la derecha elige **BOLETA** o **FACTURA**. El número (por ejemplo `B001-00000002`) se genera solo.

- **Boleta:** para personas, con DNI.
- **Factura:** solo para clientes con **RUC**.

**Paso 4. Registrar.** Presiona **Registrar venta**. El sistema guarda la venta, marca los robots como VENDIDO y descuenta el stock de los repuestos. Luego se abre el comprobante.

## 5.3 El comprobante

![Comprobante de venta](img/comprobante.png)

| Botón | Qué hace |
|---|---|
| **Imprimir** | Envía el comprobante a la impresora. |
| **Exportar PDF** | Guarda el comprobante como archivo PDF; tú eliges la carpeta. |
| **Cerrar** | Cierra la ventana y vuelves a la venta. |

El total aparece también **en letras**, por ejemplo "SETENTA Y CINCO MIL CIENTO SETENTA Y SEIS CON 40/100 SOLES".

## 5.4 Historial de ventas

**Menú:** Ventas → Historial de ventas

![Historial de ventas](img/hist_ventas.png)

- Arriba ves el número de ventas, el total vendido, el ticket promedio y el IGV.
- **Haz clic en una venta** para ver sus productos en la tabla **Detalle**.
- Presiona **Ver comprobante** para abrirlo de nuevo, imprimirlo o exportarlo.
- Usa **Filtrar** para buscar por cliente, documento o fecha.

# 6 · Perfil Gestor de reparaciones

El gestor registra las fallas que reportan los clientes, los mantenimientos y a los técnicos. *(El Administrador también puede hacer todo esto.)*

## 6.1 Técnicos

**Menú:** Reparaciones → Técnicos

![Gestión de técnicos](img/tecnicos.png)

Registra el **DNI** (8 dígitos), los **Nombres**, la **Especialidad** y el **Celular** (9 dígitos) de cada técnico. Funciona como las demás pantallas de registro (sección 3.4).

## 6.2 Reportar fallas

**Menú:** Reparaciones → Reportar fallas

![Reportar fallas](img/fallas.png)

1. Elige el **Robot** y la **Gravedad**: BAJA, MEDIA o ALTA.
2. Elige la **Fecha** y escribe la **Descripción**, de 5 a 100 caracteres, por ejemplo "La batería pierde carga rápido".
3. Presiona **Reportar falla**.

En **Ver** puedes elegir **Pendientes** o **Todas**. La falla queda pendiente hasta que se registre un mantenimiento para ese robot.

## 6.3 Registrar un mantenimiento

**Menú:** Reparaciones → Registrar mantenimiento

![Registrar mantenimiento](img/reg_mant.png)

1. **Cabecera:**
   - Elige el **Robot**. Al lado de **Fallas** verás cuántas fallas pendientes tiene; se ligarán a este mantenimiento.
   - Elige el **Técnico**, el **Tipo** (PREVENTIVO o CORRECTIVO) y la **Fecha**.
   - Escribe la **Descripción** y la **Mano de obra** en soles.
   - Elige el **Estado**: PENDIENTE, EN_PROCESO o FINALIZADO.
2. **Componentes (opcional):** elige un componente del robot y la acción: **REVISADO**, **REPARADO** o **REEMPLAZADO**. Escribe una observación y el costo, y presiona **Agregar**.
3. Revisa el **Costo total** abajo y presiona **Registrar mantenimiento**.

**Qué pasa al registrar:**

- Si eliges **REEMPLAZADO**, se descuenta 1 unidad del repuesto y el componente vuelve a 0 horas de uso.
- Si el estado es **FINALIZADO**, las fallas pendientes del robot quedan **resueltas** y el robot vuelve a estar disponible.
- Si el estado es PENDIENTE o EN_PROCESO, el robot queda **EN_REPARACION**.

## 6.4 Historial de mantenimientos

**Menú:** Reparaciones → Historial de mantenimientos

![Historial de mantenimientos](img/hist_mant.png)

Muestra todos los mantenimientos con su costo y su estado. **Haz clic en uno** para ver en **Detalle** qué componentes se revisaron o se reemplazaron.

# 7 · Perfil Gerente de importaciones

El gerente registra a los proveedores y las importaciones, es decir, la mercadería que llega del extranjero. *(El Administrador también puede hacer todo esto.)*

## 7.1 Proveedores

**Menú:** Importaciones → Proveedores

![Gestión de proveedores](img/proveedores.png)

Registra el **N° de documento**, la **Razón social**, el **País**, la **Dirección**, el **Celular** y el **Email** del proveedor. Funciona como las demás pantallas de registro (sección 3.4).

## 7.2 Registrar una importación

**Menú:** Importaciones → Registrar importación

![Registrar importación](img/reg_import.png)

::: tip
**Antes de empezar:** el **proveedor** debe estar registrado (7.1) y cada **producto** debe existir en el Catálogo (sección 4). Para traer un robot nuevo, primero regístralo en Catálogo → Robots.
:::

1. **Cabecera:** elige el **Proveedor** y la **Fecha**. Elige el **Documento** (INVOICE o FACTURA) y escribe la **Serie** y el **N°** de la factura del proveedor, por ejemplo `INV` y `2026-0500`. Escribe el **Flete** y los **Aranceles** en soles.
2. **Productos:** elige el **Producto**, escribe el **P. unit.** (costo) y la **Cantidad**, y presiona **Agregar**. Un robot entra siempre con cantidad 1.
3. **Totales:** revisa la **Base**, el **IGV** y el **Total**. En la importación, el IGV es (base + flete + aranceles) × 18 %.
4. Presiona **Registrar importación**.

![Importación registrada](img/reg_import_ok.png)

Al registrar, **el stock de los repuestos sube** con la cantidad que llegó, y los robots quedan EN_STOCK, listos para vender.

::: tip
No se puede registrar **dos veces la misma factura** del mismo proveedor. Si te sale ese mensaje, revisa el historial: probablemente ya se registró.
:::

## 7.3 Historial de importaciones

**Menú:** Importaciones → Historial de importaciones

![Historial de importaciones](img/hist_import.png)

Arriba ves el total importado, los fletes y los aranceles. **Haz clic en una importación** para ver sus productos en **Detalle**.

# 8 · Perfil Administrador

El administrador **ve todos los menús**, así que puede hacer todo lo de las secciones 4 a 7. Además tiene una opción solo para él.

## 8.1 Usuarios

**Menú:** Administración → Usuarios

![Usuarios del sistema](img/usuarios.png)

- Muestra a todos los usuarios con su **perfil** y su **estado**.
- Presiona **Desactivar** para que un usuario ya no pueda entrar, por ejemplo si dejó la empresa, y **Activar** para devolverle el acceso.
- No puedes desactivar tu propia cuenta, para no quedarte sin acceso.

# 9 · Preguntas frecuentes

| Problema | Solución |
|---|---|
| No puedo entrar. | Revisa el usuario y la clave, y que no estén activadas las mayúsculas. Si el administrador desactivó tu usuario, pídele que lo active. |
| No veo un menú. | Tu perfil no tiene ese módulo (sección 1.2). Entra con el usuario que corresponde. |
| "Stock insuficiente" | No hay suficientes unidades. Registra una importación (sección 7.2) o vende menos. |
| "La factura solo se emite a clientes con RUC" | Cambia a **BOLETA**, o elige un cliente con RUC. |
| "No se puede eliminar…" | Ese registro ya se usó en ventas, mantenimientos o importaciones, y se conserva para el historial. |
| La búsqueda de DNI no responde. | Necesita internet. Escribe los datos del cliente a mano. |
| Quiero borrar todos los datos y empezar de cero. | Cierra DzRobot y borra la carpeta `C:\Users\<tu usuario>\DzRobot`. |
| Windows dice "Windows protegió tu PC". | Presiona **Más información → Ejecutar de todas formas** (sección 2.2). |
